+++
draft = false
title = "Getting start"
description = ""

[menu.main]
parent = ""
identifier = "start"
weight = 1

+++

## Requirements

Download [Hugo binary](https://gohugo.io/overview/installing/) for your OS (Windows, Linux, Mac) : it’s that simple

{{%children style="h2" description="true"%}}