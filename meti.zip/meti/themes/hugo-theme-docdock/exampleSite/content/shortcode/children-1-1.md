+++
draft = false
title = "page 1-1"
description = "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod"

[menu.main]
parent = "children-1"
identifier = "children-1-1"
+++

This is a demo child page