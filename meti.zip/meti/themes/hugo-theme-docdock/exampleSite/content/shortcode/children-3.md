+++
draft = false
title = "page 3"
description = "This is a demo child page"

[menu.main]
parent = "children"
identifier = "children-3"

+++

This is a demo child page