+++
draft = false
title = "page 1"
description = "This is a demo child page"

[menu.main]
parent = "children"
identifier = "children-1"
+++

This is a demo child page