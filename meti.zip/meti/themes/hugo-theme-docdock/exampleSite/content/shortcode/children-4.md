+++
draft = false
title = "page 4"
description = "This is a demo child page"

[menu.main]
parent = "children"
+++

This is a demo child page, not displayed in the menu