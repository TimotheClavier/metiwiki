+++
draft = false
title = "About the Search Engine"
description = ""

[menu.main]
parent = ""
identifier = "search"
weight = 40

+++

**Nothing to do on your side. :-)**

Docdock theme uses the last improvement available in hugo version 20+ to generate a json index file ready to be consumed by lunr.js javascript search engine.


