+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Astuces Debugger"
author="Timothé Clavier"

[menu.main]
identifier = "JS-2-Astuces Debugger"
parent ="JS-1-Javascript"
+++
Auteur:  
Date: 02/05/2017

---------------

### Astuces Debugguer

- Actuce de YC (du 02/05/2016) :

Pour ceux qui utilisent chrome pour __débuguer__ :

Quand vous voulez vous placer dans un contexte javascript précis et que vous cherchez la bonne iframe, plutôt que de chercher dans la liste, il suffit de __cliquer sur le tag "iframe" correspondant__ (dans l'onglet élément) :
 ![Menu astuce Chrome](http://lxdev03:3004/resources/javascript/astuce_chrome1.png)