+++
date="2017-05-18"
draft="true"
title="Tips"
author="Timothé Clavier"

[menu.main]
identifier="JA-2-tips"
parent="JA-1-Jasper"
+++
Auteur:  
Date: 31/10/2016 

------------- 
 
# Tips Divers pour développement Jaspersoft

## Comment savoir si une édition est en 3.7 ou 4.7?
Dans une édition 4.7, certains champs possèdent une valeur en plus dis _uuid_ .
Celle-ci est automatiquement rajouté lors d'une première ouverture en 4.7.\
Afin d'être sur de la version, la méthode la plus simple (et la plus moche), 
c'est d'ouvrir systèmatiquement une édition en 3.7, et si ça parche pas.. c'est que c'est un 4.7!

## Bug lors de l'installation de JasperSoft iReport (3.7 ou 4.7)
Après installation, il se peut que le logiciel ne trouve pas le jdk nécéssaire à son fonctionnement.
Si ce jdk ne peut pas être ajouté au PATH de la machine, il faut aller directement configurer le fichier de config jasper. \
Fichier ```C:\Program Files (x86)\Jaspersoft\iReport-4.7.0\etc\ireport.conf ``` .\
Ligne à remplacer ``` #jdkhome="/path/to/jdk" ``` (à décommenter et changer le path)
