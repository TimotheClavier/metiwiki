+++
date="2017-05-18T15:12:23+02:00"
draft="true"
title="Applet"
author="Timothé Clavier"
[menu.main]

identifier="J-2-Applet"
parent="J-1-Java"

+++
Auteur:  
Date: 25/08/2016

----------------------
#Signer une applet

**keytool et jarsigner sont disponibles dans le jdk**

Génération de la clé:
```bash
keytool -genkey -keyalg rsa -alias myKeyName
```


Génération du certificat
```bash
keytool -export -alias myKeyName -file myCertName.crt
```

Signature du jar
```bash
jarsigner "C:\my path\myJar.jar" myKeyName
```