+++
date="2017-05-16T15:12:23+02:00"
draft="true"
title="Tableau Refresh Data"

[menu.main]

identifier="CP-2-Tableau Refresh Data"
parent="CP-1-Composant"

+++
Auteur:  
Date: 25/08/2016

--------------------
# Rafraichir les données d'une ligne d'un tableau après validation

Dans un code après maj :
```php
/* En creation, $data['errors']['RFCRC_RCRC_NOCHRONO'] est renseigné automatiquement à partir d'un compteur */
if ($data['type_appel']=='C' && $erreur==0 && $data['errors']['RFCRC_RCRC_NOCHRONO'])
  fnc_data_refresh(
    &$data,
    $_SESSION['s_appli_context'],
    $_GET['p_nogci'],
    "AND RCRC_NOCHRONO = ".$data['errors']['RFCRC_RCRC_NOCHRONO'],
    array(
      ':PAR_CDFO'     => $data['RFCRC_RCRC_CDFO']     ,
      ':PAR_NOVAR'    => $data['RFCRC_RCRC_NOVAR']    ,
      ':PAR_TYCTR'    => $data['RFCRC_RCRC_TYCTR']    ,
      ':PAR_NOCONTRA' => $data['RFCRC_RCRC_NOCONTRA']
    )
  ) ;
```