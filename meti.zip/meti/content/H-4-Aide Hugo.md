+++
date="2017-05-16T15:12:23+02:00"
draft="true"
title="Aide hugo"
author="Timothé Clavier"

[menu.main]
identifier="H-4-Aide"
parent="H-1-Hugo"
+++
Auteur: Timothé Clavier  
Date: 17/05/2017

---------------------
# __Tutoriel et explication de Hugo__

Avant de commencer à installer un thème assurer d’avoir installer Hugo sinon allez consulter le mode opératoire d’installation d’Hugo.

## __1. Lancement__

Tout d’abord, lancer git bash et pour vérifier notre installation d’Hugo, utiliser la commande $ hugo help

Si ce résultat apparaît alors Hugo est bien installer sinon se référer au mode opératoire d’installation d’Hugo .
![hugo help](https://y9vf1q.bn1304.livefilestore.com/y4pOKbSnVBkl9iUZpuhxinsYnHdfjquAj_Ky5a8_UI-CTGJmLMh_qFNg2cj25-8aBC0qQuwthmVEt6GfC5nSmjezmRhi355_uXncu7OcPRpixsECBctsjoXdl8S2YdTllldMumPybWpD3HvGwNEts6cVrAcoBVXtwlDgy0GT2iFes-JMSLbhKWrOzgwnkZD-3E7MYLuVgbbiAH1JVn6as8iXw/hugo%20help.png?psid=1)

## __2.Contenu__

Pour créer un contenu sur notre site il faut écrire un fichier en markdown,
pour cela on peut utiliser l’application code writer de Windows 10.

![entete](https://y9vf1q.bn1304.livefilestore.com/y4pz5SF-mW1CVQUDL-2WCPsiKtxpsfd2y2RBmpB8E2aPNwqBygBqiteb7y-4pNH-SdSwNArXiFOhMB7PDJe4__orrvMy5NjU1jEAhsxkjslKcnLHkK6Mf54B7Qodaf4DsrBgdfhKBptf774V6_WoYwd6RsLq9-sQ4_zJswAms0CSMOpBIh-ElZSpyiuJ7sro4gl6DmWgBKdYPLtvI1BIcGMhA/entete.png?psid=1)

Voilà l’entête de chaque contenu que l’on va vouloir ajouter au site. 
Une date : à modifier si on édite un fichier.
Un titre : juste  pour titre nos fichier et ne pas les mélanger.
Draft : Permettra de voir la page

Ensuite nous pouvons rajouter quelques options.

![main](https://y9vf1q.bn1304.livefilestore.com/y4p_0KkeTOtyPAX7KyhF4balUkOV7vP8PCM3OnmVIBh_5X9a0dLaiUM78MCL0eKpbfhbJxmRIAYVr4qA373jfNJzd-5iYatyXGgfETlIU2XyD23limv0ftss_84JaPIP2pNh8L5zBHoRnz7Ms_GZnhBE2UbmIzoqURFdSJ4c-LQydtcDf-dIcwAsnNRnFkXQ89uEfMmDugI9_SLbuCFq_PEpw/main.png?psid=1)

L’option [menu.main] va intégrer notre fichier dans notre barre sur la gauche du notre site

![slide](https://y9vf1q.bn1304.livefilestore.com/y4pT1qWvSJJ99vXoe3dadY5x4-ep51Pln-pz9YBahZlWBZXrwJTV6dUSx-GueLsBEahXR7eJc-SWsHxnbzIGlDBll1D3EjaG1fDaFWbu8rNjR6ZSLvwOfokUe9prOykTeP38hbvaekJLEbqAohszUXNzidtlQE2qMnFdqoyobbZqrLo-hvc8T2EElELj_n8TlrPj9-5uzGRI0BHOt-2h9--fQ/slide.png?psid=1)

« Identifier » va être l’identifiant de notre fichier dans la barre et parent sera le fichier auxquelles des sous fichiers,
par exemple le fichier astuces 1 a pour parent « javascript » et donc il est mit en sous fichier

![open slide](https://y9vf1q.bn1304.livefilestore.com/y4pTovaWvm5xYPkInCJhVotX9-HgCV0S_xlSOc-xffNA1usIHNYQBPILq0mgK7eRT5bhWmFGSEzP91Ullg8_DqKLSmcctatd1HRzM1xNCJRG676baUPfsfT_Ruz499Hp2K-llKvh6OKswBrgEE4YE9dR9pvbZOFHOpOynlGJ6ftHuWxOtvVNKOtK4xeXrZQm8uAptv2udgL9JnZif9q5PL5nQ/open%20slide.png?psid=1)

Et ensuite nous allons écrire notre document en markdown. Le markdown est une écriture permettant de faire de la mise en page tout en écrivant nos textes.

Après avoir écrit notre document nous l’enregistrons dans le dossier content de notre site.  
Pour que les fichiers soient trier correctement nous allons utiliser la nomenclature suivant:  
En majuscule un référence permettant d'identifier le dossier " H pour Hugo"  
Un tiret suivit du numero du fichier puis un autre tiret.  
Et pour finir le titre du document.