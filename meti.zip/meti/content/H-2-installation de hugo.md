+++
date="2017-05-16T15:12:23+02:00"
draft="true"
title="L'installation de hugo"
author="Timothé Clavier"

[menu.main]
identifier="H-2-installation de hugo"
parent="H-1-Hugo"
+++


Auteur : Timothé Clavier  
Date : 17/05/2017

--------------

## __1.Préparation__

Pour commencer créer un dossier nommé Hugo :  C:\Hugo  

Puis dans ce dossier un dossier bin :  C:\Hugo\bin  

Ainsi qu’un dossier Sites :  C:\Hugo\Sites

## __2.Téléchargement__

Pour télécharger Hugo, rendez-vous à cette adresse et choisissez la version qui vous convient : https://github.com/spf13/hugo/releases

Il vous faudra aussi télécharger Git Bash qui servira ensuite comme invite de commande.

## __3.Extraction__

Après avoir téléchargé Hugo, extraire les fichiers dans le dossier : C:\Hugo\bin
Si le fichier exécutable n’est pas nommé hugo.exe alors renommé le en tant que tel.

## __4.PATH settings__

- Clic droit sur le bouton démarrer

- Cliquer sur système
- Cliquer sur paramètres système  avancées 
- Cliquer sur Environment Variables. 
- Dans la section des variables d’utilisateurs, Trouver la ligne qui commence avec PATH. 
- Double-cliquer sur PATH.  
- Choisir le fichier où hugo.exe a été extrait, C:\Hugo\bin si vous avez suivi les instructions précédentes. 
- Entrer quand vous avez fini. 
- Cliquer sur Ok sur toutes les fenêtres pour quitter. 

## __5.Vérification que hugo est installé__

- Ouvrir l’invite de commande, appuyer sur la touche Windows et taper cmd puis faire entrer

- Dans cette invite de commande mettez vous dans le répertoire bin à l’aide de la commande :  cd C:\hugo\bin

- Ensuite taper la commande : hugo help

Si rien se passe vérifier que le PATH est correctement indiqué, si il n’y a pas d’erreurs alors rendez-vous sur le site de [hugo dans la partie discussion](https://discuss.gohugo.io/) pour résoudre votre problème.


### __Placez-vous dans le répertoire sites maintenant__

Avec la commande :  
<p align="center"> cd C:\hugo\Sites</p>

Pour générer un nouveau site il va falloir utiliser la commande :  

<p align="center">hugo new site nom_du_site</p>  

Par exemple : hugo new site exemple.com
