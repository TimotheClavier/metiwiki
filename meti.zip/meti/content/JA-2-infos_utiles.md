+++
date="2017-05-18"
draft="true"
title="Liens utiles"
author="Timothé Clavier"

[menu.main]
identifier="JA-2-Liens utiles"
parent="JA-1-Jasper"
+++
Auteur:  
Date: 31/10/2016  

-----------


## Adresse des serveurs de Dev

| Server                 | Adresse du service |
|---------------------   |----------------------------------|
| lxdev02 (Socle 1)      | http://lxdev02:8090/jasperserver |
| lxdev03 (Socle 2)      | http://lxdev03.meti.fr:8191/jasperserver |
| Rec11                  | http://lxdev02:8091/jasperserver |
| Serveur de Reference   | http://ref-srv-edt.dev.meti.fr:8090/jasperserver |

## Gestion des traductions sur une VM
Il se peut que les traductions ne soient pas forcement mis en place après un patch.
Il faut vérifier dans ce cas deux choses:
- Si le fichier de traduction est à jour (/meti/locale/jasperserver/emag_traduction_fr.properties)
- Si le serveur jasperserver a bien été redémarré après le patch

Si le fichier est bien sur la machine mais que jasper ne les prends pas en compte, il faut alors redémarrer le serveur:
```
service jasperserver stop && service jasperserver start
```

## Export d'édition

### La méthode standard
Les éditions sont a exporter (de manière générale) à partir du serveur de socle 2 ou du serveur de référence.
Un script a été mis en place sur _lxdev03_ afin de simplifier les exports:
```
jasper-export.sh {dev|ref} NomDuFichier.zip PATH/TO/REPORT
```
### L'autre méthode
Il se peut que, selon la version du socle technique, on doive passer par l'export plus ancien (Socle 1).
Il faut dans ce cas se placer sur le serveur de socle 1 (lxdev02) et allez exporter le report à la mano.
```
lxdev02:/opt/jasperserver/scripts
./js-export.sh --output-zip NomDuFichier.zip --uris PATH/TO/REPORT
```

# Specs utiles
- [Guide développement Jasper](http://172.16.0.19:8080/docs/trunk/Developpement/Jasper/dev_jasper_guide_developpement.odt)
- [Normes graphiques](http://172.16.0.19:8080/docs/trunk/Developpement/Jasper/dev_jasper_normes_graphiques.ods)