+++
date="2017-05-16T15:12:23+02:00"
draft="true"
title="Utilitaires Meti"
author="Timothé Clavier"

[menu.main]
identifier="ADO-4-Utilitaires Meti"
parent="ADO-1-Administration Oracle"
+++

Auteur:  
Date: 18/04/2017

------------------

## Administration avec un compte ETUDES 

- documentation 
[oracle_util.pdf](http://lxdev03:3004/resources/oracle/oracle_util.pdf)

- Connection 
```Sql
sqlplus etudes/etudes@<instance>;
```


### Gestion des sessions/tuning

#### Liste des locks 
```Sql
SELECT to_char(sysdate,'HH24:MI') "Date", a.USERNAME As SCHEMA,
	(select owner||'.'||object_name from dba_objects where object_id=a.row_wait_obj#) object,
	b.inst_id||'-'||b.sid       BLOCKER,
	b.program blocker_program,
	b.module blocker_module,
	b.action blocker_action,
	a.inst_id||'-'||a.sid       BLOCKEE,
	a.program blockee_program,
	a.module blockee_module,
	a.action blockee_action,
	a.seconds_in_wait
	FROM gv$session a, gv$session b
	WHERE a.blocking_session IS NOT NULL
	and    a.blocking_session=b.sid
	and a.blocking_instance = b.inst_id
order by a.seconds_in_wait;
```

#### Liste des objets verouillée 
```Sql
SELECT lk.SID, se.username, se.osuser, se.machine,
       DECODE (lk.TYPE,
               'TX', 'Transaction',
               'TM', 'DML',
               'UL', 'PL/SQL User Lock',
               lk.TYPE
              ) lock_type,
       DECODE (lk.lmode,
               0, 'None',
               1, 'Null',
               2, 'Row-S (SS)',
               3, 'Row-X (SX)',
               4, 'Share',
               5, 'S/Row-X (SSX)',
               6, 'Exclusive',
               TO_CHAR (lk.lmode)
              ) mode_held,
       DECODE (lk.request,
               0, 'None',
               1, 'Null',
               2, 'Row-S (SS)',
               3, 'Row-X (SX)',
               4, 'Share',
               5, 'S/Row-X (SSX)',
               6, 'Exclusive',
               TO_CHAR (lk.request)
              ) mode_requested,
       TO_CHAR (lk.id1) lock_id1, TO_CHAR (lk.id2) lock_id2, ob.owner,
       ob.object_type, ob.object_name,
       DECODE (lk.BLOCK, 0, 'No', 1, 'Yes', 2, 'Global') BLOCK, se.lockwait
  FROM v$lock lk, dba_objects ob, v$session se
 WHERE lk.TYPE IN ('TX', 'TM', 'UL') AND lk.SID = se.SID AND lk.id1 = ob.object_id(+)

```


#### Lister qui lock une gtt

```Sql
define ma_gtt=&1
SELECT s.username,s.sid ,s.osuser,s.process,s.machine,s.terminal
FROM   v$lock      l
      ,dba_objects o
      ,v$session   s
WHERE l.id1 = o.object_id
AND   s.sid = l.sid
AND   o.object_name = upper('&ma_gtt')
;
```


#### Lister les sessions actives
```Sql
SELECT s.inst_id,
       s.sid,
       s.serial#,
       p.spid,
       s.username,
       s.module,
       s.program,
       s.osuser,
       s.state
FROM   gv$session s
       JOIN gv$process p ON p.addr = s.paddr AND p.inst_id = s.inst_id
WHERE  s.type != 'BACKGROUND'
AND s.username NOT LIKE 'SYS%'
AND s.username <> user
--AND s.username='<MON_SCHEMAS>' -- ici mettre le filtre schémas
;
```

#### Killer une session 

```Sql
begin
      sys.kill_session(pn_sid=>1,pn_serial=>143,pn_instance=>1);
end;
/
```

#### flusher Oracle 
   - les requetes 
   ```Sql
   exec sys.flush_pool;
   ```
   - Tous 
   ```Sql
   exec sys.flush_all;
   ```
### Divers

#### paramètres NLS
```Sql
PROMPT *** Database parameters ***
SELECT * FROM nls_database_parameters;

PROMPT *** Instance parameters ***
SELECT * FROM nls_instance_parameters;

PROMPT *** Session parameters ***
SELECT * FROM nls_session_parameters;
```
#### Objets invalides
```Sql
SELECT to_char(sysdate,'HH24:MI') "Date", a.USERNAME As SCHEMA,
	(select owner||'.'||object_name from dba_objects where object_id=a.row_wait_obj#) object,
	b.inst_id||'-'||b.sid       BLOCKER,
	b.program blocker_program,
	b.module blocker_module,
	b.action blocker_action,
	a.inst_id||'-'||a.sid       BLOCKEE,
	a.program blockee_program,
	a.module blockee_module,
	a.action blockee_action,
	a.seconds_in_wait
	FROM gv$session a, gv$session b
	WHERE a.blocking_session IS NOT NULL
	and    a.blocking_session=b.sid
	and a.blocking_instance = b.inst_id
order by a.seconds_in_wait;
```

### Gestion des schemas
#### création de user et tableSpace associé
```Sql
exec create_user(’MAG002’);
```

#### suppression de user et tableSpace associé
```Sql
exec DROP_USER(’MAG01’);
```

#### Espace disque
- Par tableSpace

```Sql
SELECT a.file_name,
       ROUND(a.bytes/1024/1024) AS size_mb,
       ROUND(a.maxbytes/1024/1024) AS maxsize_mb,
       ROUND(b.free_bytes/1024/1024) AS free_mb
FROM   (SELECT file_name,
               file_id,
               bytes,
               GREATEST(bytes,maxbytes) AS maxbytes,
               GREATEST(bytes,maxbytes)-bytes AS growth
        FROM   dba_data_files) a,
       (SELeCT file_id,
               SUM(bytes) AS free_bytes
        FROM   dba_free_space
        GROUP BY file_id) b
WHERE  a.file_id = b.file_id
ORDER BY file_name;
```

### Droits speciaux DBMS_CRYPTO, gv$session

```Sql
grant select on sys.gv_$session to {{etude_user}} with grant option
/
grant execute on sys.dbms_crypto to {{etude_user}} with grant option
/
```
