+++
date="2017-05-16T15:12:23+02:00"
draft="true"
title="Divers Oracle"
author="Timothé Clavier"

[menu.main]

identifier="ADO-3-Divers Oracle"
parent="ADO-1-Administration Oracle"

+++

Auteur:  
Date: 31/03/2017

------------------

## Les paramètres 

### de sessions NLS

```Sql 
-- au niveau session  
SELECT parameter, VALUE
  FROM nls_session_parameters;
-- au niveau instance
SELECT parameter, VALUE
  FROM nls_instance_parameters;  
-- au niveau database
SELECT parameter, VALUE
  FROM nls_database_parameters;
  
```

### de la base 

<br> sous le compte system, sous sqlplus
```Sql
sho parameter PLSQL
```
<br>=> donne l'ensemble des paramètres ayant PLSQL dans le nom

### Gestion des warnings

<br> Les warnings sont des messages d'alerte et/ou de conseil qui apparaissent lors de la compilation des objets oracle.
- au niveau de la session
<br> Il est possible de modifier les warnings de compilation pour sa session Oracle

```Sql
-- Désactiver tout
ALTER SESSION set PLSQL_WARNINGS='DISABLE:ALL';
-- Activer tout
ALTER SESSION set PLSQL_WARNINGS='ENABLE:ALL';
-- Activer un certain type
ALTER SESSION set PLSQL_WARNINGS='ENABLE:SEVERE';
-- Activer plusieurs type 
ALTER SESSION set PLSQL_WARNINGS='DISABLE:INFORMATIONAL, DISABLE:PERFORMANCE, ENABLE:SEVERE';

```

### Environnement 

- [SYS_CONTEXT (USERENV)](http://www.techonthenet.com/oracle/functions/sys_context.php)


### Produits Oracle installés

<br> sous le compte <i>SYSTEM</i>

- Connaitre les composants
```Sql
SELECT   comp_name, VERSION, status
    FROM dba_registry
ORDER BY 1;
```
- Connaitre les options 
```Sql
SELECT   parameter, VALUE
    FROM v$option
ORDER BY 1;
```
<i>Exemple</i>
	<br>Pour savoir si OLAP est installé
```Sql 
SELECT VALUE
  FROM v$option
 WHERE parameter = 'OLAP';
```

- Savoir si une option a été utilisée
```Sql 
SELECT NAME "FEATURE", first_usage_date "FROM", last_usage_date "TO"
  FROM dba_feature_usage_statistics
 WHERE NAME LIKE '%OLAP%';
 ```

- Connaitre les patchs Oracle d'installée : 
<br> sur <b>Oracle 11</b> (sous system)
```Sql
  SELECT *
    FROM dba_registry_history
ORDER BY action_time;
```
<br> sur <b>Oracle 12</b> (sous system)
```Sql
SELECT * FROM dba_registry_sqlpatch;
```


## Connaitre les transactions actives dans sa session

- Utilisation du package <b><i>DBMS_TRANSACTION.step_id</i></b> 
<br> ce package renvoi l'ensemble des objets en cours de transaction.

- Fonction <b><i>mlib_util.exists_transaction_0_1()</i></b>
<br> renvoi Vrai(1) ou faux (0) s'il existe une transaction dans la session.

## Flusher Oracle 

<br> Sous un compte système <i>(avec droit alter session) </i> </br>
 ```Sql 
alter system checkpoint;
 --le cache des données
alter system flush buffer_cache;
--mémoire cache partagée : données, plan d'exécution, bibliothèque, dictionnaire
alter system flush shared_pool;

alter system flush global context;
alter system switch logfile;
```
## Consommation Mémoire
 - Taille de la SGA + PGA
 <br> <i>Sous le compte system</i>
 ```Sql 
 sho parameter sga
 sho parameter pga
 select name, bytes/1024/1024 as Mo from v$sgainfo;
```
<br>Puis de façon plus détaillé :

 ```Sql
 select * from v$sgastat;
 select * from v$pgastat;
 ```
 <br>Mémoire libre :
 ```Sql
 select sum(bytes)/1024/1024 as "Mo free" from v$sgastat where name ='free memory';
 ```
 <br>Conseil pour le dimensionnement de la PGA : 
 ```Sql
 select * from v$pga_target_advice;
 ```
   
## Lien de base de données (DBLINK)

- Créer un lien de connections entre schémas 

<br>1 - Sous un compte <i>SYSTEM</i> donner les droits aux schémas utilisateur

<i>Exemple</i>
```Sql
GRANT CREATE DATABASE LINK TO hyp011;
```
<br>2 - Sous chaque schemas demandeur, creer la connection vers  le schémas demandé

<i>Exemple</i>
```Sql
CREATE DATABASE LINK "DBL_HYPCEN"
CONNECT TO HYPCEN
IDENTIFIED BY "ATTENT1"
USING 'lxora10:1521/MAG11';
```

<br>3 - Utilisation sur chaque schemas demandeur :
```Sql 
select * from mgart@DBL_HYPCEN;
```


- Connaitre les liens actif d'un schémas 

```Sql 
SELECT *
  FROM user_db_links;
```

<br>4 - Suppression du lien sur chaque schemas demandeur :
```Sql 
DROP DATABASE LINK "DBL_HYPCEN";
``` 

## Création d'un répertoire sous Oracle (directory)
 
<br> Sous le compte <b><i>System</i></b>
<br> sous le compte d'un schémas si celui-ci possède le droit de créer les répertoires <i>(privilège au niveau system)</i>
```Sql 
CREATE ANY DIRECTORY TO <schemas_name>;
```
<br><i><u>Exemple de création de répertoire</u></i>

```Sql
CREATE OR REPLACE DIRECTORY <directory_name> AS '<rep_physique_accessible_sous_oracle>';
CREATE OR REPLACE DIRECTORY totorep AS '/save';
```
<br><i>Attention Oracle ne test pas l'existance du répertoire</i>

<br>Accorder les droits de lecture/écriture (vers un schémas ou tous le Monde)
```Sql 
-- Vérifier l'existance de privilege
SELECT grantor, grantee, table_schema, table_name, privilege
FROM all_tab_privs WHERE table_name = <directory_name>;
-- Ajouter les autorisations
GRANT READ,WRITE ON DIRECTORY <directory_name> TO PUBLIC;
GRANT READ,WRITE ON DIRECTORY <directory_name> TO <schemas_name>;
-- Supprimer les autorisations
REVOKE READ ON DIRECTORY <directory_name> FROM <schema_name>;
```

<br>Vérifier la liste des répertoires déclaré
```Sql
SELECT * FROM all_directories;
```

<br> Supprimer un répertoire de déclaré sous Oracle 
```Sql
drop directory <directory_name>;
```
## Gestion des synonymes et des autorisations 

<br>Sous le compte <i>SYSTEM</i>, créer un synonyme public
```Sql 
create public synonym exscri for exmeti.exscri;
```
<br> Donner les droits à partir d'un schémas pour tous
```
grant all on exscri to public;
-- Supprimer les droits pour un schemas 
revoke all on exscri from mlib;
revoke all on exscri from uae1md;
```


## Vulgarisation Oracle

- le SGA (http://www.tuto-dba-oracle.com/sga-oracle.html)
- le PGA (http://www.tuto-dba-oracle.com/pga-oracle.html)
<br>
<br>La PGA varie en fonction de l'activité des sessions et non en fonction de la mémoire disponible sur la machine.
<br><i>(tris, jointures, allocation de variables PL/SQL, etc...)</i>

## Demarrage/arrêt Oracle

- Connaitre les instances démarrées : 
 Sous le serveur Linux Oracle 
 ```Bash
 ps -eaf|grep pmon
 ```
- Sous sqplus : 
 ```Bash
 export ORACLE_SID=MV9020
 sqlplus "/ as sysdba"
 ```
 puis une fois sous sqlplus : 
 ```Sql
 shutdown
 startup
 ```
 
- Si ASM
 ```Bash
export LeSID=REC11
ps -ef |grep -i local=no | grep $LeSid 
$ORACLE_HOME/bin/srvctl stop database -d $LeSid
$ORACLE_HOME/bin/srvctl start database -d $LeSid
```

- Listener
<br>sous le serveur Linux Oracle
```Bash
$ORACLE_HOME/bin/lsnrctl status
$ORACLE_HOME/bin/lsnrctl stop
$ORACLE_HOME/bin/lsnrctl start
```



## Occupation disque de la database

### Espace total

```SQl
SELECT 'groupedisk '|| NAME ||' : '||
       DECODE (SIGN (1 - free_mb / 1000),
               1, free_mb || ' Mb',
               (free_mb / 1000) || ' Gb'
              ) ||' libre sur '||
       DECODE (SIGN (1 - total_mb / 1000),
               1, total_mb || ' Mb',
               (total_mb / 1000) || ' Gb'
              ) ||' total Soit '|| ROUND (free_mb * 100 / total_mb, 2) || '% libre '||
       ROUND (100 - free_mb * 100 / total_mb, 2) || '% occupe' as "Tx Occupation"
  FROM v$asm_diskgroup
/

```


### Répartition par tableSpace

```Sql 
--=======================================================
-- liste des tablespaces espaces utilise/libre/taille
--=======================================================
SET WRAP OFF;
SET VERIFY OFF;
SET HEADING OFF;
SET FEEDBACK OFF;
SET PAGES 0;
SET SPACE 1;

SELECT   a.tablespace_name, ROUND (a.bytes_alloc / 1024 / 1024, 2) megs_alloc,
         ROUND (NVL (b.bytes_free, 0) / 1024 / 1024, 2) megs_free,
         ROUND ((a.bytes_alloc - NVL (b.bytes_free, 0)) / 1024 / 1024, 2) megs_used,
         ROUND ((NVL (b.bytes_free, 0) / a.bytes_alloc) * 100, 2) pct_free,
         100 - ROUND ((NVL (b.bytes_free, 0) / a.bytes_alloc) * 100, 2) pct_used,
         ROUND (maxbytes / 1048576, 2) MAX
    FROM (SELECT   f.tablespace_name, SUM (f.BYTES) bytes_alloc,
                   SUM (DECODE (f.autoextensible,
                                'YES', f.maxbytes,
                                'NO', f.BYTES
                               )) maxbytes
              FROM dba_data_files f
          GROUP BY tablespace_name) a,
         (SELECT   f.tablespace_name, SUM (f.BYTES) bytes_free
              FROM dba_free_space f
          GROUP BY tablespace_name) b
   WHERE a.tablespace_name = b.tablespace_name(+)
UNION ALL
SELECT   h.tablespace_name, ROUND (SUM (h.bytes_free + h.bytes_used) / 1048576, 2) megs_alloc,
         ROUND (SUM ((h.bytes_free + h.bytes_used) - NVL (p.bytes_used, 0)) / 1048576, 2) megs_free,
         ROUND (SUM (NVL (p.bytes_used, 0)) / 1048576, 2) megs_used,
         ROUND (  (  SUM ((h.bytes_free + h.bytes_used) - NVL (p.bytes_used, 0))
                   / SUM (h.bytes_used + h.bytes_free)
                  )
                * 100,
                2) pct_free,
           100
         - ROUND (  (  SUM ((h.bytes_free + h.bytes_used) - NVL (p.bytes_used, 0))
                     / SUM (h.bytes_used + h.bytes_free)
                    )
                  * 100,
                  2) pct_used,
         ROUND (SUM (f.maxbytes) / 1048576, 2) MAX
    FROM SYS.v_$temp_space_header h, SYS.v_$temp_extent_pool p, dba_temp_files f
   WHERE p.file_id(+) = h.file_id
     AND p.tablespace_name(+) = h.tablespace_name
     AND f.file_id = h.file_id
     AND f.tablespace_name = h.tablespace_name
GROUP BY h.tablespace_name
ORDER BY 1
/

```
### Répartition par tableSpace Metier (du + gros au + petit)
```Sql
  SELECT schemas, megs_alloc AS "Mo ", megs_free AS "Mo libre", megs_used AS "Mo used",
         pct_free AS "% libre", pct_used AS "% used"
    FROM (SELECT REPLACE (a.tablespace_name, '_DATA', '') AS schemas,
                 ROUND (a.bytes_alloc / 1024 / 1024, 2) megs_alloc,
                 ROUND (NVL (b.bytes_free, 0) / 1024 / 1024, 2) megs_free,
                 ROUND ( (a.bytes_alloc - NVL (b.bytes_free, 0)) / 1024 / 1024, 2) megs_used,
                 ROUND ( (NVL (b.bytes_free, 0) / a.bytes_alloc) * 100, 2) pct_free,
                 100 - ROUND ( (NVL (b.bytes_free, 0) / a.bytes_alloc) * 100, 2) pct_used
            FROM (  SELECT f.tablespace_name, SUM (f.bytes) bytes_alloc,
                           SUM (DECODE (f.autoextensible,  'YES', f.maxbytes,  'NO', f.bytes)) maxbytes
                      FROM dba_data_files f
                  GROUP BY tablespace_name) a,
                 (  SELECT f.tablespace_name, SUM (f.bytes) bytes_free
                      FROM dba_free_space f
                  GROUP BY tablespace_name) b
           WHERE a.tablespace_name = b.tablespace_name(+)
          UNION ALL
            SELECT REPLACE (h.tablespace_name, '_DATA', '') AS schemas,
                   ROUND (SUM (h.bytes_free + h.bytes_used) / 1048576, 2) megs_alloc,
                   ROUND (SUM ( (h.bytes_free + h.bytes_used) - NVL (p.bytes_used, 0)) / 1048576, 2) megs_free,
                   ROUND (SUM (NVL (p.bytes_used, 0)) / 1048576, 2) megs_used,
                   ROUND ( (SUM ( (h.bytes_free + h.bytes_used) - NVL (p.bytes_used, 0)) / SUM (h.bytes_used + h.bytes_free)) * 100, 2) pct_free,
                   100 - ROUND ( (SUM ( (h.bytes_free + h.bytes_used) - NVL (p.bytes_used, 0)) / SUM (h.bytes_used + h.bytes_free)) * 100, 2) pct_used
              FROM sys.v_$temp_space_header h, sys.v_$temp_extent_pool p, dba_temp_files f
             WHERE     p.file_id(+) = h.file_id
                   AND p.tablespace_name(+) = h.tablespace_name
                   AND f.file_id = h.file_id
                   AND f.tablespace_name = h.tablespace_name
          GROUP BY h.tablespace_name)
   WHERE EXISTS
            (SELECT 1
               FROM all_objects
              WHERE object_name IN ('MGSOC', 'TPSOC', 'MXDOS', 'APMEN') AND schemas = owner)
ORDER BY 2 DESC
/
```


### Répartition des objets pour un tableSpace

```Sql
--=======================================================
-- liste des tables par tablespaces espaces utilise/libre/taille
--=======================================================
SET WRAP OFF;
SET VERIFY OFF;
SET HEADING OFF;
SET FEEDBACK OFF;
SET PAGES 0;
SET SPACE 1;


SELECT * FROM (
SELECT DECODE (partition_name,
               NULL, segment_name,
               segment_name || ':' || partition_name
              ) objectname, segment_type object_type, ROUND (BYTES / 1024 / 1024, 2) mb,
       initial_extent initial_ex, next_extent next_ex, extents, BYTES ttlsize, owner, max_extents
  FROM dba_segments
 WHERE tablespace_name like '%_DATA' --:tname
 order by mb desc
) WHERE ROWNUM<30
/

--=======================================================
-- liste des tables par tablespaces espaces utilise/libre/taille avec des objets > 1 Go
--=======================================================
SELECT *
  FROM (  SELECT DECODE (partition_name, NULL, segment_name, segment_name || ':' || partition_name) objectname,
                 segment_type object_type, ROUND (bytes / 1024 / 1024, 2) mb, owner
            FROM dba_segments
           WHERE tablespace_name LIKE '%_DATA' --:tname
        ORDER BY mb DESC)
 WHERE mb > 1000
/

```

## Les statistiques 


### Export/import des statistiques 

```Sql
EXEC DBMS_STATS.drop_stat_table(user,'STAT_TABLE');
EXEC DBMS_STATS.create_stat_table(user,'STAT_TABLE_MGARV');
EXEC DBMS_STATS.export_schema_stats(user,'STAT_TABLE',NULL,user);
SELECT * FROM stat_table;
EXEC DBMS_STATS.import_schema_stats(user,'STAT_TABLE',NULL,user,force=>true);
EXEC DBMS_STATS.unlock_schema_stats(user);

EXEC DBMS_STATS.lock_table_stats(user,'MGART');


EXEC DBMS_STATS.export_table_stats(user,'MGARV',stattab=>'STAT_TABLE_MGARV');
EXEC DBMS_STATS.import_table_stats(user,'MGART',stattab=>'STAT_TABLE',force=>true);

select * from ALL_PART_COL_STATISTICS;
select * from stat_table_mgarv;
select * from user_stats;


```

### Connaitres les tables qui ont leur stats de verrouillées

<br> Sur le schémas courant 

```Sql
select table_name, stattype_locked
from user_tab_statistics
where stattype_locked is not null; 
```


### Connaitres les ressources utilisées (nbre de processe,sessions/transaction)

Oracle intermittently throws “ORA-12516, TNS:listener could not find available handler with matching protocol stack”

```Sql
show parameter processes


SELECT *
  FROM v$resource_limit
 WHERE resource_name IN ('processes', 'sessions', 'transactions');
 ```
 

 
### Connaitres les infos et status du listener Oracle

Sous Linux, lancer l'utilitaire du listener
```bash
lsnrctl
``` 
On obtient alors 
```Bash 
LSNRCTL for Linux: Version 11.2.0.4.0 - Production on 31-MARS -2017 10:20:16

Copyright (c) 1991, 2013, Oracle.  All rights reserved.

Bienvenue dans LSNRCTL, tapez "help" pour plus d'informations.

LSNRCTL> status


``` 

On obtient alors toute les informations sur l'activité et l'état du listener
