+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Manipulation chaine"
author="Timothé Clavier"

[menu.main]
identifier = "SQL-7-Manipulation chaine"
parent ="SQL-1-SQL"
+++
Auteur:  
Date: 12/09/2016

---------------

```Sql 

SELECT COLUMN_VALUE AS id_alpha
         FROM THE (SELECT CAST (mlib_string.str2table ('a,b,c,d,e,f,g,h,i,j', ',') AS typ_mlib_t_varchar)
                     FROM DUAL);


/**************************************************
 * Transformer une ligne en colonne 
 * (Methode 2 :  non utilisation de la pseudo colonne THE) 
 **************************************************
 */
SELECT COLUMN_VALUE AS id_alpha
         FROM TABLE (CAST (mlib_string.str2table ('a,b,c,d,e,f,g,h,i,j', ',') AS typ_mlib_t_varchar));


/**************************************************
 * Transformer une ligne en colonne 
 * (Methode 3 :  utilisation de connect by) 
 * ATTENTION !! cette méthode est consommatrice en CPU
 **************************************************
 */
 SELECT     TRIM (SUBSTR (txt,
                               INSTR (txt,
                                      ',',--  <-- delim
                                      1,
                                      LEVEL
                                     ) + 1,
                                 INSTR (txt,
                                        ',',--  <-- delim
                                        1,
                                        LEVEL + 1
                                       )
                               - INSTR (txt,
                                        ',',--  <-- delim
                                        1,
                                        LEVEL
                                       )
                               - 1
                              )) AS token
            FROM (SELECT ',' || 'a,b,c,d,e,f,g,h,i,j' || ',' txt  --  <-- delim ici aussi 
                    FROM DUAL)
      CONNECT BY LEVEL <= LENGTH ('a,b,c,d,e,f,g,h,i,j') - LENGTH (REPLACE ('a,b,c,d,e,f,g,h,i,j',
                                                              ',',
                                                              ''
                                                             )) + 1;
                                     


/**************************************************
 * Transformer une ligne en colonne 
 * (Methode 4 :  utilisation de connect by et expression reguliere) 
 * ATTENTION !! cette méthode est consommatrice en CPU
 **************************************************
 */

SELECT     REGEXP_SUBSTR ((';' || 'a;b;c;d;e;f;g' || ';'),
                          '[^;]+',
                          1,
                          LEVEL
                         )
      FROM DUAL
CONNECT BY REGEXP_SUBSTR ((';' || 'a;b;c;d;e;f;g' || ';'),
                          '[^;]+',
                          1,
                          LEVEL
                         ) IS NOT NULL;                                     
                                                             

/**************************************************
 * Transformer une ligne en colonne 
 * (Methode 5 :  utilisation de OdciNumberList/OdciVarchar2List/OdciDateList) 
 * Utilisation en dynamique ou en static mais il faut 
 * Que les valeurs soient séparés par des virgules
 * Exemple : 1,2,3 pour des nombres
 *           '1','2','3' pour des alpha
 **************************************************
 */

 SELECT COLUMN_VALUE AS RESULT
  FROM TABLE (SYS.odcivarchar2list ('a',
                                    'b',
                                    'c'
                                   ));

SELECT COLUMN_VALUE AS RESULT
  FROM TABLE (SYS.odcinumberlist (1,
                                  2,
                                  3
                                 ));

SELECT   COLUMN_VALUE AS RESULT
    FROM TABLE (SYS.odcidatelist (TO_DATE ('01/12/2015', 'DD/MM/YYYY'),
                                  TO_DATE ('01/11/2015', 'DD/MM/YYYY'),
                                  TO_DATE ('01/12/2014', 'DD/MM/YYYY')
                                 ))
ORDER BY 1;




/**************************************************
 * Transformer une ligne en colonne 
 * (Methode 6 :  utilisation de plsql )
 * 
 **************************************************
 */

DECLARE
   CURSOR c_art
   IS
      SELECT art_noart
        FROM mgart;

   l_buffer     CLOB;
   nb_data      NUMBER := 0;
   v_nobuffer   NUMBER;
BEGIN
   FOR i IN c_art
   LOOP
      l_buffer := l_buffer || ';' || i.art_noart;
      nb_data := nb_data + 1;
      EXIT WHEN LENGTH (l_buffer) > 32760;
   END LOOP;

   DBMS_OUTPUT.put_line ('lg=> ' || LENGTH (l_buffer) || ' pour ' || nb_data || ' article ');
   mlib_util.load_gtt_util (pi_buffer        => l_buffer,
                            pi_token         => ';',
                            pi_mode_a_n      => 'N',
                            po_nobuffer      => v_nobuffer
                           );
END;
/

SELECT COUNT (*)
  FROM gtt_util_number;




/**************************************************
 * Transformer une ligne en colonne 
 * (Methode 7 :  utilisation de XMLTABLE )
 * 
 **************************************************
 */


-- Note : il faut remplacer le token par "," et encapsuler la data par " (guillemet)
WITH my_data
     AS (SELECT noligne AS vue_noligne,
                '"' || REPLACE ('a;b;c;d;e;f;g', ';', '","') || '"' AS liste
           FROM gtt_tran_impo_rer_mgsaco_v7)
SELECT TRIM (COLUMN_VALUE) AS result
  FROM my_data, XMLTABLE (liste);
  

/**************************************************
 * Transformer une ligne en colonne 
 * (Methode 8 :  utilisation de la clause MODEL )
 * un poil compliqué 
 * le token est ici le car. * 
 **************************************************
 */

WITH model_param
     AS (SELECT inf_cdmag, inf_noart, inf_lsraljou AS orig_str,
                '*' || inf_lsraljou || '*' AS mod_str, 1 AS start_pos,
                LENGTH (inf_lsraljou) AS end_pos,
                (LENGTH (inf_lsraljou) - LENGTH (REPLACE (inf_lsraljou, '*'))) + 1 AS element_count,
                0 AS element_no, ROWNUM AS rn
           FROM mginfo
          WHERE inf_lsraljou IS NOT NULL)
  SELECT inf_cdmag, inf_noart, TRIM (SUBSTR (mod_str, start_pos, end_pos - start_pos)) inf_lsraljou
    FROM (SELECT *
            FROM model_param
          MODEL
             PARTITION BY (inf_cdmag, inf_noart, rn, orig_str, mod_str)
             DIMENSION BY (element_no)
             MEASURES (start_pos, end_pos, element_count)
             RULES
                ITERATE (2000) UNTIL (ITERATION_NUMBER + 1 = element_count[0])
                (start_pos [ITERATION_NUMBER + 1] =   INSTR (CV (mod_str),
                                                             '*',
                                                             1,
                                                             CV (element_no))
                                                    + 1,
                end_pos [ITERATION_NUMBER + 1] = INSTR (CV (mod_str),
                                                        '*',
                                                        1,
                                                        CV (element_no) + 1)))
   WHERE element_no != 0
ORDER BY mod_str, element_no
/



 /**************************************************
 * Exemple avec une table en jointure
 * Note : ici la colonne ins_lsraljou est continuée ainsi : 
 * 1ere partie (séparée par "*" ): une chaine alpha 
 * 2eme partie (séparée par ";" ): 2 champs <Date Livraison> et <qté ral>
 * Soit  <Date Livraison>;<qté ral>* 
 *
 * Exemple : 
 * 05/02/2013;0*05/02/2013;0*05/02/2013;0*05/02/2013;0*14/02/2013;0*
 **************************************************
 */
SELECT   inf_cdmag, inf_noart, SUM (mlib_string.strtoken (COLUMN_VALUE,
                                                          ';',
                                                          2
                                                         )) AS Result 
    FROM mginfo, TABLE (CAST (mlib_string.str2table (inf_lsraljou || '*', '*') AS typ_util_char))
   WHERE inf_lsraljou IS NOT NULL
GROUP BY inf_cdmag, inf_noart;

                
   
 /**************************************************
 * Exemple avec une table en jointure et methode XMLTABLE
 * Note : Meme principe que precedemenet
 **************************************************
 */
  WITH my_data
     AS (SELECT inf_cdmag, inf_noart,
                '"' || TRIM (REPLACE (inf_lsraljou, '*', '","')) || '"' AS inf_lsraljou
           FROM mginfo
          WHERE inf_lsraljou IS NOT NULL)
SELECT inf_cdmag, inf_noart, TRIM (COLUMN_VALUE) AS r
  FROM my_data, XMLTABLE (inf_lsraljou);
  
															 
/**************************************************
 * Transformer des colonnes en lignes 
 * ATTENTION !! Listagg est limite en taille (4000 car.)!!!! 
 * Utiliser l'astuce rownum
 * LISTAGG ignore les valeurs null
 **************************************************
 */
SELECT LISTAGG(EAN_CD, ';') 
        WITHIN GROUP (ORDER BY EAN_NOART) AS result
FROM mgean 
WHERE ROWNUM<100;

--====================================
-- Avec l'astuce de limitation 
--====================================
SELECT LISTAGG(CASE WHEN ROWNUM<100 THEN 
					EAN_CD
				ELSE
					NULL
				END, ';') 
        WITHIN GROUP (ORDER BY EAN_NOART) AS result
FROM mgean;


--====================================
-- Supprimer les doublons 
-- Necessite de mettre les colonnes dans le group by 
-- Methode 1 
--====================================
SELECT UNIQUE ray_cdr,LISTAGG(fam_flmajsto, ';') 
        WITHIN GROUP (ORDER BY ray_cdr,fam_flmajsto) over (partition by ray_cdr) AS result
FROM mgray, mgfam
WHERE fam_cdr=ray_cdr 
GROUP BY ray_cdr,fam_flmajsto
ORDER BY ray_cdr;


--====================================
-- Supprimer les doublons 
-- Necessite de mettre les colonnes dans le group by 
-- Methode 2 (avec une sous-requete)
--====================================
SELECT ray_cdr,listagg(fam_flmajsto,',')WITHIN GROUP (ORDER BY RAY_CDR) as R
  FROM (SELECT   ray_cdr, fam_flmajsto,
                 ROW_NUMBER () OVER (PARTITION BY ray_cdr, fam_flmajsto ORDER BY ray_cdr,
                  fam_flmajsto NULLS LAST) AS pos
            FROM mgray, mgfam
--   WHERE fam_cdr = ray_cdr -- ici FULL cartesien juste pour le test
        ORDER BY ray_cdr, pos)
 WHERE pos = 1
 group by ray_cdr;


WITH my_data
AS (
    SELECT LISTAGG(EAN_CD, ';') 
        WITHIN GROUP (ORDER BY EAN_NOART) AS result
    FROM mgean WHERE ROWNUM<100
    )
SELECT COLUMN_VALUE AS ean
         FROM my_data,
             TABLE (
                    CAST (
                           mlib_string.str2table (result, ';') AS typ_mlib_t_varchar
                         )
                   );
                   
                   
															 
 /**************************************************
 * Exemple avec la fonction COLLECT* 
 **************************************************
 */
SELECT *
  FROM (SELECT   ray_cdr,
                 mlib_string.tab_to_string
                    (CAST
                        (COLLECT (UNIQUE CAST (fam_flmajsto AS VARCHAR2 (1))) AS typ_mlib_t_varchar))
                                                                                               AS r
            FROM mgray, mgfam
           WHERE fam_cdr = ray_cdr
        GROUP BY ray_cdr);
        


 /**************************************************
 * Exemple avec la fonction XML * 
 **************************************************
 */
SELECT   ray_cdr,
         RTRIM (XMLAGG (XMLELEMENT (Ma_COLONNE, fam_cdf || ',') ORDER BY ray_cdr).EXTRACT ('//text()'),
                ',') AS r
    FROM mgray, mgfam
   WHERE fam_cdr = ray_cdr
GROUP BY ray_cdr;


/**************************************************
 * Exemple avec SYS_CONNECT_BY * 
 **************************************************
 */
SELECT     ray_cdr, LTRIM (SYS_CONNECT_BY_PATH (fam_cdf, ','))
      FROM (SELECT ray_cdr, fam_cdf,
                   ROW_NUMBER () OVER (PARTITION BY ray_cdr ORDER BY fam_cdf) AS pos
              FROM mgray, mgfam
             WHERE ray_cdr = fam_cdr)
     WHERE CONNECT_BY_ISLEAF = 1
CONNECT BY pos = PRIOR pos + 1 AND ray_cdr = PRIOR ray_cdr
START WITH pos = 1;

 /**************************************************
 * Exemple avec un fonctiojn objet
 **************************************************
 */

-- Trop lent (avec stragg de Tom Kyte)
                   
                   
```