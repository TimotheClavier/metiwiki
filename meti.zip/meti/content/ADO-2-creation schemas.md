+++
date="2017-05-16T15:12:23+02:00"
draft="true"
title="Creation Schemas"
author="Timothé Clavier"

[menu.main]
identifier="ADO-2-Creation Schemas"
parent="ADO-1-Administration Oracle"
+++
Auteur:  
Date: 04/10/2016

--------------------

### [DataPump](http://wikiora.com/index.php?option=com_content&view=article&id=88:datapump-manager-les-donnees-sqlplsql&catid=46:chapitre-9&Itemid=62)

## Installation d'un schémas Oracle
 
### Création d'un tableSpace


```Sql 
CREATE BIGFILE TABLESPACE <SCHEMAS_ORACLE>_DATA DATAFILE
  '+DATA' SIZE 276M AUTOEXTEND ON NEXT 256M MAXSIZE 32768M
LOGGING
ONLINE
EXTENT MANAGEMENT LOCAL AUTOALLOCATE
BLOCKSIZE 8K
SEGMENT SPACE MANAGEMENT AUTO
FLASHBACK ON;
```

### Création d'un user Oracle 

```Sql
CREATE USER <SCHEMAS_ORACLE>
  IDENTIFIED BY ATTENT1
  DEFAULT TABLESPACE <SCHEMAS_ORACLE>_data
  TEMPORARY TABLESPACE <TABLESPACE_TEMP>
  PROFILE DEFAULT
  ACCOUNT UNLOCK;
  -- 2 Roles for <SCHEMAS_ORACLE>
GRANT CONNECT TO <SCHEMAS_ORACLE>;
GRANT RESOURCE TO <SCHEMAS_ORACLE>;
  ALTER USER <SCHEMAS_ORACLE> DEFAULT ROLE ALL;
  -- 3 System Privileges for <SCHEMAS_ORACLE>
GRANT CREATE SYNONYM TO <SCHEMAS_ORACLE>;
GRANT CREATE VIEW TO <SCHEMAS_ORACLE>;
REVOKE UNLIMITED TABLESPACE FROM <SCHEMAS_ORACLE>;
ALTER USER <SCHEMAS_ORACLE> QUOTA UNLIMITED ON <SCHEMAS_ORACLE>_data;

```
<br>Savoir si les quotas sont activés pour un <i>user</i>
```Sql
select * from dba_ts_quotas where username='<SCHEMAS_NAME>';
```

### Importer un dump

- Si on connait pas le contenu du dump 

```Sql 
 impdp etudes/etudes dumpfile=<Nom_du_dump> LOGFILE=<nom_du_fichier_log>.log sqlfile=ddl_dump.txt
```
```shell
grep "CREATE USER" ddl_dump.txt
```
- on obtient la liste des users contenu dans le dump

```
CREATE USER "VITANTIS" IDENTIFIED BY VALUES 'S:9ADEE6534D5FCD09F1A248249CC23A07D0DE7D0434B97C661E6543C920BA;289159D630932E3F'
```


#### Import du dump  

- contenu du parfile 

```
DIRECTORY=DATA_PUMP_DIR 
transform=storage:n 
QUERY=MGFLD:"WHERE rownum<1" 
QUERY=MGFLE:"WHERE rownum<1" 
QUERY=MGRAI:"WHERE rownum<1" 
SCHEMAS=<SCHEMAS_ORACLE>
DUMPFILE=<NOM_DU_DUMPE>.dmp
LOGFILE=<NOM_DU_LOG>.log
```
puis lancement de la commande suivante : 

```
impdp etudes/etudes@ME01 parfile=parfile
```

#### Paramétrage divers

- Exclure/inclure des objets

<br>La vue <i><b>schema_export_objects</b></i> permet de visualiser l'ensemble des objets pouvant être exlcus/inclus du datapump

<i><u>Exemple</u></i>
```Bash
EXCLUDE=GRANT,SYNONYM,PACKAGE,TRIGGER
EXCLUDE=INDEX:"LIKE '%ART%'"
```

### Exporter un dump

- Pour que le dump soit compatible avec une version Oracle :
<br>Rajouter dans le parfile la directive suivante :
```Txt
VERSION=11.2.0.2
```


### Divers

- <b>Arrete le job en cours : </b>
<br>
<br> de manière propre (CTRL+D sur l'export/import en cours)
```Sql
-- au prompt de l'export/import
kill_job;
```

- <b>Verrouiller/Déverrouiller un compte oracle : </b>

<br> Sous le compte <i>system</i>
```sql 
ALTER USER username ACCOUNT LOCK;
ALTER USER username ACCOUNT UNLOCK;
```
- <b>Erreur Oracle type ORA-31626 (job does not exist)</b>

<br> Depuis la version 11.2.0.4, il est important de positionner le paramètre oracle <i><b>streams_pool_size</b></i> à 128 Mo 
<br>pour que l'utilitaire Datapump (impdp/expdp) fonctionne

<br> si l'import datapump est très lent (avec <b>wait event</b><i>Streams AQ: enqueue blocked on low memory</i>), il faut aussi le faire     
     

```Sql
	-- Compte SYS ( as SYSDBA)
    ALTER SYSTEM SET streams_pool_size=128M SCOPE=spfile;
    -- redemarrage de la base
    shutdown
    startup
    
```

- <b> Exit Code : </b>
http://docs.oracle.com/cd/E11882_01/server.112/e22490/dp_overview.htm#SUTIL3834