+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Drop des objets Oracle"
author="Timothé Clavier"

[menu.main]
identifier = "NORM-2-Drop des objets Oracles"
parent ="NORM-1-Normes"
+++
Auteur:  
Date: 25/08/2016

---------------

### Normes de suppression/création des objets Oracle dans les scripts (patch / svn)

#### 1 - Suppression des tables (GTT/WRK)

```Sql
SET serveroutput on;

DECLARE
   e_942   EXCEPTION;
   PRAGMA EXCEPTION_INIT (e_942, -942);
BEGIN
   EXECUTE IMMEDIATE 'drop table <MA_TABLE>';

   DBMS_OUTPUT.put_line ('Table Supprimée');
EXCEPTION
   WHEN e_942
   THEN
      NULL;
END;
/
SET serveroutput off;

```
#### 2 - Suppression des Synonymes

```Sql 
SET serveroutput on;

DECLARE
   e_1434   EXCEPTION;
   PRAGMA EXCEPTION_INIT (e_1434, -1434);
BEGIN
   EXECUTE IMMEDIATE 'DROP SYNONYM <Mon_Objetc>';

   DBMS_OUTPUT.put_line ('Synonyme Supprimée');
EXCEPTION
   WHEN e_1434
   THEN
      NULL;
END;
/

SET serveroutput off;

```

#### 3 - Suppression des indexes 

```Sql 
SET serveroutput on;

DECLARE
   e_1418   EXCEPTION;
   PRAGMA EXCEPTION_INIT (e_1418, -1418);
BEGIN
   EXECUTE IMMEDIATE 'DROP INDEX <Min_INDEX>';

   DBMS_OUTPUT.put_line ('Indexe Supprimé');
EXCEPTION
   WHEN e_1418
   THEN
      NULL;
END;
/

SET serveroutput off;

```

#### 4 - Creation des sequences

<br>ATTENTION A la norme des sequence !!!
<b>S_TABLE_COLONNE</b>
<br><u><i>Exemple : </i></u>
<br> S_MGPFA_NOLETTRA pour la colonne MGPFA.PFA_NOLETTRA

```Sql
SET SERVEROUTPUT ON;

DECLARE
   e_955   EXCEPTION;
   PRAGMA EXCEPTION_INIT (e_955, -00955);
BEGIN
   EXECUTE IMMEDIATE
      'CREATE SEQUENCE <MA_SEQUENCE> INCREMENT BY 1 START WITH 10 MAXVALUE 9999999 MINVALUE 10 CYCLE NOCACHE';

   DBMS_OUTPUT.put_line ('Succes de l''element CREATE SEQUENCE.');
EXCEPTION
   WHEN e_955
   THEN
      NULL;
END;
/

SET SERVEROUTPUT OFF;
```