+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Plugging"
author="Timothé Clavier"

[menu.main]
identifier = "SQLDEV-2-Plugging"
parent ="SQLDEV-1-SQL Developpeur"
+++
Auteur:  
Date: 11/05/2017

---------------

# analyseur de code

- Il existe un plugging permettant l'analyse de code PL/SQL à l'instar de l'utilitaire PLSQL WARNING.

- Télécharger le plugging [ici](http://lxdev03:3004/resources/sql_developper/TVDCC_for_SQLDev-2.0.1.zip)

### Paramétrage du plugging

1- Dans Sql Développer aller dans le menu aide/Rechercher les mises à jour ... 

![Menu plugging1](http://lxdev03:3004/resources/sql_developper/SQL_Developer_plugging1.jpg)

2- Sélectionner ensuite "installer à partir d'un fichier local" 
![Menu plugging2](http://lxdev03:3004/resources/sql_developper/SQL_Developer_plugging2.jpg)

3- Sélectionner le fichier télécharger précédemment
![Menu plugging3](http://lxdev03:3004/resources/sql_developper/SQL_Developer_plugging3.jpg)

4- redémarrer SQL Developper


### Utilisation du plugging

1- Sur un code SQL ou sur un package : clique Droit de la souris 

![Menu plugging4](http://lxdev03:3004/resources/sql_developper/SQL_Developer_plugging4.jpg)

2- Sur la fenêtre du bas vous obtenez la liste des recommandations et certaines métrique (onglet <b>Issues</b> et <b>Report</b>

![Menu plugging4](http://lxdev03:3004/resources/sql_developper/SQL_Developer_plugging5.jpg)