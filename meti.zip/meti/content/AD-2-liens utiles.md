+++
date="2017-05-16T15:12:23+02:00"
draft="true"
title="liens utiles"
author="Timothé Clavier"
content="liens utiles"


[menu.main]
identifier="AD-2-Liens utiles"
parent="AD-1-Administration"

+++
Auteur:  
Date: 21/09/2016

-------------

## Interne 
- [Saisie des temps/points](http://metisp.meti.fr)

- [Recherche document](http://lxdev03:8000/)

- [Annuaire téléphonique](http://10.29.1.241/annuaire/)

- [Portail Meti](http://intranet.meti.fr/)

- [Site Meti](http://www.meti.fr) 

- [Pegase Pwa](https://pwa.meti.fr/pwa)

- [Messagerie (Zimbra)](https://zimbra.meti.fr)

- [Dépôt SVN de Documentation](http://lxdev01.meti.fr:8080/docs/trunk/)
    
- [Dépôt SVN de Développement](http://lxdev01.meti.fr:8080/metidev/trunk/)

- [Trombinoscope : \\\mfnas01\Commun\Documentations METI\connaissance entreprise\](file:///mfnas01/Commun/Documentations%20METI/connaissance%20entreprise/)

- [http://www.cemeti.org/](http://www.cemeti.org/)

- MLR : \\\magic1\ma7\doc\MLR\

- [CE : Fichier de commande hebdomadaire (pour le spécif spectacle/bateau etc...) T:\Comite Entreprise\ASC\CommandesCE\CEZAM ](file:///T:/Comite%20Entreprise/ASC/CommandesCE/CEZAM)  

    * Les commandes seront envoyées à Cezam le mardi et récupérées pour le vendredi (sous réserve de disponibilité à Cezam)
	* Pour la billetterie habituelle il n'y aura pas de changement (CGR/piscine/squash etc).
	* Pour les commandes spécifiques (spectacle/bateau etc), vous pouvez nous faire vos commandes via ce fichier.


## Formulaires 
### Modèle
- [http://lxdev01:8080/docs/trunk/NORM_Normes/NORMES_demande_modif_modele.odt](http://lxdev01:8080/docs/trunk/NORM_Normes/NORMES_demande_modif_modele.odt)

### Rec11/Mag11
- [http://lxdev01:8080/docs/trunk/POLE_Edition/moe_emag/Projet/Formulaire_de_demande_de_schema.odt ](http://lxdev01:8080/docs/trunk/POLE_Edition/moe_emag/Projet/Formulaire_de_demande_de_schema.odt)

### Analyse specification
- [http://lxdev01:8080/docs/trunk/NORM_Normes/Modeles/MODELE_specifications.ott](http://lxdev01:8080/docs/trunk/NORM_Normes/Modeles/MODELE_specifications.ott)

### Astreinte
- [\\\mfnas01\Commun\Documentations METI\imprimes](file://mfnas01/Commun/Documentations%20METI/imprimes/)

- [![an image](/image)](/file)
^D
<p><a file://////mfnas01/Commun/Documentations%20METI/imprimes/></a>
</p>

## Techniques
### Archives ancien arrete Magic
- [\\\mfnas01\Services\Etudes\Versions\versions_MA7\arrete](file://mfnas01/Services/Etudes/Versions/versions_MA7/arrete/)

### VM
- [\\\mfnas01\Commun\Documentations technique\recette_vmware\](file://mfnas01/Commun/Documentations technique/recette_vmware/)

### GLPI
- [http://helpdesk.meti.fr](http://helpdesk.meti.fr)
- Création d'un ticket : 
  
  Deux méthodes possibles pour créer une demande interne :
	* par l'envoi d'un mail à l'adresse suivante <B>interne@support.meti.fr</B> : 
	<BR>le demandeur, ainsi que les personnes en copie du mail, seront notifiées par mail lors de l'ouverture et de la résolution du ticket.
    * via l'interface GLPI, en choisissant le profil client et créer un ticket (symbole +). 
	<BR>Le demandeur, ainsi que les personnes ajoutées en tant qu'observateur au ticket, seront notifiées par mail lors de l'ouverture et de la résolution du ticket.

- Accéder rapidement à un ticket
	* Se positionner sur un ticket et modifier le numéro du ticket dans l'URL.
	* A partir d'une notification, cliquer sur le lien présent dans le corps du mail.

- [Résolution d'un ticket](/resources/glpi/GLPI_Resolution_d_un_ticket.pdf)
- [Envoi de mail quand et a qui](/resources/glpi/GLPI_Envoi_de_mail_Quand_et_A_qui.pdf)
- [Cycle de vie d'un ticket](/resources/glpi/GLPI_Cycle_de_vie_d_un_ticket.pdf)
- <u>Evolution sur la gestion GLPI (7 mars 2016)</u>

```Bash
Bonjour à tous,

Pour information, avec Nicolas et François, nous avons initié des travaux autour de l'utilisation de GLPI dans le but d'améliorer le traitement des tickets à destination des équipes "techniques".

Entre autres actions, il ressort 3 changements ou rappels sur les bonnes pratiques pour les personnes qui créent ou escaladent des tickets aux équipes Système et DBA (équipe client et support technique principalement).
Certains points s'appliquent d'ailleurs à tous les tickets qu'ils soient techniques ou non.

1) Affecter le ticket au bon client

Nous avons initié un fichier de référence de tous les clients en production, qui reste à enrichir :
\\mfnas01\Documentation Clients\Production_Meti_v1.0.xlsx

Le nom et le code du client sont normalement les mêmes que dans GLPI.
Le fichier donnera, une fois enrichi, quelques informations sur les périmètres de responsabilité (et donc vers qui escalader le ticket).
N'hésitez pas à revenir vers moi pour corriger/compléter les informations.

Il y a encore beaucoup de tickets affecté à l'entité "1 - Meti".
A partir d'aujourd'hui, pour les nouvelles créations de tickets :
-Les tickets de demande de VM de recette doivent dorénavant être créées sur l'entité du client.
-Pour les clients gérés par Meti Roumanie, les tickets doivent tous être créés (ou rester) dans le GLPI Roumanie. Les équipes transverses ont les outils nécessaire pour travailler de la même façon dans les deux GLPI

Les seuls tickets restant attribués au client "1 Meti" doivent être les demandes purement internes (poste individuel, téléphonie, etc...)

2) "Entité projet" pour les qualification

Une entité "projet" va être créée prochainement pour les clients qui n'en disposent pas encore (travaux terminés fin de cette semaine).
Tous les tickets (incidents ou demandes) qui ne concernent pas la production doivent être créés dans l'entité "projet".
Cela permet en particulier de distinguer si un appel concerne un environnement de production ou de qualification, et également de ne pas fausser les statistiques des incidents de production.

3) Décrire le plus précisément possible le problème 

Incident ou demande / urgence et impact : Pour permettre de gérer aux mieux les priorités et les urgences merci de renseigner au mieux ces informations.
En particulier le type "demande" ou "incident" est très important.
Les demandes correspondent :
- soit à des demandes de service ponctuelles (ex: ajout d'un utilisateur, d'un droit, etc...)
- soit à des projets plus conséquents (typiquement création d'environnements), elle sont dans ce cas souvent classées dans une "entité projet"

Avec la croissance de l'entreprise, les équipes transverses ne peuvent plus être au fait de l'évolution du contexte de chaque client.
Pour permettre de traiter les tickets dans les meilleures conditions, il faut donner un maximum d'informations sur le "problème".
Si le ticket est créé par le client, n'hésitez pas à poser les questions lors de la qualification N1, N2 ou N3 fonctionnel.

Pour vous guider, vous pouvez vous appuyer sur la liste de questions génériques ci-dessous :

Environnement/site impacté :
Les problèmes rencontrés concernent-ils bien des environnements en production ?
Serveurs / grappes impactés :
o  Tous ou certains seulement
o  Noms et IP des serveurs
o   Infos de connexion
 
Description résumé du problème :
-       Qui / quoi / quand ?
-       Y-a-t-il des messages d’erreurs ?
o   Si oui, où retrouver ces messages ? (fichier de log ?)
-       L’erreur est-elle reproductible ? Si oui, comment la reproduire ?
 
Description de l’impact fonctionnel :
-       L’impact concerne-t-il tous les utilisateurs ? 
-       La connexion aux environnements systèmes est-elle disponible ?
o   Si non quels sont les serveurs non joignables ?
-       Quelle(s) application(s) est (sont) impactée(s) ?
o   Quelle(s) fonctionnalité(s) de cette (ces) application(s) sont impactées ?
 
Contexte opérationnel :
-       Y-a-t-il eu des modifications sur le serveur/site récents qui pourraient causer le problème :
(ex: mise à jour applicative, changement de configuration, intervention par le client ou hébergeur, ...)
-       L’heure à laquelle se produit le problème correspond-il à une action en exploitation (traitement ? backup ? envoi ou réception de flux ? autre tâche planifiée ?)
 
Historique lié à cet incident :
-       Ce problème a-t-il déjà été rencontré sur ce site ?
o   Si oui, associez le ticket correspondant dans GLPI
```