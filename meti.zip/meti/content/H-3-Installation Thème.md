+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Installation Thème Hugo"
author="Timothé Clavier"

[menu.main]
identifier = "H-3-Installation Thème"
parent ="H-1-Hugo"
+++
Auteur: Timothé Clavier 
Date: 19/05/2017

---------------



# __Mode opératoire installation d’un thème pour un site Hugo__

Avant de commencer à installer un thème assurer d’avoir installer Hugo sinon allez
consulter le mode opératoire d’installation d’Hugo.

## __1.Téléchargement__

Ouvrez git bash et à l’aide de la commande __$ cd__, placez vous dans le répertoire où votre site a été crée.

Maintenant rendez-vous sur le site de hugo pour choisir un thème, une fois votre thème choisit, cliquer sur le bouton de téléchargement, vous arrivez
sur une page github et à droite sur le bouton clone or download un lien apparaît.
Dans git bash entrez la commande __$ git clone « puis le lien »__

Si le téléchargement ne se lance pas c’est que le pare feu ne le permet pas alors
dans ce cas télécharger l’archive sur github et décompresser la dans le dossier thème de votre site.



## __2.Lancement__


Pour lancer votre site maintenant vous allez utiliser la commande

	$ hugo server --theme=votre_nom_de_thème –buildDrafts

Ensuite rendez-vous à l’adresse __[Localhost:1313](localhost:1313)__