+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Divers"
author="Timothé Clavier"

[menu.main]
identifier = "O-2-Divers"
parent ="O-1-Oracle"
+++
Auteur:  
Date: 11/05/2017

---------------
[Sql patterns_12c_1965433.pdf](http://lxdev03:3004/resources/oracle/Sql%20patterns_12c_1965433.pdf)

[System-Global-Area.png](http://lxdev03:3004/resources/oracle/System-Global-Area.png)

[twp-best-practices-optimizer-stats-04042012-1577139.pdf](http://lxdev03:3004/resources/oracle/twp-best-practices-optimizer-stats-04042012-1577139.pdf)

[twp-best-practices-optimizer-stats-04042012-1577139.pdf](http://lxdev03:3004/resources/oracle/Understanding_Optimize_Statistics_1354477.pdf)

[Pool de connection](https://oracle-base.com/articles/11g/database-resident-connection-pool-11gr1)

[Rappel SQL Niv 1 (METI)](http://lxdev01:8080/docs/trunk/doc_formation_outils/Oracle/cours/formation_sql_niv_1.odt)