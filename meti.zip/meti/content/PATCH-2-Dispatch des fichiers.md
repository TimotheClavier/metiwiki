+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Dispatch des fichiers"
author="Timothé Clavier"

[menu.main]
identifier = "PATCH-2-Dispatch des fichiers"
parent ="PATCH-1-Patch"
+++
Auteur:  
Date: 07/09/2016

---------------
# Dispatch des fichiers dans les Patch

|Repertoire |  Type de fichiers|
| ------------- |:-------------:|
|serveur_appli/prog	 |		JAR|
|serveur_edition/prog	|		ZIP|
|serveur_edition/traduction  |			emag_tradution.properties.default|
|serveur_bdd/dfap			|  fnc_dfap_comp + PKG DFAP|
|serveur_bdd/dfap/datas		|	export comp, menus …|
|serveur_bdd/dfap/traduction	 |		apmeti_trad.dmp|
|serveur_bdd/dfex	|		PKG DFEX|
|serveur_bdd/metimag/rfmeti		|	PKG, TYP, GTT, PRC ,FCT|
|serveur_bdd/metimag/data		|	DAT|
|serveur_bdd/metimag/all_schemas	 |		WRK, VUE, SEQ, TRG|
|serveur_bdd/metimag/all_schemas/dfap/grants		|	grant fnc_dfap_comp|
|serveur_bdd/metimag/all_schemas/dfap/synonyms	|		synonym fnc_dfap_comp|
|serveur_application/emag/job		|	CTL|
