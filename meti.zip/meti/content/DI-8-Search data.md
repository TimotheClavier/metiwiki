+++
date="2017-05-16T15:12:23+02:00"
draft="true"
title="Search Data"
author="Timothé Clavier"
[menu.main]

identifier="DI-8-Search Data"
parent="DI-1-Divers"

+++
Auteur:  
Date: 25/08/2016

----------------------
#### Recherche de schémas Oracle

- Script recherche de schémas avec des données précises

<br> Utile pour trouver un jeux de test
<br><u>Note :</u> 
<br> - modifier dans le script toutes les lignes sous <i>A - MODIFIER A CHAQUE RECHERCHE</i>       
<br> - Chaque table doit être préfixer par #SCHEMAS#
        
<br>Le script doit être exécuté sous un compte <b><i>SYSTEM</i></b>

```Sql 
set serveuroutput ON size 1000000
DECLARE
   CURSOR c_owner
   IS
      SELECT   owner
          FROM all_tables
         WHERE table_name = 'MGSOC'
      ORDER BY 1;

   TYPE refcur IS REF CURSOR;

   c_cursor_dyna   refcur;

   --<A MODIFIER A CHAQUE RECHERCHE>
   TYPE data_rec_type IS RECORD (
      notrait   NUMBER,
      nb        NUMBER
   );

   rec_data        data_rec_type;
   --<A MODIFIER A CHAQUE RECHERCHE>
   l_query         VARCHAR2 (32767)
      := '
        SELECT   fle_notrait, (SELECT COUNT (*)
                         FROM #SCHEMAS#.mgfld
                        WHERE fld_cdflux = fle_cdflux AND fld_notrait = fle_notrait) AS nb
        FROM #SCHEMAS#.mgfle
    WHERE fle_cdflux = ''CDE''
    ORDER BY 2 desc,fle_notrait DESC';
BEGIN
   FOR i IN c_owner
   LOOP
      OPEN c_cursor_dyna FOR REPLACE (l_query,
                                      '#SCHEMAS#',
                                      TRIM (i.owner)
                                     );

      LOOP
         FETCH c_cursor_dyna
          INTO rec_data;

         EXIT WHEN c_cursor_dyna%NOTFOUND;
         --<A MODIFIER A CHAQUE RECHERCHE>
         DBMS_OUTPUT.put_line (i.owner || ' notrait ' || rec_data.notrait || ' =>' || rec_data.nb);
      END LOOP;

      CLOSE c_cursor_dyna;
   END LOOP;
END;
/
```