+++
date="2017-05-16T15:12:23+02:00"
draft="true"
title="Serveur Multiversion"
author="Timothé Clavier"
[menu.main]

identifier="DI-9-Serveur Multiversion"
parent="DI-1-Divers"

+++
Auteur:  
Date: 31/01/2017

----------------------
### Accès
  - [http://lxdev03:8010/](http://lxdev03:8010/)
  - [adresse ip](http://lxdev03:3004/resources/metidev/DT__METI_MultiVersion_0001.pdf)
  - [dev_GUID_CheckList_dev.ods](http://lxdev03:3004/resources/metidev/dev_GUID_CheckList_dev.ods)
  - [Jasper (metiadm/metiadm)](http://vm902001.meti.fr:8090/jasperserver/flow.html?_flowId=searchFlow)
  
### Maj des patchs
  
  
#### journalière 

- Tous les <b>10</b> minutes de <b>8-18h</b> du lundi au vendredi (avec récupération des objets Oracle invalide)

- Recup des objets Oracle invalide : <b>6h45</b> et <b>12h45</b> du lundi au vendredi

#### hebdomadaire 

- Patch Full : <b>19h</b> le dimanche

- Archive des logs : <b>18h</b> le dimanche

#### mensuel 

Le 1er dimanche du mois 

- drop des schémas Oracle
- Installation de la version 
- Patch Full 

#### Log des maj 

- sous <b>lxdev01</b> répertoire <i>/meti/ora11g/multi_version</i>

	- Fichier liste_point.txt : Contient la liste des points devant être patché
    - répertorie <i>log</i> : Contientl'ensemble des logs des patch
    
#### Re-Lancer une vérif des compilations 
<br>Sous lxdev01 
```Bash
/home/metiadm/outil_dev/multi_version/outils/maj_serveur_multi_version.sh -c
```

#### Vérifier une erreur compilation avec récup des derniers Commit SVN Pour une Version 
<br> Sous lxdev01 : pour la version <i>901503</i>
```Bash
touch /tmp/rapport_compile_test.txt
/home/metiadm/outil_dev/multi_version/outils/get_svn.sh -j /tmp/rapport_compile_test.txt-v 901503 -t OUI
```

#### Erreur de patch d'un point
Erreur de version, de std/spécif, etc... avec comme symptôme un email qui vous spamme en précisant que le pt est en erreur

- sous <b>lxdev01</b> répertoire <i>/meti/ora11g/multi_version</i>

	- Fichier liste_point.txt : Contient la liste des points devant être patché
  - editer le fichier et supprimer la ligne concernant le pt ne devant plus être patché