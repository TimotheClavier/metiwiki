+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Debug"
author="Timothé Clavier"

[menu.main]
identifier = "PHP-2-Debug"
parent ="PHP-1-PHP"
+++
Auteur:  
Date: 25/08/2016

---------------
### Faire du pas à pas avec PHP et Visual Code

- Plugin vscode : https://github.com/felixfbecker/vscode-php-debug

F5 : Selectionner PHP pour créer un config automatiquement


- Config xdebug dans php.ini:

zend_extension = php_xdebug-2.4.0rc3-5.6-vc11-x86_64.dll

```Ini 
;;;;;;;;;;;;;;;;;;;
; Module Settings ;
;;;;;;;;;;;;;;;;;;;


[xdebug]
xdebug.remote_enable = 1
xdebug.remote_autostart = 1
xdebug.profiler_enable = 1
xdebug.profiler_output_dir = C:\Meti\xdebug_profile
xdebug.remote_log = C:\Meti\Apache24\logs
```
- Extension Chrome pour "l'autostart" du debuggage :
https://chrome.google.com/webstore/detail/xdebug-helper/eadndfjplgieldjbigjakmdgkmoaaaoc

Options IDE_KEY => XDEBUG_SESSION_START


- Ensuite mettre un breakpoint dans l'éditeur et voilà !