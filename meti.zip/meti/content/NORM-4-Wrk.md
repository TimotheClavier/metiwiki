+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Wrk"
author="Timothé Clavier"

[menu.main]
identifier = "NORM-3-Wrk"
parent ="NORM-1-Normes"
+++
Auteur:  
Date: 25/08/2016

---------------
### Normes des WRK 
- [Rappel de la doc NORM_tables_wrk.odt](http://lxdev01:8080/docs/trunk/Architecture/Normes/archi_NORM_tables_wrk.odt)

<br><u> 2 types de tables :</u> 
<br>
    Table <b>classique</b> (sans reprise de données hors idsession)
    <br>préfixe : <b>WRK\_</b>
    <br>Colonne wrk\_\_idsession obligatoire (en pk)
    <br>Colonne wrk__cduser facultatif (hors pk)
    <br>
    <br> Il n'y a pas de purge hormis l'idession dans les progs
    
<br>
    Table avec <b>reprise de données</b> (code user Obligatoire)
    <br>préfixe : <b>WRK\_R\_</b>
    <br>Colonne wrk__cduser obligatoire et en pk
    <br>
    <br>La purge de la table est <b><i>obligatoirement</i></b> réalisée par le prog qui l'utilise
    

- Colonne technique

```Sql 
	wrk__idsession    VARCHAR2(128) NOT NULL,
    wrk__cduser       VARCHAR2(10) NOT NULL,
    wrk__dtcrea       DATE DEFAULT TRUNC(SYSDATE) NOT NULL,
    wrk__ctl          VARCHAR2(10), 
```    


- WRK de type Reprise : préfixe <b>WRK\_R\_</b>

```Sql 
CREATE TABLE wrk_r_apro_invn_saisie_inv1
(
    wrk__cduser       VARCHAR2(10) NOT NULL,
    wrk_noligne       NUMBER NOT NULL,
    wrk_cdmag         NUMBER(6),
    wrk_noinvent      NUMBER(4),
    wrk_cdempl        CHAR(10),
    wrk__dtcrea       DATE DEFAULT TRUNC(SYSDATE) NOT NULL,
   CONSTRAINT pk_wrk_r_apro_invn_saisie_inv1 PRIMARY KEY (wrk__cduser,wrk_noligne)
)
/

```


- WRK classique (avec idsession) préfixe <b>WRK\_</b> :

```Sql 
CREATE TABLE wrk_apro_invn_saisie_inv1
(
    wrk__idsession    VARCHAR2(128) NOT NULL,
    wrk_noligne       NUMBER NOT NULL,
    wrk__cduser       VARCHAR2(10) NOT NULL,
    wrk_cdmag         NUMBER(6),
    wrk_noinvent      NUMBER(4),
    wrk_cdempl        CHAR(10),
    wrk__dtcrea       DATE DEFAULT TRUNC(SYSDATE) NOT NULL,
   CONSTRAINT pk_wrk_apro_invn_saisie_inv1 PRIMARY KEY (wrk__idsession,wrk_noligne)
)
/
CREATE INDEX i_wrk_apro_invn_saisie_inv1 ON wrk_apro_invn_saisie_inv1(wrk__cduser);

```