+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Divers"
author="Timothé Clavier"

[menu.main]
identifier = "SH-2-Divers"
parent ="SH-1-Shell"
+++
Auteur:  
Date: 15/03/2017

---------------
### Tester une commande sous Crontab

- Exemple avec <b>at</b>

Format de la commande  :

at -f <b><i>fichier de commande</i></b> -t <b><i>jour et heure dexecution</i></b>

avec  <b><i>fichier de commande</i></b> = rep+fichier cde shell

avec <b><i>jour et heure dexecution</i></b> = Annee/mois/jour/heure/min
    

<u><i>exemple</i></u>
<br> soit la script /tmp/test_script.sh a executer le 19/09/2019 a 15h30 

```Bash 
at -f /tmp/test_script.sh -t 201909191530
```

### Résumé sur les modes d'expansion des variables


```Bash 
${MYVAR#pattern}       # supprime le plus petit match du pattern à partir du début
${MYVAR##pattern}      # supprime le plus grand match du pattern à partir du début
${MYVAR%pattern}       # supprime le plus petit match du pattern à partir de la fin
${MYVAR%%pattern}      # supprime le plus grand match du pattern à partir de la fin
```

- \# signifie recherche les chaines à partir du début de la ligne
- %  signifie recherche les chaines à partir de la fin

- Si ce car (# ou %) est présent :
	- 1 fois cela signifie recherche la 1ere occurence
    - 2 fois cela signifie recherche la derniere occurence

Il est possible d'effectuer aussi des remplacemetn de chaine :
```Bash
${MYVAR/search/replace}
```
L'expression (pattern) à le meme format qu'une recherche de nom, donc * (any characters) est le plus utilisé, suivi par le symbole "/" ou "."

<u>Exemples:</u>

```Bash
MYVAR="/meti/sce/etudes/versions/patch/mlib/v902005.std.76031.txt" 
```
Extraire le nom du fichier (tous les car. jusqu'a slash):
```Bash
echo ${MYVAR##*/}
v902005.std.76031.txt
```
Supprimer le nom pour avoir le repertoire (suppression des car en partant par la fin jusqu'au 1er /):
```Bash
echo ${MYVAR%/*}
/meti/sce/etudes/versions/patch/mlib/
```
Récupérer l'extension du fichier (supprimer tous jusqu'a la derniere occurence):

```Bash
echo ${MYVAR##*.}
txt
```
Remarque : Il n'est pas possible de combiner 2 opérations. Pour cela, il faut passer par une variable intermédiaire.

<u>Exemple  :</u> Avoir le nom du fichier sans l'extension et le repertoire :
```Bash
NAME=${MYVAR##*/}      # suppression avant le dernier slash
echo ${NAME%.*}        # a partir de la nouvelle variable suprression de la partie après le dernier "."
v902005.std.76031
```
