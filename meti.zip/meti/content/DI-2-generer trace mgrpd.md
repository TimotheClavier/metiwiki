+++
date="2017-05-16T15:12:23+02:00"
draft="true"
title="Generer traces mgrpd"

[menu.main]

identifier="DI-2-Generer traces mgrpd"
parent="DI-1-Divers"

+++
Auteur:  
Date: 25/08/2016

----------------------

### Sélectionner les traces 

- [(télécharger le script pour l'utiliser dans Sql Déveloper)](/resources/divers/rpd_file.sql)


```Sql 
/*
 ***************************************************************
 * Script permettant de generer un fichier a partir des donnees MGRPD  
 * sous Sql Developer
 * (Ouvrir et enregistrer le fichier blob via SqlDeveloper )
 ****************************************************************
 */
 
-- Pour selectionner les traces 
SELECT  /*+ first */  rpe_cdidjob, rpe_cdtrait, rpe_cduseror, rpe_dtsoumis
    FROM mgrpe
   WHERE rpe_cddoss = USER
ORDER BY rpe_cdidjob DESC;

SELECT   rpd_hhrap, rpd_lbexplic
    FROM mgrpd
   WHERE rpd_cdidjob = 1854392   -- <== no trace mgrpd a modifier 
ORDER BY rpd_nointern;
```

### Générer un fichier de traces 

```Sql 

DECLARE
-- le parametre
--===================================================
   pe_cdidjob       mgrpd.rpd_cdidjob%TYPE             := 1854392;-- <== no trace mgrpd a modifier
--===================================================
   ot               typ_mlib_otrc;
   parametre_blob   gtt_xml_dummy.gtt_parametre%TYPE;
   nom_fichier      VARCHAR2 (100);
   le_blob          BLOB;

   CURSOR c_rpd
   IS
      SELECT   rpd_lbexplic
          FROM mgrpd
         WHERE rpd_cdidjob = pe_cdidjob
      ORDER BY rpd_nointern;

   TYPE l_rpd_tab_type IS TABLE OF c_rpd%ROWTYPE
      INDEX BY PLS_INTEGER;

   l_tab_rpd        l_rpd_tab_type;
   nb_data          NUMBER (9)                         := 0;
   -- buffer ligen a ecrire
   v_buffer         VARCHAR2 (32767);
BEGIN
--=============
-- Etape 1
--=============
--init de la table tempo
   mlib_trace.init_session;
   ot :=
      mlib_trace.cre_trc (pe_idtrace      => 0,
                          pe_nompkg       => 'test',
                          pe_version      => '1.0',
                          pe_nomproc      => 'rpd',
                          pe_type         => 'STD'
                         );
   util_iofile.init_blob_from_pl_table;
   --formatage du nom de fichier
   nom_fichier :=
         'test_2_'
      || TO_CHAR (SYSDATE, 'DDMMYY')
      || '_'
      || TO_CHAR (SYSDATE, 'HHMM')
      || '_'
      || TRIM (TO_CHAR (pe_cdidjob))
      || '.txt';
--=============
-- Etape 2
--=============
--formatage des parametres pour le module des transferts flux Magic
   parametre_blob :=
      util_iofile.formate_parametre_blob (pe_idtrace                         => ot.idtrace,
                                          pe_file                            => nom_fichier,
                                          pe_destinataire                    => NULL,
                                          -- facultatif mais je le mets ici pour indiquer que l'on peut preciser un destinataire
                                          pe_flg_histo_file                  => TRUE,
                                          -- indique que le fichier devra etre historiser sous rep ecriture + histo
                                          pe_flg_supp_file                   => TRUE,
                                          -- indique qu'il faut supprimer le fichier apres transfert (si c'est ok)
                                          pe_fle_notrait_etat_transfert      => 0,
                                          -- facultatif mais je le mets ici pour indiquer que le prog doit gerer un no traitement mgfle et doit passer le code etat a 22 ou 25 si le tranfert est ok
                                          pe_flg_sans_transfert              => FALSE
                                         --facultatif mais je le mets ici pour indiquer que le prog Magic ne doit pas faire de transfert
                                         );
--=============
--Etape  3  : Init du blob avec creation du 1ere enreg
--=============
   util_iofile.create_tempo_and_write2blob (le_blob,
                                            NULL,
                                            NULL
                                           );
--=======================================================
-- Extraction des donnees
--=======================================================
   nb_data := 0;

   OPEN c_rpd;

   <<loop_data>>
   LOOP
      FETCH c_rpd
      BULK COLLECT INTO l_tab_rpd LIMIT 1000;

      EXIT WHEN l_tab_rpd.COUNT = 0;

      FOR i IN l_tab_rpd.FIRST .. l_tab_rpd.LAST
      LOOP
         v_buffer := l_tab_rpd (i).rpd_lbexplic;
--=============
-- Etape 4 creation ligne du fichier
--=============
         util_iofile.write_append2blob (le_blob, v_buffer);
      END LOOP;

      nb_data := nb_data + l_tab_rpd.COUNT;
   END LOOP loop_data;

   CLOSE c_rpd;

--=============
-- Etape 5
--=============
--Generation du fichier en blob dans la gtt
   util_iofile.insert2_gtt_xml_and_close_blob (pe_idtrace        => ot.idtrace,
                                               pe_parametre      => parametre_blob,
                                               pes_blob          => le_blob
                                              );
   ot.msg ('Fin ');
EXCEPTION
   WHEN OTHERS
   THEN
      ot.msg ('ERROR ' || SQLERRM);
--=============
-- Etape 7 : nettoyage des datas
--=============
      util_iofile.close_and_free_blob (le_blob);
END;
/

```