+++
draft = false
title = "logo"
description = ""
date = "2017-04-24T18:36:24+02:00"


creatordisplayname = "Timothé CLAVIER"
creatoremail = "clavier.timothe@gmail.com"
lastmodifierdisplayname = "Timothé CLAVIER"
lastmodifieremail = "clavier.timothe@gmail.com"

+++

![Meti Logo](http://imagescxp.algora.fr/gamixfr_imgs/gmx_003586.gif)
