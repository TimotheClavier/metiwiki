+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Schéma et Diagramme"
author="Timothé Clavier"

[menu.main]
identifier = "SD-1-Schema et Diagramme"
parent =""
+++
Auteur:  
Date: 07/10/2016

---------------

# draw.io ou comment faire un joli schéma ?

[https://www.draw.io](https://www.draw.io)


## Support et Documentation

https://support.draw.io/display/DO/draw.io+Online+Support

## Astuces

### Connector
Il existe deux types de connector lorsqu'on relie des blocs : "anchored" et "floating".
Les floating vont avoir tendance à se positionner un peu n'importe où :( alors que les anchored comme leur nom l'indique restent ancrés à l'endroit sélectionné.

La documentation explique tout ça très bien:

[https://support.draw.io/display/DO/Tutorial+3+-+Connectors,+Waypoints,+and+Altering+Shapes](https://support.draw.io/display/DO/Tutorial+3+-+Connectors,+Waypoints,+and+Altering+Shapes)

### Export d'une sélection
Selectionner une partie du schéma et ensuite
dans le menu d'export il faudra
cocher l'option "selection only"

