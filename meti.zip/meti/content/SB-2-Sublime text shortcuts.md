+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Sublime texte shortcuts"
author="Timothé Clavier"

[menu.main]
identifier = "SB-2-Sublime text shortcuts"
parent ="SB-1-Sublime Text"
+++
Auteur:  
Date: 25/08/2016

---------------

## System and Files
Command                                               | Windows                   | Linux
--------                                              | -----------               | -------------
Open File                                             | Ctrl + O                  | Ctrl + O
Save File                                             | Ctrl + S                  | Ctrl + S
Close File                                            | Ctrl + W                  | Ctrl + W
Open recently closed                                  | file  Ctrl + Shift + T    | Ctrl + Shift + T
Toggle sidebar                                        | Ctrl + K B                | Ctrl + K B
Switch project                                        | Ctrl + Alt + P            | Ctrl + Alt + P
Font size                                             | Ctrl + +/-                | Ctrl + +/-
Command pallette                                      | Ctrl + Shift + P          | Ctrl + Shift + P
Fullscreen                                            | F11                       | F11
Distraction free fullscreen                           | Shift + F11               | Shift + F11
Change tab                                            | Alt + Number              | Alt + Number
Navigate Through Tabs                                 | Ctrl + PageUp/Down        | Ctrl + PageUp/Down


## Layout
Command                                               | Windows                   | Linux
--------                                              | -----------               | -------------
Select column layouts                                 | Alt + Shift + (1-4)       | Alt + Shift + (1-4)
Select 4 grid layout                                  | Alt + Shift + 5           | Alt + Shift + 5
Select two or three row layouts                       | Alt + Shift + (8,9)       | Alt + Shift + (8,9)
Move to panel                                         | Ctrl + Number             | Ctrl + Number
Move file to panel                                    | Ctrl + Shift + Number     | Ctrl + Shift + Number


## Finding Things
Command                                               | Windows                   | Linux
--------                                              | -----------               | -------------
Find                                                  | Ctrl + F                  | Ctrl + F
Find in files                                         | Ctrl + Shift + F          | Ctrl + Shift + F
Find and replace                                      | Ctrl + H                  | Ctrl + H
Incremental search                                    | Ctrl + I                  | Ctrl + I
Navigate through the search panel                     | Tab                       | Tab
Close search                                          | Escape                    | Escape
Goto anything                                         | Ctrl + P                  | Ctrl + P
Goto line number                                      | Ctrl + G                  | Ctrl + G
Goto symbol                                           | Ctrl + R                  | Ctrl + R
Go to word                                            | Ctrl + P + write #        | Ctrl + P + write #
Find next                                             | Enter (Or F3)             | Enter (Or F3)
Find previous                                         | Shift + Enter (Or F3)     | Shift + Enter (Or F3)
Find all                                              | Alt + F3                  | Alt + F3


## Selections / Moving Around
Command                                               | Windows                   | Linux
--------                                              | -----------               | -------------
Jump words / characters                               | Ctrl + Left/Right         | Ctrl + Left/Right
Moving around and selecting                           | Ctrl + Shift + Left/Right | Ctrl + Shift + Left/Right
Add next occurence to selection                       | Ctrl + D                  | Ctrl + D
Add scope to selection                                | Ctrl + Shift + Space      | Ctrl + Shift + Space
Add all occurences to selection                       | Alt + F3                  | Alt + F3
Select contents inside parenthesis                    | Ctrl + Shift + M          | Ctrl + Shift + M
Expand selection to indentation                       | Ctrl + Shift + J          | Ctrl + Shift + J
Expand selection to Tag                               | Ctrl + Shift + A          | Ctrl + Shift + A
Go to closing / opening parenthesis                   | Ctrl + M                  | Ctrl + M
Back to single selection                              | Escape                    | Escape
Scroll to selection                                   | Ctrl + K, Ctrl + C        | Ctrl + K, Ctrl + C
Draw selection with mouse                             | Middle Mouse Button       | Right Mouse Button + Shift
Add to mouse selection                                | Ctrl                      | Ctrl
Subtract from mouse selection                         | Alt                       | Alt


## Multiple Cursors
Command                                               | Windows                   | Linux
--------                                              | -----------               | -------------
Split selection into lines                            | Ctrl + Shift + L          | Ctrl + Shift + L
Add new cursor                                        | Ctrl + Alt + Up/Down      | Alt + Shift + Up/Down
Single cursor                                         | Escape                    | Escape


## Editing
Command                                               | Windows                   | Linux
--------                                              | -----------               | -------------
Copy line / selection                                 | Ctrl + C                  | Ctrl + C
Cut line / selection                                  | Ctrl + X                  | Ctrl + X
Paste                                                 | Ctrl + V                  | Ctrl + V
Paste with indentation                                | Ctrl + Shift + V          | Ctrl + Shift + V
Delete line                                           | Ctrl + Shift + K          | Ctrl + Shift + K
Delete from cursor to end of line                     | Ctrl + K K                | Ctrl + K K
Delete from cursor to beginning of line               | Ctrl + K Backspace        | Ctrl + K Backspace
Duplicate line / selection                            | Ctrl + Shift + D          | Ctrl + Shift + D
Select line                                           | Ctrl + L                  | Ctrl + L
Move line up/down                                     | Ctrl + Shift + Up/Down    | Ctrl + Shift + Up/Down
Insert line after                                     | Ctrl + Enter              | Ctrl + Enter
Insert line before                                    | Ctrl + Shift + Enter      | Ctrl + Shift + Enter
Join next line end of the current line                | Ctrl + J                  | Ctrl + J
Transpose (swap place of characters/words)            | Ctrl + T                  | Ctrl + T
Uppercase                                             | Ctrl + K, Ctrl + U        | Ctrl + K, Ctrl + U
Lowercase                                             | Ctrl + K, Ctrl + L        | Ctrl + K, Ctrl + L
Delete word forward                                   | Ctrl + Del                | Ctrl + Del
Delete word backwards                                 | Ctrl + Backspace          | Ctrl + Backspace
Close tag                                             | Alt + .                   | Alt + .


## Bookmarks
Command                                               | Windows                   | Linux
--------                                              | -----------               | -------------
Add/remove bookmark                                   | Ctrl + F2                 | Ctrl + F2
Goto next bookmark                                    | F2                        | F2
Goto previous bookmark                                | Shift + F2                | Shift + F2
Clear bookmarks                                       | Ctrl + Shift + F2         | Ctrl + Shift + F2


## Mark (you can set one mark)
Command                                               | Windows                   | Linux
--------                                              | -----------               | -------------
Set mark                                              | Ctrl + K Space            | Ctrl + K Space
Set new location                                      | Ctrl + K X                | Ctrl + K X
Select to mark                                        | Ctrl + K A                | Ctrl + K A
Delete to mark                                        | Ctrl + K W                | Ctrl + K W
Delete mark                                           | Ctrl + K G                | Ctrl + K G


## Misc
Command                                               | Windows                   | Linux
--------                                              | -----------               | -------------
Toggle Spellchecking                                  | F6                        | F6
Sort lines                                            | F9                        | F9