+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Trace Oracle"
author="Timothé Clavier"

[menu.main]
identifier = "PL-6-Trace Oracle"
parent ="PL-1-PLSQL"
+++
Auteur:  
Date: 25/08/2016

---------------
# Monitoring Oracle 

## 1- Méthode d'activation (Pour un traitement)

- <u>Package DBMS_MONITOR</u>

	* <b>Activation </b>
```sql
-- Sous le compte system :
BEGIN
   DBMS_MONITOR.serv_mod_act_trace_enable (service_name      => '<Instance>',
                                           module_name       => <SCHEMAS_ORACLE>||':emag OUTIFLUX',
                                           action_name       => 'OUTI_FLUX_LCT_STD RER_EXPORT'
                                          );
END;
/
```

	* <b>Désactivation </b>    
```sql
-- Sous le compte system :
BEGIN
   DBMS_MONITOR.serv_mod_act_trace_disable (service_name      => '<Instance>',
                                            module_name       => <SCHEMAS_ORACLE>||':'emag OUTIFLUX',
                                            action_name       => 'OUTI_FLUX_LCT_STD RER_EXPORT'
                                           );
END;
/
```

## 2- Méthode d'activation (Pour un utilisateur)

- <u>Package DBMS_MONITOR</u>

    * <b>Activation </b>
```sql
-- Sous le compte system :
BEGIN
   SYS.DBMS_MONITOR.client_id_trace_enable (client_id      => '<Code Site> <Login Utilisateur Emag>');
   -- Exemple
   SYS.DBMS_MONITOR.client_id_trace_enable (client_id      => 'AUCDRIVE FRA0262775');
END;
/
```

	* <b>Désactivation </b>    
```sql
-- Sous le compte system :
BEGIN
   SYS.DBMS_MONITOR.client_id_trace_disable (client_id      => '<Code Site> <Login Utilisateur Emag>');
   -- Exemple
   SYS.DBMS_MONITOR.client_id_trace_disable (client_id      => 'AUCDRIVE FRA0262775');
END;
/
```
	* <b>Trouver les paramètres </b>
<br> Chaque fichier .trc comporte au début les informations
<i>Exemple</i> : 
```Bash 
*** SESSION ID:(102.31513) 
*** CLIENT ID:(FPLP DTA) 
*** SERVICE NAME:(FSUP93R) 
*** MODULE NAME:(SUFPLP:emag ENTPENTR) 
*** ACTION NAME:(ENTP_ENTR_LANC_PREPA) 
```	
	* <b>Visualiser les parametres</b>

```sql
-- Sous le compte system :
SELECT client_identifier, client_info, action, module
  FROM gv$session
 WHERE action IS NOT NULL;

```



<b><u>Utilisation : </u></b>

<p>Sur le serveur oracle, se positionner dans le répertoire de traces (<b><i>sho parameters user_dump_dest</i></b>)</p>
<p>et lancer les commandes suivantes : </p>
<p>
<b>trcsess output=<i><blue>trc_flux_rer.trc</i> service= <i>Instance</i> module=<i>"<SCHEMAS_ORACLE>:emag OUTIFLUX"</i> action=<i>"OUTI_FLUX_LCT_STD RER_EXPORT"</i></b>
</p>
<p>
puis
</p>
<p>
<b>tkprof <i>trc_flux_rfi.trc trc_flux_rer.log</i></b>
</p>



- <u>Méthode à la session (sous sqlplus, sql Developper etc....)</u>

<br><i> Nécessite le droit <b>ALTER SESSION</b> sur le schémas 
<br> Pour activer ce droit sous SYSTEM (ou équivalent)</i>
```sql
grant ALTER SESSION to <SCHEMAS>
````

* <b>Activation </b>

```Sql 
-- sous le schemas Oracle à tracer 

-- Activation des traces 
alter session set sql_trace=true;

-- modifier le nom du fichier trace 
ALTER SESSION SET TRACEFILE_IDENTIFIER = "Test_jpu_propo";

-- Execution des traitements  à tracer 
exec APPRO_CDEAUTO.main_CumulVte;

-- Desactiver les traces a la fin du traitement
alter session set sql_trace=false;

```

<b><u>Utilisation : </u></b>

<p>Sur le serveur oracle, se positionner dans le répertoire de traces (<b><i>sho parameters user_dump_dest</i></b>)</p>
<p>et lancer les commandes suivantes : </p>
<p>
<p>
<b>tkprof <i>trc_Test_jpu_propo.trc trc_flux_rer.log</i></b>
</p>





## 3- Controle monitoring actif
<p> Pour savoir si une trace de monitoring est active il faut interroger la table Oracle suivant :  </p>

```sql
-- sous SYSTEM 
select * from DBA_ENABLED_TRACES;
```

<p> Pour désactiver la trace, il faut alors récuperer la valeur de la colonne CLIENT_ID et lancer la procédure suivante </p>
```sql
-- sous SYSTEM , desactivation du client id RECETTE SP : 
exec dbms_monitor.client_id_trace_disable('RECETTE SP');
```

## 4- Controle que les dump de trace ne sont pas limités:
- <br> Sous <b>system</b> vérifier le paramètre <i><b>max_dump_file_size</b></i>
- <br> Changer la valeur si celle-ci est trop petite ( UNLIMITED si jusqu'à plus soif)
<br><b>ATTENTION!</b> Il est <b><u>impératif</u></b> de remettre la valeur originale après utilisation.