+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Infos pratiques SQL"
author="Timothé Clavier"

[menu.main]
identifier = "SQL-5-Infos pratiques sql"
parent ="SQL-1-SQL"
+++
Auteur:  
Date: 11/05/2017

---------------
## Techniques Sql 
- [http://www.orafaq.com/wiki/Oracle_Row_Generator_Techniques ](http://www.orafaq.com/wiki/Oracle_Row_Generator_Techniques)
- [requete a trou ](http://lxdev03:8000/absressources/meti_all/jobs/Raneto-0.7.1_backup/content/sql/requete_a_trou.md)
- [gestion des quotes dans les requetes dynamique ](http://www.oracle-developer.net/display.php?id=311)
- [tuto sql (site sql.sh)](http://sql.sh/)