+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Best Practices"
author="Timothé Clavier"

[menu.main]
identifier = "JS-3-Best Practices"
parent ="JS-1-Javascript"
+++
Auteur:  
Date: 02/03/2017

---------------

## Les "on\_recup\_infos"

Il ne faut pas faire plus d'un recup infos à fois.

Rappel : La fonction "on_recup_infos" génère un appel http_request. Ce qui équivaut à un appel vers apache et une connexion Oracle.

Mauvaise pratique:
Faire un "on_recup_infos" pour faire un "select count" puis  en fonction du retour en faire un autre, n'est pas une bonne pratique !

Il faut préférer appeler un script PHP (avec une requète httprequest) qui fera tout le traitement en une seule fois.

[La doc ici](http://lxdev01:8080/docs/trunk/Developpement/BestPractices/dev_NORM_onrecupinfos_bestpractices.odt)