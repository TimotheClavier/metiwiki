+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Best Practices"
author="Timothé Clavier"

[menu.main]
identifier = "PL-2-Best Practices"
parent ="PL-1-PLSQL"
+++
Auteur:  
Date: 25/08/2016

---------------
### Déclaration de paramétre Procédure/function
- Rajout de nouveau paramètres :
<br>En générale, il faut toujours déclarer les nouveaux  paramtres avec une valeur défaut.
<br> Si ce n'est pas le cas : 
 - Il faut alors rechercher tous les objets Oracle faisant référence à la fonction/procédure que l'on est en train de modifier afin de passer les bonnes valeurs à l'objet (sous peine que celui-ci ne compilera plus).
 
 <br> ATENTION : la recherche de ces objets ne doit pas être faite <b>uniquement</b> via les dépendances Oracle  (<i>vue oracle user_dependencies<i>), mais sur l'ensemble du dépôt svn, à cause des   appelle dynaiqmyque
 <i> ou bien sur RFMETI de REC11 avec la vue user_source</i>)
 
 <i><u>Exemple</u></i>
 
 ```Sql
 select * from user_source where instr(upper(text),'<ma fonction>')>0;
 ```
 