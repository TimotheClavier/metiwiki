+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Sql Developper"
author="Timothé Clavier"

[menu.main]
identifier = "SQLDEV-3-Sql developper"
parent ="SQLDEV-1-SQL Developpeur"
+++
Auteur:  
Date: 25/08/2016

---------------
## 1- Paramétrages

- Vérification Paramétrage SQL Developer

<p> Suivant les versions de SQL Developer, il peut y avoir des erreurs de paramétrages des variables
    d'environnement NLS engendré par le soft. </p>
<p> Pour être sur d'être toujours  ok, il est conseillé de prendre en compte les paramètres de la bases
    et d'ignorer celles proposé par le soft.</p>
<p> Soit : </p>
<p> Ignorer les paramètres NLS </p>

![Menu preference](http://lxdev03:3004/resources/oracle/sql_dev_menu_preference.png)
![Menu NLS](http://lxdev03:3004/resources/oracle/sql_dev_preference_nls.png)

 <p> Forcer les parametres NLS au démarrage </p>
![Menu NLS](http://lxdev03:3004/resources/oracle/sql_dev_preference_nls_default.png)
 <p></p>

<p> Contenu du fichier de démarrage</p>

```sql
alter session set NLS_LENGTH_SEMANTICS=CHAR;
alter session set NLS_DATE_FORMAT='DD/MM/YYYY';
alter session set NLS_DATE_LANGUAGE=FRENCH;
ALTER session SET NLS_NUMERIC_CHARACTERS = '.,';
-- Pour vérifier :  (on doit obtenir AL32UTF8)
SELECT 'NLS_CHARACTERSET=>' || VALUE AS verif FROM nls_database_parameters WHERE parameter = 'NLS_CHARACTERSET';
```



## 2- Controle (dans le cas ou un sql dev est mal paramétré)

- Vérifier si un objet est stocké en CHAR ou BYTE (Ce qui peut provoquer des erreurs type dépassement capacité, nombre invalide,erreur sur une valeur ...)

<br>
```sql
<p>
	SELECT *
	FROM user_plsql_object_settings
	WHERE NAME LIKE '%TRAN_EXPO_FICHIER_RER%';
</p>

<br>
	<p> On obtient les résulats suivants
		<table border='1' width='90%' align='center' summary='Script output'>
		<tr>
			<th scope="col">NAME</th>
			<th scope="col">TYPE</th>
			<th scope="col">PLSQL_OPTIMIZE_LEVEL</th>
			<th scope="col">PLSQL_CODE_TYPE</th>
			<th scope="col">PLSQL_DEBUG</th>
			<th scope="col">PLSQL_WARNINGS</th>
			<th scope="col">NLS_LENGTH_SEMANTICS</th>
			<th scope="col">PLSQL_CCFLAGS</th>
			<th scope="col">PLSCOPE_SETTINGS</th>
		</tr>
		<tr>
			<td>TRAN_EXPO_FICHIER_RER</td>
			<td>PACKAGE</td>
			<td align="right">2</td>
			<td>INTERPRETED</td>
			<td>FALSE</td>
			<td>DISABLE:INFORMATIONAL,
				DISABLE:PERFORMANCE,
				ENABLE:SEVERE
			</td>
			<td>CHAR</td>
			<td>{null}</td>
			<td>IDENTIFIERS:NONE</td>
		</tr>
		<tr>
			<td>TRAN_EXPO_FICHIER_RER</td>
			<td>PACKAGE BODY</td>
			<td align="right">         2</td>
			<td>INTERPRETED</td>
			<td>FALSE</td>
			<td>DISABLE:INFORMATIONAL,
				DISABLE:PERFORMANCE,
				ENABLE:SEVERE
			</td>
			<td>CHAR</td>
			<td>{null}</td>
			<td>IDENTIFIERS:NONE</td>
		</tr>
		</table>
	</p>
```
	<br>
	<p> Il faut vérifier la valeur de la colonne NLS_LENGTH_SEMANTICS qui doit être positionné à CHAR et non à BYTE. </p>
    
 - Vérifier si un objet est compilé en mode debug
 
```Sql
SELECT * FROM user_plsql_object_settings where plsql_debug='TRUE';
```