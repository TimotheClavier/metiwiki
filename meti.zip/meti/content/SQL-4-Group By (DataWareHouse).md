+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Group By(DataWhareHouse)"
author="Timothé Clavier"

[menu.main]
identifier = "SQL-4-Group By(DataWhareHouse)"
parent ="SQL-1-SQL"
+++
Auteur:  
Date: 28/08/2016

---------------
- Exemple succint de quelques fonctionnalités de regroupement issu du DataWareHouse

### Group By classique

```Sql 
SELECT   TO_CHAR (vaj_dtrem, 'MM/YYYY') AS dt, art_cdf,vaj_txtva, 
         SUM (vaj_mtvente) AS mtvente,
         SUM (vaj_mtachat) AS mtachat
    FROM mgvajr, mgart
   WHERE art_noart = vaj_noart
GROUP BY TO_CHAR (vaj_dtrem, 'MM/YYYY'), art_cdf,vaj_txtva
ORDER BY TO_CHAR (vaj_dtrem, 'MM/YYYY'), art_cdf,vaj_txtva;
```

### ROLLUP 
<br> Fait des totaux par rupture de la clause Group by 

```Sql 
SELECT   TO_CHAR (vaj_dtrem, 'MM/YYYY') AS dt, art_cdf, vaj_txtva, 
         SUM (vaj_mtvente) AS mtvente,
         SUM (vaj_mtachat) AS mtachat
    FROM mgvajr, mgart
   WHERE art_noart = vaj_noart 
     AND vaj_dtrem BETWEEN '01/01/2015' AND '31/12/2016' 
     AND art_cdf=982
GROUP BY ROLLUP (TO_CHAR (vaj_dtrem, 'MM/YYYY'), art_cdf, vaj_txtva)
ORDER BY TO_CHAR (vaj_dtrem, 'MM/YYYY'), art_cdf, vaj_txtva;
```

### CUBE 
<br>Idem que <b><i>Rollup</i></b> mais avec une récap final des totaux
```Sql 
SELECT   TO_CHAR (vaj_dtrem, 'MM/YYYY') AS dt, art_cdf, vaj_txtva, 
         SUM (vaj_mtvente) AS mtvente,
         SUM (vaj_mtachat) AS mtachat
    FROM mgvajr, mgart
   WHERE art_noart = vaj_noart 
     AND vaj_dtrem BETWEEN '01/01/2015' AND '31/12/2016'
     AND art_cdf=982
GROUP BY CUBE (TO_CHAR (vaj_dtrem, 'MM/YYYY'), art_cdf, vaj_txtva)
ORDER BY TO_CHAR (vaj_dtrem, 'MM/YYYY'), art_cdf, vaj_txtva;
```
<br> Il est possible de faire aussi un regroupement Partiel : oco une récap par cdf

```Sql 
SELECT   TO_CHAR (vaj_dtrem, 'MM/YYYY') AS dt, art_cdf, vaj_txtva, 
         SUM (vaj_mtvente) AS mtvente,
         SUM (vaj_mtachat) AS mtachat
    FROM mgvajr, mgart
   WHERE art_noart = vaj_noart AND vaj_dtrem BETWEEN '01/01/2015' AND '31/12/2016'
GROUP BY art_cdf, CUBE (TO_CHAR (vaj_dtrem, 'MM/YYYY'), vaj_txtva)
ORDER BY TO_CHAR (vaj_dtrem, 'MM/YYYY'), art_cdf, vaj_txtva;
```

### Grouping

<br> Il peut être practique d'identifier direcetment les lignes calculées par une fonction ROLLUP/CUBE par l'utilisation de <b><i>GROUPING</i></b>


<i>Exemple avec <b>ROLLUP</b></i> : 
```Sql 
SELECT   TO_CHAR (vaj_dtrem, 'MM/YYYY') AS dt, 
         art_cdf, 
         vaj_txtva, 
         SUM (vaj_mtvente) AS mtvente,
         SUM (vaj_mtachat) AS mtachat, 
         GROUPING (art_cdf) AS flg_tot_cdf
    FROM mgvajr, mgart
   WHERE art_noart = vaj_noart AND vaj_dtrem BETWEEN '01/01/2015' AND '31/12/2016'
GROUP BY TO_CHAR (vaj_dtrem, 'MM/YYYY'), ROLLUP (art_cdf), vaj_txtva
ORDER BY TO_CHAR (vaj_dtrem, 'MM/YYYY'), art_cdf, vaj_txtva;

```

<i>Exemple avec <b>CUBE</b></i> : 
```Sql 
SELECT   TO_CHAR (vaj_dtrem, 'MM/YYYY') AS dt, art_cdf, vaj_txtva, 
         SUM (vaj_mtvente) AS mtvente,
         SUM (vaj_mtachat) AS mtachat, 
         GROUPING (TO_CHAR (vaj_dtrem, 'MM/YYYY')) AS flg_tot_mois_an,
         GROUPING (vaj_txtva) AS flg_tot_txtva
    FROM mgvajr, mgart
   WHERE art_noart = vaj_noart AND vaj_dtrem BETWEEN '01/01/2015' AND '31/12/2016'
GROUP BY art_cdf, CUBE (TO_CHAR (vaj_dtrem, 'MM/YYYY'), vaj_txtva)
ORDER BY TO_CHAR (vaj_dtrem, 'MM/YYYY'), art_cdf, vaj_txtva;


```

<br> On obtient des flg <i>0</i> et <i>1</i> avec <b><i>1</i></b> qui indique que le résultat provient d'un total


<br> Il est aussi possible de <b><i>filter</i></b> les résultats ou bien <b><i>d'ordonner</i></b> ceci suivant ces pseudo-colonnes

```Sql 

SELECT   TO_CHAR (vaj_dtrem, 'MM/YYYY') AS dt, art_cdf, vaj_txtva, 
         SUM (vaj_mtvente) AS mtvente,
         SUM (vaj_mtachat) AS mtachat, 
         GROUPING (TO_CHAR (vaj_dtrem, 'MM/YYYY')) AS flg_tot_mois_an,
         GROUPING (vaj_txtva) AS flg_tot_txtva
    FROM mgvajr, mgart
   WHERE art_noart = vaj_noart AND vaj_dtrem BETWEEN '01/01/2015' AND '31/12/2016'
GROUP BY art_cdf, CUBE (TO_CHAR (vaj_dtrem, 'MM/YYYY'), vaj_txtva)
  HAVING GROUPING (TO_CHAR (vaj_dtrem, 'MM/YYYY')) = 1
      OR GROUPING (vaj_txtva) = 1
ORDER BY TO_CHAR (vaj_dtrem, 'MM/YYYY'),
         art_cdf,
         vaj_txtva,
         GROUPING (TO_CHAR (vaj_dtrem, 'MM/YYYY')),
         GROUPING (vaj_txtva);

```

### Grouping_ID

<br> Idem que Grouping à la différence qu'il est possible d'indentifier le niveau de profondeur d'un resultat total</br>
<br>       (0 pour ligne courante)
<br>       (1 pour total rupture 1)
<br>       (2 pour total rupture 1 + rupture 2)
<br>       etc ...


```Sql 
SELECT   art_cdf, art_cdtva, COUNT (*) AS nb, 
         GROUPING (art_cdtva) AS flg_ligne_avec_tot_nb_tva,
         GROUPING_ID (art_cdf,art_cdtva) AS no_id_ligne_avec_tot_nb_tva
    FROM mgart
   WHERE art_cdf IN (20, 30, 39)
GROUP BY CUBE (art_cdf,art_cdtva)
ORDER BY art_cdf, art_cdtva;

```
<table border=1 cellspacing=1 cellpadding=1 width="100%">
  <tr>
  <th align="left" bgcolor="#C0C0C0" bordercolor="#FFFFFF">ART_CDF</th>
  <th align="left" bgcolor="#C0C0C0" bordercolor="#FFFFFF">ART_CDTVA</th>
  <th align="left" bgcolor="#C0C0C0" bordercolor="#FFFFFF">NB</th>
  <th align="left" bgcolor="#C0C0C0" bordercolor="#FFFFFF">FLG_LIGNE_AVEC_TOT_NB_TVA</th>
  <th align="left" bgcolor="#C0C0C0" bordercolor="#FFFFFF">NO_ID_LIGNE_AVEC_TOT_NB_TVA</th>
  </tr>
  <tr>    <td nowrap><div align=right>20</div></td>
    <td nowrap><div align=right>1</div></td>
    <td nowrap><div align=right>15</div></td>
    <td nowrap><div align=right>0</div></td>
    <td nowrap><div align=right>0</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>20</div></td>
    <td nowrap><div align=right>2</div></td>
    <td nowrap><div align=right>5</div></td>
    <td nowrap><div align=right>0</div></td>
    <td nowrap><div align=right>0</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>20</div></td>
    <td nowrap><div align=right>5</div></td>
    <td nowrap><div align=right>1</div></td>
    <td nowrap><div align=right>0</div></td>
    <td nowrap><div align=right>0</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>20</div></td>
    <td nowrap>&nbsp;</td>    <td nowrap><div align=right>21</div></td>
    <td nowrap><div align=right>1</div></td>
    <td nowrap><div align=right>1</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>30</div></td>
    <td nowrap><div align=right>1</div></td>
    <td nowrap><div align=right>16</div></td>
    <td nowrap><div align=right>0</div></td>
    <td nowrap><div align=right>0</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>30</div></td>
    <td nowrap><div align=right>2</div></td>
    <td nowrap><div align=right>1</div></td>
    <td nowrap><div align=right>0</div></td>
    <td nowrap><div align=right>0</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>30</div></td>
    <td nowrap>&nbsp;</td>    <td nowrap><div align=right>17</div></td>
    <td nowrap><div align=right>1</div></td>
    <td nowrap><div align=right>1</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>39</div></td>
    <td nowrap><div align=right>1</div></td>
    <td nowrap><div align=right>5</div></td>
    <td nowrap><div align=right>0</div></td>
    <td nowrap><div align=right>0</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>39</div></td>
    <td nowrap><div align=right>4</div></td>
    <td nowrap><div align=right>1</div></td>
    <td nowrap><div align=right>0</div></td>
    <td nowrap><div align=right>0</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>39</div></td>
    <td nowrap>&nbsp;</td>    <td nowrap><div align=right>6</div></td>
    <td nowrap><div align=right>1</div></td>
    <td nowrap><div align=right>1</div></td>
  </tr>
  <tr>    <td nowrap>&nbsp;</td>    <td nowrap><div align=right>1</div></td>
    <td nowrap><div align=right>36</div></td>
    <td nowrap><div align=right>0</div></td>
    <td nowrap><div align=right>2</div></td>
  </tr>
  <tr>    <td nowrap>&nbsp;</td>    <td nowrap><div align=right>2</div></td>
    <td nowrap><div align=right>6</div></td>
    <td nowrap><div align=right>0</div></td>
    <td nowrap><div align=right>2</div></td>
  </tr>
  <tr>    <td nowrap>&nbsp;</td>    <td nowrap><div align=right>4</div></td>
    <td nowrap><div align=right>1</div></td>
    <td nowrap><div align=right>0</div></td>
    <td nowrap><div align=right>2</div></td>
  </tr>
  <tr>    <td nowrap>&nbsp;</td>    <td nowrap><div align=right>5</div></td>
    <td nowrap><div align=right>1</div></td>
    <td nowrap><div align=right>0</div></td>
    <td nowrap><div align=right>2</div></td>
  </tr>
  <tr>    <td nowrap>&nbsp;</td>    <td nowrap>&nbsp;</td>    <td nowrap><div align=right>44</div></td>
    <td nowrap><div align=right>1</div></td>
    <td nowrap><div align=right>3</div></td>
  </tr>
</table>


<br> Pour de plus ample renseignement cf https://oracle-base.com/articles/misc/rollup-cube-grouping-functions-and-grouping-sets