+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Svn Astuces"
author="Timothé Clavier"

[menu.main]
identifier = "SVN-2-Astuces"
parent ="SVN-1-SVN"
+++
Auteur:  
Date: 12/01/2017

---------------
## Reporter des modifs via tortoise SVN

Une petite fonctionnalité pratique de tortoise pour des reports de code, l'outil de patchs.

<i><u>Explication par l'exemple : </u></i>

J'ai modifié 4 fichiers .sql, sur le trunk, que je dois livrer en 9021 :

![astuce_patch1](http://lxdev03:3004/resources/svn/svn_astuce_patch1.png)

1 - Vu qu'ils sont tous dans le dossier std, je créé un "patch svn" à partir du dossier std du trunk :
![astuce_patch2](http://lxdev03:3004/resources/svn/svn_astuce_patch2.png)
2 - Je sélectionne les fichiers que je veux y ajouter et j'enregistre mon patch :
![astuce_patch3](http://lxdev03:3004/resources/svn/svn_astuce_patch3.png)
![astuce_patch4](http://lxdev03:3004/resources/svn/svn_astuce_patch4.png)

3 - Dans mon tag 9021, sur le dossier std, j'applique le patch précédemment créé:
![astuce_patch5](http://lxdev03:3004/resources/svn/svn_astuce_patch5.png)
...fichier par fichier avec vérification des modifs au cas où :
![astuce_patch6](http://lxdev03:3004/resources/svn/svn_astuce_patch6.png)

4 - Pas d'étape 4...


## Automatiser les updates Tortoise 

- Commande TortoiseSVN pour automatiser la maj d'un dépot :
<br>

| <i>Pour Chaque depot SVN :</i> | |
|---:|:---------|
|C:\Program Files\TortoiseSVN\bin\TortoiseProc.exe||
|    |/command:update |
|    |/closeonend:2  |
|    |/closeforlocal  |
|    |/path: ** Mon depot SVN ** |

<i>Exemple</i>
```Batch
C:\Program Files\TortoiseSVN\bin\TortoiseProc.exe /command:update /closeonend:2 /closeforlocal /path:D:\devcoop\docs

```




- Outils pour Plannifier la tâche : 

	- Via le plannificateur de tâche Window
    
    - Via un outils tiers comme [Z-Cron Scheduler](http://www.z-cron.com/scheduler.html)
    
    
   
## Echec de l'update et Cleanup  : 

Contexte : un update qui plante systématiquement 

```Bash
Command: Update Error: Previous operation has not finished; run 'cleanup' if it was interrupted Error: Please execute the 'Cleanup' command. Completed!:
```

- télécharger ceci: [SQLlite](https://github.com/sqlitebrowser/sqlitebrowser/releases/download/v3.9.1/DB.Browser.for.SQLite-3.9.1-win64.exe)

- ouvrir la base de donnée SVN ".svn/wc.db" avec le logiciel

![astuce_svn_cleanup1](/resources/svn/svn_cleanup_load_database.jpg)


- faire ces deux commandes:
	- delete from work_queue
	- select * from work_queue (vérifier que 0 enreg sont retournés)
![astuce_svn_cleanup1](/resources/svn/svn_delete_database.jpg)

- sauvegarder la base
![astuce_svn_cleanup1](/resources/svn/svn_save_database.png)

- et là,  il est possible de faire le cleanup