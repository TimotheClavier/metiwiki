+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Ligne en colonne et inversement (pivot unpivot)"
author="Timothé Clavier"

[menu.main]
identifier = "SQL-6-Ligne en colonne et inversment(pivot unpivot)"
parent ="SQL-1-SQL"
+++
Auteur:  
Date: 25/08/2016

---------------

- Exemple Pivot-Unpivot :

```Sql 
/********************************************
 * Exemple Requete PIVOT 
 * regrouper les qtes par TVA 
 * (Mettre en colonnes les enreg de type ligne
 ********************************************
 */ 
WITH pivot_data AS (
SELECT   art_cdf,vaj_qtvend,  art_cdtva
    FROM mgvajr, mgart
   WHERE art_noart = vaj_noart AND vaj_dtrem = '15/02/2011'-- AND art_cdf = 641)
    )   
SELECT * FROM pivot_data
pivot (SUM (vaj_qtvend) AS qt 
            FOR (art_cdtva) IN 
                (1 AS tva1,2 AS tva2,3 AS tva3,4 AS tva4,5 AS tva5,6 AS tva6,7 AS tva7,8 AS tva8,9 AS tva9)  )   
ORDER BY art_cdf;
;

/********************************************
 * Exemple Requete PIVOT 
 * regrouper les qtes par jour de la semaine 
 * (Mettre en colonnes les enreg de type ligne)
 * Test sous HYP011/MAG11
 ********************************************
 */ 
with pivot_data as (
SELECT   vaj_noart, TO_CHAR (vaj_dtrem, 'D') AS nojour, vaj_qtvend,
               vaj_mtvente
          FROM mgvajr
         WHERE vaj_noart = 21400616
           AND vaj_cdmag = 11
           AND vaj_dtrem BETWEEN '09/06/2014' AND '17/06/2014'
           )
select * from pivot_data                 
    pivot (
    sum(vaj_qtvend) as qtvend,
    sum(vaj_mtvente) as mtvente
    for nojour in (
    1 as lundi,
    2 as mardi,
    3 as mercredi,
    4 as jeudi,
    5 as vendredi,
    6 as samedi,
    7 as dimanche)
    ) 
  ;  


/********************************************
 * Exemple Requete UNPIVOT 
 * DEgrouper les montants par TVA 
 * (Mettre en ligne les enreg de type colonnes
 ********************************************
 */ 
WITH my_data AS (
    SELECT 
            vug_cdf, 
            vug_cdtva1,vug_mtcatva1, 
            vug_cdtva2,vug_mtcatva2, 
            vug_cdtva3,vug_mtcatva3,
            vug_cdtva4,vug_mtcatva4, 
            vug_cdtva5,vug_mtcatva5, 
            vug_cdtva6,vug_mtcatva6, 
            vug_cdtva7,vug_mtcatva7, 
            vug_cdtva8,vug_mtcatva8, 
            vug_cdtva9,vug_mtcatva9
    FROM mgvug
    WHERE vug_dtrem = '15/02/2011' and vug_cdf=641
    )
SELECT vug_cdf,t,cdtva 
FROM my_data
UNPIVOT   (cdtva FOR  t IN (vug_cdtva1 AS 't1',
                            vug_cdtva2 AS 't2',
                            vug_cdtva3 AS 't3',
                            vug_cdtva4 AS 't4',
                            vug_cdtva5 AS 't5',
                            vug_cdtva6 AS 't6',
                            vug_cdtva7 AS 't7',
                            vug_cdtva8 AS 't8',
                            vug_cdtva9 AS 't9',
                            vug_mtcatva1 AS 'm1',
                            vug_mtcatva2 AS 'm2',
                            vug_mtcatva3 AS 'm3',
                            vug_mtcatva4 as 'm4',
                            vug_mtcatva5 as 'm5',
                            vug_mtcatva6 as 'm6',
                            vug_mtcatva7 as 'm7',
                            vug_mtcatva8 as 'm8',
                            vug_mtcatva9 as 'm9'
                            )
            )
 WHERE cdtva<>0 
 ORDER BY vug_cdf;
```
