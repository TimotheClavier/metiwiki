+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Déclaration exception"
author="Timothé Clavier"

[menu.main]
identifier = "PL-2-Declaration exception"
parent ="PL-1-PLSQL"
+++
Auteur:  
Date: 25/08/2016

---------------
- Exemple basique

```Sql
DECLARE
   err_ctrl_type_arti_inconnu   EXCEPTION;                                    -- echec ctrl article
   PRAGMA EXCEPTION_INIT (err_ctrl_type_arti_inconnu, -20900);             -- Numero de l'exception
   dummy_a                      mgart.art_lbarti%TYPE;
BEGIN
   SELECT art_lbarti
     INTO dummy_a
     FROM mgart
    WHERE art_noart = 9999999;

   IF art_lbarti <> 'Ceci est une erreur'
   THEN
      raise_application_error (-20900, 'Article 9999 9999 non accepte ' || dummy_a);
   END IF;
EXCEPTION
   WHEN err_ctrl_type_arti_inconnu
   THEN
      DBMS_OUTPUT.put_line ('Erreur de ctrl ' || SQLCODE || '-' || SQLERRM);
END;
/

```

 - Exemple avec <b><u>bulk collect</u></b> et utilisation du package <b><i>mlib_erreur</i></b> : 
 

```Sql

/*
****************************************************
    Exemple d'utilisation avec mlib_erreur 
***************************************************
*/

DECLARE
-- declaration d'un tableau
   TYPE l_plg_tab_type IS TABLE OF gtt_apro_acha_cdeauto_mgplg%ROWTYPE
      INDEX BY PLS_INTEGER;

   l_tab_plg   l_plg_tab_type;
   idx_plg     PLS_INTEGER    := 0;
   log_raise   BOOLEAN        := FALSE;
   nb_cr       NUMBER (9)     := 0;
BEGIN
   -- Creation par bulk d'un tableau (deja precharge)
   FORALL i IN 1 .. l_tab_plg.COUNT SAVE EXCEPTIONS
      INSERT INTO gtt_apro_acha_cdeauto_mgplg
           VALUES l_tab_plg (i);
   nb_cr := SQL%ROWCOUNT;
   ot.msg (' (Cr) MGPLG ' || nb_cr);
EXCEPTION
   -- Qd erreur de type Bulk ( a la fin de l'execution du FORALL)
   WHEN mlib_erreur.exc_bulk_errors
   THEN

--===============================================
-- Bcle sur l'ensemble des erreurs rencontrees
--===============================================
      <<loop_tab_erreur>>
      FOR indx IN 1 .. SQL%BULK_EXCEPTIONS.COUNT
      LOOP
         -- Recup de l'index du tableau l_tab_plg
         idx_plg := SQL%BULK_EXCEPTIONS (indx).ERROR_INDEX;

         -- si pas doublons DUP_VAL_ON_INDEX
         -- ( ERROR_CODE correspond au code Oracle SQLCODE)
         IF SQL%BULK_EXCEPTIONS (indx).ERROR_CODE <> 1
         THEN
            DBMS_OUTPUT.put_line (   'ERREUR '
                                  || SQLERRM (- (SQL%BULK_EXCEPTIONS (indx).ERROR_CODE))
                                  || ' '
                                  || l_tab_plg (idx_plg).PLG_cdarti
                                  || ' ul:'
                                  || l_tab_plg (idx_plg).PLG_cdul);
         ELSE
            DBMS_OUTPUT.put_line (   'ANO! Doublons MGPLG : '
                                  || l_tab_plg (idx_plg).PLG_cdarti
                                  || ' ul:'
                                  || l_tab_plg (idx_plg).PLG_cdul);
         END IF;
      END LOOP loop_tab_erreur;
END;
/

```