+++
date="2017-05-16T15:12:23+02:00"
draft="true"
title="Hugo"
author="Timothé Clavier"

[menu.main]
identifier="H-1-Hugo"
parent=""
+++
Auteur: Timothé Clavier  
Date: 17/05/2017

---------------------
--------------------------

<h2>Hugo est cms permettant de générer des sites statiques dont celui-ci</h2>  
  
  
  
---------------------------
  


__[L'installation de hugo](http://localhost:1313/installation-de-hugo)__
 
__[L'installation d'un thème](http://localhost:1313/h-3-installation-th%C3%A8me/)__
  




