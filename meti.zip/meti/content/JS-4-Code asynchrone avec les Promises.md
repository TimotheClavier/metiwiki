+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Code asynchrone avec les Promises"
author="Timothé Clavier"

[menu.main]
identifier = "JS-3-Code asynchrone avec les Promises"
parent ="JS-1-Javascript"
+++
Auteur:  
Date: 14/09/2016

---------------
## Code asynchrone avec les Promises

Une Promise est un objet qui reflête l'état d'une action asynchrone.

Une Promise peut prendre trois état:
- "resolved" : Terminé avec succès
- "rejected : Terminé avec erreur
- "pending" : En cours

### Exemple

On va créer une fonction qui effectue une action asynchrone et retourne une Promise:

```javascript
function doAsyncJob(){
    return new Promise(function(resolve, reject){
        ...blablabla
        if(ok)
            resolve("terminé");
        else
            reject("echec");
    });
}
```

Ensuite si on veut éxécuter du code après l'éxécution de "doAsyncJob", on peut faire:

```javascript
doAsyncJob.then(function onSuccessed(){

}, function onRejected(){

});
```

Avec plusieurs Promises

```javascript
Promise.all([doAsyncJob(), doAsyncJob(), doAsyncJob()]).then(function onSuccessed(){

}, function onRejected(){

});
```