+++
date="2017-05-16T15:12:23+02:00"
draft="true"
title="Generer traces (mgtrace)"

[menu.main]

identifier="DI-3-Generer traces (mgtrace)"
parent="DI-1-Divers"

+++
Auteur:  
Date: 25/08/2016

----------------------
## Création de trace type MGTRACE/MGTRAR 

```Sql 

/*Script qui génère en sortie console les appels pour lever les traces mgtrace/mgtrar*/

DECLARE
   v_out1    VARCHAR2 (2000);
   v_out2    VARCHAR2 (2000);
   tbl       VARCHAR2 (2000);
   mdappel   VARCHAR2 (2000);
   prefx     VARCHAR2 (2000);
BEGIN
   tbl := UPPER ('&table');
   mdappel := UPPER ('&modeappel');
   prefx := LOWER ('&prefixe');

   FOR row IN (  SELECT *
                   FROM (  SELECT LOWER (cols.column_name) name, MAX (atc.data_type) TYPE,
                                  MAX (atc.char_length) lng_char, MAX (atc.data_precision) lng_numb,
                                  MAX (cols.position) pos
                             FROM all_constraints cons
                                  INNER JOIN all_cons_columns cols
                                     ON     cons.constraint_name = cols.constraint_name
                                        AND cons.owner = cols.owner
                                  INNER JOIN all_tab_cols atc
                                     ON     atc.table_name = cols.table_name
                                        AND atc.column_name = cols.column_name
                            WHERE     cols.table_name = tbl
                                  AND cons.constraint_type = 'P'
                                  AND cons.owner = cols.owner
                         GROUP BY cols.column_name)
               ORDER BY pos)
   LOOP
      IF row.pos > 1
      THEN
         v_out1 := v_out1 || '||';
         v_out2 := v_out2 || '||''|''||';
      END IF;

      IF row.TYPE = 'VARCHAR2'
      THEN
         v_out1 := v_out1 || 'rpad(' || prefx || row.name || ',' || row.lng_char || ','' '')';
      END IF;

      IF row.TYPE = 'NUMBER'
      THEN
         v_out1 := v_out1 || 'lpad(' || prefx || row.name || ',' || row.lng_numb || ',''0'')';
      END IF;

      IF row.TYPE = 'DATE'
      THEN
         v_out1 := v_out1 || 'to_char(' || prefx || row.name || ',''DD/MM/YYYY'')';
         v_out2 := v_out2 || 'to_char(' || prefx || row.name || ',''DD/MM/YYYY'')';
      END IF;

      IF row.TYPE <> 'DATE'
      THEN
         v_out2 := v_out2 || prefx || row.name;
      END IF;
   END LOOP;


   DBMS_OUTPUT.put_line (' -- Traces MGTRACE');
   DBMS_OUTPUT.put_line (' Meti_util.trace (');
   DBMS_OUTPUT.put_line (' P_table => ''' || tbl || ''',');
   DBMS_OUTPUT.put_line (' P_mode => ''' || mdappel || ''',');
   DBMS_OUTPUT.put_line (' P_ident => ' || v_out1);
   DBMS_OUTPUT.put_line (' );');

   DBMS_OUTPUT.put_line (' -- Traces MGTRAR');
   DBMS_OUTPUT.put_line (' METI_UTIL.PROC_MGTRAR(');
   DBMS_OUTPUT.put_line (' pe_cdtable => ''' || tbl || ''',');
   DBMS_OUTPUT.put_line (' pe_cdident => ' || v_out2 || ',');
   DBMS_OUTPUT.put_line (' pe_cdmvt => ''' || mdappel || '''');
   DBMS_OUTPUT.put_line (' );');
END;
/

```