+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Oramag"
author="Timothé Clavier"

[menu.main]
identifier = "O-2-Oramag"
parent ="O-1-Oracle"
+++
Auteur:  
Date: 25/08/2016

---------------
[mai_juin_2015_Ask_Tom_On_More-Secure_Applications.pdf](http://lxdev03:3004/resources/oracle/oramag/mai_juin_2015_Ask_Tom_On_More-Secure_Applications.pdf)

[mai_juin_2015_PL_SQL_ Dynamically Dangerous Code.pdf](http://lxdev03:3004/resources/oracle/oramag/mai_juin_2015_PL_SQL_%20Dynamically%20Dangerous%20Code.pdf)