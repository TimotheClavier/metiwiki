+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Best Practice Requete"
author="Timothé Clavier"

[menu.main]
identifier = "SQL-2-Best practice requete"
parent ="SQL-1-SQL"
+++
Auteur:  
Date: 28/08/2016

---------------

### Filtre avec des dates pouvant etre null 

```sql
-- Exemple selection des donnees MGARV active
SELECT *
  FROM mgarv
 WHERE     NVL (arv_dtdeb, TO_DATE ('01/01/0001', 'DD/MM/YYYY')) <= TRUNC (SYSDATE)
       AND NVL (arv_dtfin, TO_DATE ('31/12/2999', 'DD/MM/YYYY')) >= TRUNC (SYSDATE);
``` 
a remplacer  par 
```sql
SELECT *
  FROM mgarv
 WHERE     (arv_dtdeb <= TRUNC (SYSDATE) OR arv_dtdeb IS NULL)
       AND (arv_dtfin >= TRUNC (SYSDATE) OR arv_dtfin IS NULL);


``` 
		 
		 
### Filtre avec la liste des rayons des utilisateurs 

```sql	 
SELECT *
  FROM mgarv
 WHERE     (arv_dtdeb <= TRUNC (SYSDATE) OR arv_dtdeb IS NULL)
       AND (arv_dtfin >= TRUNC (SYSDATE) OR arv_dtfin IS NULL)
       AND (   dfex_util_session.session_get ('LSRAYAUTO') IS NULL
            OR INSTR (';' || dfex_util_session.session_get ('LSRAYAUTO') || ';',
                      ';' || arv_cdr || ';') > 0);
```

a remplacer par 

```sql
WITH my_liste_rayons_autorise 
	AS (SELECT /*+ MATERIALIZE */
		dfex_util_session.session_get ('LSRAYAUTO') lsr 
		FROM DUAL)
SELECT *
  FROM mgarv, my_liste_rayonautorise
 WHERE     (arv_dtdeb <= TRUNC (SYSDATE) OR arv_dtdeb IS NULL)
       AND (arv_dtfin >= TRUNC (SYSDATE) OR arv_dtfin IS NULL)
       AND (lsr IS NULL OR INSTR (';' || lsr || ';', ';' || arv_cdr || ';') > 0);

```

### Bind variables dans les requetes dynamiques

<br>Lorsque la variable HOTE n'est pas renseignée
<br> Cette méthode est valable quelquesoit le type de dynamique <i>(execute immediate, ref cursor, dbms_sql)</i>


 - Exemple avec <i>EXECUTE IMMEDIATE</i>

```sql

(1=1 or :MA_BIND_VARIABLE IS NULL)
-- Exemple 
DECLARE

l_noart  MGART.ART_NOART%TYPE:=&NOART; 
l_query varchar2(4000):='SELECT art_noart,art_lbarti from MGART WHERE ';
    
BEGIN
	 if l_noart is NULL THEN 
     	l_query := l_query || '(1=1 OR :MA_BIND_NOART IS NULL)';
     else
     	l_query := l_query || ' art_noart=:MA_BIND_NOART ';
     end if;
     execute IMMEDIATE l_query USING l_noart;

END;
/
```
- Exemple avec <i>REF CURSOR</i>

```Sql
DECLARE
   -- cursor qui sert uniquement a la reception des donnees
   -- (equvalanet à la déclaration d'un record)
   CURSOR c_cursor_rec
   IS
      SELECT art_noart, art_lbarti
        FROM mgart;

   -- declaration du type de curseur dynamique
   TYPE refcur IS REF CURSOR;

   -- declaration du curseur dynamique
   c_cursor_dyna   refcur;
   -- le record basé sur la définition de la structure du SELECT
   rec_data        c_cursor_rec%ROWTYPE;
   --
   l_noart         mgart.art_noart%TYPE   := NULL;
   -- la requete dynamique ( la structure du SELECT doit correspondre  a la structure du
   -- cursor c_cursor_rec
   l_query         VARCHAR2 (4000)        := 'SELECT art_noart,art_lbarti from MGART WHERE ';
BEGIN
   IF l_noart IS NULL
   THEN
      l_query := l_query || '(   1 = 1
                             OR :ma_bind_noart IS NULL)';
   ELSE
      l_query := l_query || ' art_noart = :ma_bind_noart ';
   END IF;

   OPEN c_cursor_dyna FOR l_query USING l_noart;

   LOOP
      FETCH c_cursor_dyna
       INTO rec_data;

      EXIT WHEN c_cursor_dyna%NOTFOUND;
      DBMS_OUTPUT.put_line ('Art ' || rec_data.art_noart || ' ' || rec_data.art_lbarti);
   END LOOP;

   CLOSE c_cursor_dyna;
END;
/

```

### éviter les row cache lock

#### 1- Bind variables dans les requêtes en générale

<br> Il est nécessaire (voir <b>impératif</b>) de "variabiliser" des requetes ("bind variable" ou "variable hotes") </br>

<br>Note : Le paramètre Oracle <b>CURSOR_SHARING</b> influence grandement le comportement des requête au niveau de l'optimiseur Oracle
<br>(cf http://www.polymorphe.org/index.php/oracle-11g-adaptive-cursor-sharing)

<u><i>Exemple </i></u>
```Sql 
-- soit les requêtes suivantes : 
--======================
-- Requete 1 
--======================
SELECT TRIM(VCO_ZNVLRUBD) 
FROM MGVCO 
WHERE VCO_DSLOGORI = 'METI' 
  AND VCO_CDRUBORI = 'DRIVE' 
  AND VCO_ZNVLRUBO = 'LIB_ART1';
 
--======================
-- Requete 2
--======================
SELECT TRIM(VCO_ZNVLRUBD) 
FROM MGVCO 
WHERE VCO_DSLOGORI = 'METI' 
  AND VCO_CDRUBORI = 'DRIVE' 
  AND VCO_ZNVLRUBO = 'LIB_ART2';
  
 --======================
-- Requete 3
--======================
SELECT TRIM(VCO_ZNVLRUBD) 
FROM MGVCO 
WHERE VCO_DSLOGORI = 'METI' 
  AND VCO_CDRUBORI = 'DRIVE' 
  AND VCO_ZNVLRUBO = 'TRI_PREP_PROMO';

  
```
<br> il est préférable de les remplacer par un curseur paramétré 
<br>Même si ces 3 requêtes sont exécutées dans la section init des packages, sinon cela rique de générer des locks au niveau du cache Oracle (<b>ROW CACHE LOCK</b>) </br>
```Sql
declare

cursor 
     c_vco (cp_dslogori IN MGVCO%VCO_dslogori%type,
            cp_CDRUBORI IN MGVCO%VCO_CDRUBORI%type,
            cp_ZNVLRUBO IN MGVCO%VCO_ZNVLRUBOMtype
            )
            
     IS
      	SELECT TRIM(VCO_ZNVLRUBD) 
	FROM MGVCO 
	WHERE VCO_DSLOGORI = cp_DSLOGORI
  	AND   VCO_CDRUBORI = cp_CDRUBORI
  	AND   VCO_ZNVLRUBO = cp_ZNVLRUBO;
    
    v_lib_art1         	MGVCO.VCO_ZNVLRUBD%type;
    v_lib_art2			MGVCO.VCO_ZNVLRUBD%type;
    v_tri_prep_promo	MGVCO.VCO_ZNVLRUBD%type;

BEGIN
	open c_vco(cp_dslogori =>'METI',
               cp_CDRUBORI =>'DRIVE',
               cp_ZNVLRUBO =>'LIB_ART1'
               );
    fetch c_vco into v_lib_art1;
    close c_vco;
    
    open c_vco(cp_dslogori =>'METI',
               cp_CDRUBORI =>'DRIVE',
               cp_ZNVLRUBO =>'LIB_ART2'
               );
    fetch c_vco into v_lib_art2;
    close c_vco;
    
    open c_vco(cp_dslogori =>'METI',
               cp_CDRUBORI =>'DRIVE',
               cp_ZNVLRUBO =>'TRI_PREP_PROMO'
               );               
	fetch c_vco into v_tri_prep_promo;
    close c_vco;
                   
END;
/
```

<br>Note : il est préférable d'utiliser une fonction ici
    
```Sql
declare

v_lib_art1         	MGVCO.VCO_ZNVLRUBD%type;
v_lib_art2	        MGVCO.VCO_ZNVLRUBD%type;
v_tri_prep_promo    MGVCO.VCO_ZNVLRUBD%type;


function get_vco(
            cp_dslogori IN MGVCO%VCO_dslogori%type,
            cp_CDRUBORI IN MGVCO%VCO_CDRUBORI%type,
            cp_ZNVLRUBO IN MGVCO%VCO_ZNVLRUBOMtype
            )return varchar2
IS
retour mgvco.VCO_ZNVLRUBD%type;
cursor 
     c_vco (cp_dslogori IN MGVCO%VCO_dslogori%type,
            cp_CDRUBORI IN MGVCO%VCO_CDRUBORI%type,
            cp_ZNVLRUBO IN MGVCO%VCO_ZNVLRUBOMtype
            )
            
     IS
      	SELECT TRIM(VCO_ZNVLRUBD) 
        FROM MGVCO 
        WHERE VCO_DSLOGORI = cp_DSLOGORI
  	    AND   VCO_CDRUBORI = cp_CDRUBORI
  	    AND   VCO_ZNVLRUBO = cp_ZNVLRUBO;
BEGIN
      open c_vco( 
            pi_dslogori,
            pi_CDRUBORI,
            pi_ZNVLRUBO);
     fetch c_vco into retour;
     close c_vco;
     return(trim(retour));                       

END get_vco;

BEGIN
    
    v_lib_art1:=get_vco(
               		pi_dslogori =>'METI',
               		pi_CDRUBORI =>'DRIVE',
               		pi_ZNVLRUBO =>'LIB_ART1');
               
	v_lib_art2:=get_vco(
                    pi_dslogori =>'METI',
                    pi_CDRUBORI =>'DRIVE',
                    pi_ZNVLRUBO =>'LIB_ART2'
               );
	v_tri_prep_promo:=get_vco(
                    pi_dslogori =>'METI',
                    pi_CDRUBORI =>'DRIVE',
                    pi_ZNVLRUBO =>'TRI_PREP_PROMO'
                    );

END;
/
```

<br>Note : il est préférable d'utiliser un IN (au niveau SQL)

```Sql
declare

cursor 
     c_vco (cp_dslogori  IN MGVCO%VCO_dslogori%type,
            cp_CDRUBORI  IN MGVCO%VCO_CDRUBORI%type,
            cp_ZNVLRUBO1 IN MGVCO%VCO_ZNVLRUBOMtype,
            cp_ZNVLRUBO2 IN MGVCO%VCO_ZNVLRUBOMtype,
            cp_ZNVLRUBO3 IN MGVCO%VCO_ZNVLRUBOMtype
            )
            
     IS
      	SELECT TRIM(VCO_ZNVLRUBD) 
	FROM MGVCO 
	WHERE VCO_DSLOGORI = cp_DSLOGORI
  	AND   VCO_CDRUBORI = cp_CDRUBORI
  	AND   VCO_ZNVLRUBO IN (cp_ZNVLRUBO1,cp_ZNVLRUBO2,cp_ZNVLRUBO3);
    
    v_lib_art1         	MGVCO.VCO_ZNVLRUBD%type;
    v_lib_art2	        MGVCO.VCO_ZNVLRUBD%type;
    v_tri_prep_promo    MGVCO.VCO_ZNVLRUBD%type;

BEGIN
	open c_vco(cp_dslogori =>'METI',
               cp_CDRUBORI =>'DRIVE',
               cp_ZNVLRUBO =>'LIB_ART1','LIB_ART2','TRI_PREP_PROMO'
               );
    fetch c_vco into v_lib_art1,v_lib_art2,v_tri_prep_promo;
    close c_vco;
                       
END;
/
```    


#### 2- Avoir le méme formatage pour les requêtes 

<br> <u>Explication </u></br>
<br> Si 2 requetes <b>identiques</b> sont générées dans un pkg ou 2 pkg différent mais que celles-ci ont un formatage (ou des caratères espaces en plus dans l'une des requêtes ou une casse différente) alors Oracle interprête ses 2 requêtes (pourtant similaire) comme 2 requêtes différentes, et il va donc les garder en cache.
<br> L'inconvénient engendré, est une multitude de requêtes similaire garder en cache, ce qui pénalise l'analyse des requêtes , car Oracle va rechercher dedans celles qu'il a déjà exécuté pour ne pas les re-analyser. </br>
<br> Ensuite Oracle va les stocker en cache, d'ou potentiellement des lock</br>

<br><i><u>Exemple</u></i>
```Sql
Select art_noart from MGART;
```
est différent de 
```Sql
Select art_noart          from MGART;
```
est différent de 
```Sql
Select art_noart          from mgart;
```

est différent de 
```Sql
Select art_noart
from MGART;
```
<br> Faire un <b>tkprof</b> pour visualiser les résultats ici 
<br> Il est donc <b>important</b> d'avoir le même formatage des données pour l'ensemble des développeur.
<br><i><u>exemple</u></i>
<br>
<b>SQL Dévleloppeur</b> :  le formatage est <b>CTRL+F7</b>