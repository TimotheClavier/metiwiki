+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Requete a trou"
author="Timothé Clavier"

[menu.main]
identifier = "SQL-8-Requete a trou"
parent ="SQL-1-SQL"
+++
Auteur:  
Date: 25/08/2016

---------------
### Ne pas afficher le code article si celui de la ligne précédente est le même 

```sql
SELECT   DECODE (LAG (arv_noart,
                      1,
                      -1
                     ) OVER (PARTITION BY arv_noart ORDER BY arv_noart),
                 arv_noart, NULL,
                 arv_noart
                ) AS noart,
         arv_cdfo, arv_novar
    FROM mgarv
   WHERE arv_noart IN (18600869, 18600870, 18600867)
ORDER BY arv_noart, arv_cdfo, arv_novar;
```

<p> On obtient </p>

<p>
	<table border='1' width='90%' align='center' summary='Script output'>
	<tr>
		<th scope="col">NOART</th>
		<th scope="col">ARV_CDFO</th>
		<th scope="col">ARV_NOVAR</th>
	</tr>
	<tr>
		<td>18600867</td>
		<td align="right">19147</td>
		<td align="right">1</td>
	</tr>
	<tr>
		<td>{null}</td>
		<td align="right">24999</td>
		<td align="right">1</td>
	</tr>
	<tr>
		<td>{null}</td>
		<td align="right">25109</td>
		<td align="right">1</td>
	</tr>
	<tr>
<td>
{null}
</td>
<td align="right">
     26307
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     27703
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     28439
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     36461
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     38082
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     39415
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     45030
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     45544
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     46027
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     46989
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     51106
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<th scope="col">
NOART
</th>
<th scope="col">
ARV_CDFO
</th>
<th scope="col">
ARV_NOVAR
</th>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     53940
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     54043
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     55865
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     62778
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     63638
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     68140
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     72190
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     74041
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     74483
</td>
<td align="right">
         2
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     75947
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     79518
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     84626
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     84831
</td>
<td align="right">
         2
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     89402
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<th scope="col">
NOART
</th>
<th scope="col">
ARV_CDFO
</th>
<th scope="col">
ARV_NOVAR
</th>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     89402
</td>
<td align="right">
         2
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     90938
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     93214
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     96715
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
18600869
</td>
<td align="right">
     14859
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     19147
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     24999
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     25109
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     26307
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     27703
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     28439
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     36461
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     38082
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     39415
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<th scope="col">
NOART
</th>
<th scope="col">
ARV_CDFO
</th>
<th scope="col">
ARV_NOVAR
</th>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     45030
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     45544
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     46027
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     46989
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     51106
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     53940
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     54043
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     55865
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     62778
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     63638
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     68140
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     70688
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     72190
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     74041
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<th scope="col">
NOART
</th>
<th scope="col">
ARV_CDFO
</th>
<th scope="col">
ARV_NOVAR
</th>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     74483
</td>
<td align="right">
         2
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     75947
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     79518
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     84626
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     84831
</td>
<td align="right">
         2
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     89402
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     90938
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     93214
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     96715
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
18600870
</td>
<td align="right">
     14859
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     19147
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     24999
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     25109
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     26307
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<th scope="col">
NOART
</th>
<th scope="col">
ARV_CDFO
</th>
<th scope="col">
ARV_NOVAR
</th>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     27703
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     28439
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     36461
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     38082
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     39415
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     45030
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     45544
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     46027
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     46989
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     51106
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     53940
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     54043
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     55865
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     62778
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<th scope="col">
NOART
</th>
<th scope="col">
ARV_CDFO
</th>
<th scope="col">
ARV_NOVAR
</th>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     63638
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     68140
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     70688
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     72190
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     74041
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     74483
</td>
<td align="right">
         2
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     75947
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     79518
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     84626
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     84831
</td>
<td align="right">
         2
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     90938
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     93214
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td>
{null}
</td>
<td align="right">
     96715
</td>
<td align="right">
         1
</td>
</tr>
</table>
<p>
<br>
<br>


### Gerer des ruptures avec OVER PARTITION Max 

<br>Exemple permettant d'indiquer la ligne Entete par rapport à un détail

```Sql
SELECT vue.*
    FROM (SELECT fld_nolign,
                 fld_zncle1,
                 MAX (CASE fld_zncle1
                         WHEN 'T' THEN fld_nolign
                         ELSE 0
                      END)
                 OVER (ORDER BY fld_nolign)
                    AS ligne_entete
            FROM mgfld
           WHERE fld_cdflux = 'U115_REFART' AND fld_notrait = 408632) vue
   --WHERE fld_zncle1 = 'R'
ORDER BY fld_nolign;

```

<table border=1 cellspacing=1 cellpadding=1 width="100%">
  <tr>
  <th align="left" bgcolor="#C0C0C0" bordercolor="#FFFFFF">FLD_NOLIGN</th>
  <th align="left" bgcolor="#C0C0C0" bordercolor="#FFFFFF">FLD_ZNCLE1</th>
  <th align="left" bgcolor="#C0C0C0" bordercolor="#FFFFFF">LIGNE_ENTETE</th>
  </tr>
  <tr>    <td nowrap><div align=right>1</div></td>
    <td nowrap>T              </td>
    <td nowrap><div align=right>1</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>2</div></td>
    <td nowrap>T              </td>
    <td nowrap><div align=right>2</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>3</div></td>
    <td nowrap>R              </td>
    <td nowrap><div align=right>2</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>4</div></td>
    <td nowrap>T              </td>
    <td nowrap><div align=right>4</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>5</div></td>
    <td nowrap>R              </td>
    <td nowrap><div align=right>4</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>6</div></td>
    <td nowrap>R              </td>
    <td nowrap><div align=right>4</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>7</div></td>
    <td nowrap>R              </td>
    <td nowrap><div align=right>4</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>8</div></td>
    <td nowrap>R              </td>
    <td nowrap><div align=right>4</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>9</div></td>
    <td nowrap>R              </td>
    <td nowrap><div align=right>4</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>10</div></td>
    <td nowrap>R              </td>
    <td nowrap><div align=right>4</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>11</div></td>
    <td nowrap>R              </td>
    <td nowrap><div align=right>4</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>12</div></td>
    <td nowrap>R              </td>
    <td nowrap><div align=right>4</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>13</div></td>
    <td nowrap>R              </td>
    <td nowrap><div align=right>4</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>14</div></td>
    <td nowrap>R              </td>
    <td nowrap><div align=right>4</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>15</div></td>
    <td nowrap>R              </td>
    <td nowrap><div align=right>4</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>16</div></td>
    <td nowrap>R              </td>
    <td nowrap><div align=right>4</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>17</div></td>
    <td nowrap>T              </td>
    <td nowrap><div align=right>17</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>18</div></td>
    <td nowrap>R              </td>
    <td nowrap><div align=right>17</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>19</div></td>
    <td nowrap>R              </td>
    <td nowrap><div align=right>17</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>20</div></td>
    <td nowrap>R              </td>
    <td nowrap><div align=right>17</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>21</div></td>
    <td nowrap>T              </td>
    <td nowrap><div align=right>21</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>22</div></td>
    <td nowrap>T              </td>
    <td nowrap><div align=right>22</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>23</div></td>
    <td nowrap>R              </td>
    <td nowrap><div align=right>22</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>24</div></td>
    <td nowrap>T              </td>
    <td nowrap><div align=right>24</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>25</div></td>
    <td nowrap>R              </td>
    <td nowrap><div align=right>24</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>26</div></td>
    <td nowrap>R              </td>
    <td nowrap><div align=right>24</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>27</div></td>
    <td nowrap>R              </td>
    <td nowrap><div align=right>24</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>28</div></td>
    <td nowrap>R              </td>
    <td nowrap><div align=right>24</div></td>
  </tr>
  <tr>    <td nowrap><div align=right>29</div></td>
    <td nowrap>R              </td>
    <td nowrap><div align=right>24</div></td>
  </tr>
</table>
