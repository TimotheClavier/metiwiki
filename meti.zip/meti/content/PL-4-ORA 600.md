+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "ORA 600"
author="Timothé Clavier"

[menu.main]
identifier = "PL-3-ORA 600"
parent ="PL-1-PLSQL"
+++
Auteur:  
Date: 13/12/2016

---------------
## Trouver l'erreur ORA-600 (Erreur Interne à Oracle)

### 1- Méthode de recherche

- 
Exemple ORA-00600: internal error code, arguments: [13013], [5001], [4722], [29361923], [9], [29361923], [17], []

####  - Signification de l'erreur
ORA-600 [13013] [a] [b] [c] [d] [e] [f]

Ce format est valable au moins pour Oracle Server 8.0.3 à  10.1

		Arg [a] Passcount
		Arg [b] Data Object number
		Arg [c] Tablespace Relative DBA of block containing the row to be updated
		Arg [d] Row Slot number
		Arg [e] Relative DBA of block being updated (should be same as [c])
		Arg [f] Code

#### - Déterminer l'objet ayant soulevé l'erreur
	
-
Le 2eme argument devrait donnée l'objet Ib concerné (ici b)


``` sql
	SELECT object_name,object_type,owner 
	FROM dba_objects 
	WHERE data_object_id=<valeur reporté dans l'argment b>;
```

#### - Vérifier si le bug est connu sur le web 
	
-
Recherche l'erreur avec le 1er argument et la version oracle (ora 11.2.0.4 par exemple)
exemple : ORA-600 [13013]

#### - Envoyer les résultats aux DBA

Suivant les résultats obtenu précédemment, contacter ou non les DBA pour la résolution du pb.
<br>
(Ici, dans notre exemple, il suffit de recréer l'indexe)

## ORA-07445 (Erreur interne à Oracle niveau environnement)

```Sql
No more data to read from socket -- SQL state 08000 -- Code 17410
```
<br> Cette erreur est "l'autre" erreur générique Oracle.
<br> Pour avoir plus de détail il faut vérifier dans le fichier de log Oracle sous le répertoire indiqué dans le paramètre d'environnement <b><i>user_dump_dest</i></b> et régarder plus en détail dans le fichier de log des incidents et alertes l'origine du pb. 
<br>Cela peut être un pb réseaux, mémoire trop juste, un bloc de connée corrompus etc...

## ORA-600 Connu  : 

|Version Oracle|Erreur | Symptome |Solution |Release fixe|#Msp|
|--:| :------------- |:-------------|:-----------|---------|------------|
|11.2.0.2.0 |ORA-00600: code d'erreur interne, arguments : [kcbchg1_16], [], [], [], [], [], [], [], [], [], [], []|  jointure fetch fld+gtt(rer)| PSU par DBA|Necessite upgrade version 11.2.0.2.6 + OPatch PSU|||
|11.2.0.2.0 |ORA-00600: code d'erreur interne, arguments : [ktsfbfmt:objdchk_kcbnew_3], [2], [4663936], [0], [], [], [], [], [], [], [], []| Insert sur gtt (rer)| PSU par DBA, sauf pas de patch en 32bit|Fixed in 11.2.0.3||
|11.2.0.2.0 |ORA-00600: code d'erreur interne, arguments : [ktsfbfmt:objdchk_kcbnew_3], [2], [4648704], [0], [], [], [], [], [], [], [], []| Insert sur gtt (rer)| PSU par DBA, sauf pas de patch en 32bit|Fixed in 11.2.0.3||
|11.2.0.2.0 |ORA-00600: code d'erreur interne, arguments : [kdlwdb:objdchk_kcbnew_3], [0], [4715392], [4], [], [], [], [], [], [], [], []| Insert sur gtt (rer)| PSU par DBA, sauf pas de patch en 32bit|Fixed in 11.2.0.3||
|11.2.0.2.0 |ORA-00600: code d'erreur interne, arguments : [kkmupsViewDestFro_4] ou [qksdmlMrgViewDestFro_4] -> bug no 18175718 | from MERGE SQL | Contournement a mettre dans l'init  , set "_optimizer_enable_table_lookup_by_nl" enabled. (false par default)| Server patch set in 12.1.0.2, Fixed in 12.2 (Futur release)|

## ORA-7445 Connu  : 

|Version Oracle|Erreur | Symptome |Solution |Release fixe|#Msp|
|--:| :------------- |:-------------|:-------|------------|----------|
|11.2.0.2.0 |ORA-7445 [kxccexi]  (bug no 11056082) | Merge/update sur table avec au moins 2 colonne, une de la pk et l'autre de la fk pointant sur la pk (self-join type MGAUL) et les 2 colonnes sont indexes (rer)|Modifier la requete (bug confirmer sur 11.2.0.1 et 11.2.0.2) |11.2.02.7 Database Patch set, 11.2.0.3 Server Patch Set,12.1.0.1 Base release|72177|

  
- repertoire des patchs Oracle : 
```Bash
$ORACLE_HOME/oraInventory/logs
```