+++
date="2017-05-16T15:12:23+02:00"
draft="true"
title="Gestion des serveurs du pole édition"

[menu.main]

identifier="DI-5-Gestion des serveurs du pole édition"
parent="DI-1-Divers"

+++
Auteur:  
Date: 12/01/2017

----------------------
## 1- Serveur de developpement

#### Maintenance de la base oracle (MAG11)

<br></br> Depuis le 13 avril 2016, les jobs de maintenance Oracle (Calcul des stats, etc...) sont désactivés la semaine.
<br></br> Ils ne sont réalisés dorénavant que le Week-end
![Menu preference](http://lxdev03:3004/resources/divers/plan_maintenance_rec11.jpeg)

### Planning des maj  


| Action|Instance| Schemas| Frequence|
|-----------|:-----------:|:-----------:|---------|  
|Mise à jour en différentiel du modèle| MAG11|Tous|midi/soir|
|| RECDEV|Tous|midi/soir|
|Mise à jour des programmes commité| RECDEV|Tous|midi|
|| MAG11|MLIB|midi|
|Mise à jour des dat commité| RECDEV|Tous(sauf RFMETI)|midi/soir|
|| MAG11|Tous|dimanche|
|| MAG11|MLIB|midi/soir|
|Delete et Réinstallation de tous les programmes standard| MAG11|Tous|dimanche|
|| MAG11|MLIB|Soir|
|| RECDEV|RFMETI|Soir|
|Delete et Réinstallation de tous les programmes spécifique|MAG11|Tous|dimanche|
|| RECDEV|RFMETI|Soir|


(Note : pour le spécifique cf tableaux ci-dessous pour la liste)
 

### entités Client installées par schémas Oracle
 
|Instance|Schemas|Entités|
|------------|:--------:|:----------:|
|<b>MAG11</b>|
| |bampro|mlib std|
| |casexpor|mlib std|
| |cusse9|mlib std|
| |metiref|mlib std e1|
| |welcen|mlib std e5 p74|
| |sufplp|mlib std c2031|
| |cefplp|mlib std c2031|
| |ent030|mlib std e5 p74|
| |px0100|mlib std c125|
| |px0500|mlib std c125|
| |px0516|mlib std c125|
| |idrdsm|mlib std c4305|
| |dpibcp|mlib std p78|
| |hypcen|mlib std|
| |hyp011|mlib std e7|
| |metisp|mlib std|
| |mlib|mlib|
| |dpi|mlib std c3300 p78|
| |uacemd|mlib std e1 p79 c31 c2475|
| |uae1md|mlib std e1 p79 c31 c2475|
| |lpmcen|mlib std p74|
| |lpment|mlib std p74|
| |pruace|mlib std p74|
| |pruae1|mlib std p74|
| |hypvde|mlib std p74 e5|
| |cash01|mlib std c2400 e1 p74|
| |cashce|mlib std c2400 e1 p74|
| |portal|mlib std|
| |cenvde|mlib std p74|
| |entvde|mlib std p74|
| |magdrv|mlib std p74 c1200 p75 p73|
| |cendrv|mlib std p74 c1200 p75 p73|
| |entdrv|mlib std p74 c1200 p75 p73|
|<b>RECDEV</b>| | |
| |rfmeti|mlib std c2030 c125 e5 c2400 e1 c3102 p74 c3130 c4305 p76 c2500 c2560 p72 g50 e2 c2100 c2540 c2520 c2535 c560 c2300 c2430 c2440 c2530 p79 c450 c405 c31 c2475 c2031 c3101 e3 c440 c2065 c1200 p75 pp73 c3300|
| |mag551|mlib std c2030 e2|
| |lpcent|mlib std c2030 e2|
| |px8823|mlib std c125 e3 c440|
| |px6329|mlib std c125 e3 c440|
| |welcen|mlib std e5 p74|
| |ent030|mlib std e5 p74|
| |ent010|mlib std e5 p74|
| |welmag|mlib std e5 p74|
| |hypcen|mlib std c2400 e1 p74|
| |hyp011|mlib std c2400 e1 p74|
| |hyp010|mlib std c2400 e1 p74|
| |cash01|mlib std c2400 e1 p74|
| |cashce|mlib std c2400 e1 p74|
| |forma|mlib std c2400 e1 p74|
| |hypent|mlib std c2400 e1 p74|
| |hypen2|mlib std c2400 e1 p74|
| |mbri01|mlib std c2400 e1 p74|
| |mbrice|mlib std c2400 e1 p74|
| |ppcash|mlib std c2400 e1 p74|
| |cenrun|mlib std c3102|
| |ent800|mlib std c3102|
| |mag780|mlib std c3102|
| |mag810|mlib std c3102|
| |rbrice|mlib std c3130 p74|
| |rbri01|mlib std c3130 p74|
| |rbri02|mlib std c3130 p74|
| |rbripf|mlib std c3130 p74|
| |cdcent|mlib std p76 e1 c2500 c2540 c2560 p72 g50|
| |hyp011_rct|mlib std|
| |hypcen_rct|mlib std|
| |hyp068_rct|mlib std|
| |cenrun_rct|mlib std|
| |mag780_rct|mlib std|
| |ataexp|mlib std c2100|
| |lvcent|mlib std c2520|
| |lventr|mlib std c2520|
| |lvramb|mlib std c2520|
| |luxcen|mlib std e1 c2535 c2400 p74 p79 c31 c2475|
| |lux001|mlib std e1 c2535 c2400 p74 p79 c31 c2475|
| |luxent|mlib std e1 c2535 c2400 p74 p79 c31 c2475|
| |ard010|mlib std c560|
| |hyp011_auc|mlib std e1 c2300 c2400 c2430 c2440 c2530|
| |hypcen_auc|mlib std e1 c2300 c2400 c2430 c2440 c2530|
| |trroce|mlib std e1 p79 c31 c2475|
| |trroe1|mlib std e1 p79 c31 c2475|
| |aeeen1|mlib std e1 p79 c31 c2475|
| |aeecen|mlib std e1 p79 c31 c2475|
| |fof001|mlib std c450|
| |fop101|mlib std c450|
| |secent|mlib std c405|
| |se4001|mlib std c405|
| |cefplp|mlib std c2031|
| |sufplp|mlib std c2031|
| |frabas|mlib std c3101|
| |uacemd|mlib std e1 p79 c31 c2475|
| |uae1md|mlib std e1 p79 c31 c2475|
| |deli001|mlib std c2065|
| |deli002|mlib std c2065|
| |delice|mlib std c2065|
| |delisup|mlib std c2065|
| |hypvde|mlib std p74 e5|
| |lpmcen|mlib std|
| |lpment|mlib std|
| |pruae1|mlib std|
| |pruace|mlib std|
| |hypcen_apro|mlib std|
| |hyp068_apro|mlib std|
| |cenvde|mlib std p74|
| |entvde|mlib std p74|
| |magdrv|mlib std p74 c1200 p75 p73|
| |cendrv|mlib std p74 c1200 p75 p73|
| |entdrv|mlib std p74 c1200 p75 p73|
| |magcen|mlib std c2400 e1 p74|
| |magent|mlib std c2400 e1 p74|
| |mag001|mlib std c2400 e1 p74|
| |mag002|mlib std c2400 e1 p74|
| |dpi|mlib std c3300|
| |cenrun_mat|mlib std|
| |mag780_mat|mlib std|
| |hyp011_mat|mlib std|
 



## 2- Serveurs Multi-version

### Maj des patchs

#### journalière 

- Tous les <b>10</b> minutes de <b>8-18h</b> du lundi au vendredi (avec récupération des objets Oracle invalide)

- Recup des objets Oracle invalide : <b>6h45</b> et <b>12h45</b> du lundi au vendredi

#### hebdomadaire 

- Patch Full : <b>19h</b> le dimanche

- Archive des logs : <b>18h</b> le dimanche

#### mensuel 

Le 1er dimanche du mois 

- drop des schémas Oracle
- Installation de la version 
- Patch Full de la version
