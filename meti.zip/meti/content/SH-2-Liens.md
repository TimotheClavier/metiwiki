+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Liens"
author="Timothé Clavier"

[menu.main]
identifier = "SH-3-Liens"
parent ="SH-1-Shell"
+++
Auteur:  
Date: 28/03/2017

---------------
- [http://explainshell.com/](http://explainshell.com/)
- [http://www.shellcheck.net/](http://www.shellcheck.net/)
- [Advanced Bash Scripts ou ABS (Guide avancé d'écriture des scripts Bash)](http://abs.traduc.org/abs-fr/)
- [<b> vi </b> Commande de base <b>(Kit de survie)</b>](http://lxdev03:3004/resources/shell/vi_memento_fr.pdf)