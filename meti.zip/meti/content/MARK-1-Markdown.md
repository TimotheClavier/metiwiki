+++
date = "2017-05-17T11:46:16+02:00"
draft = true
title = "Markdown"
author="Timothé Clavier"
[menu.main]
identifier="MARK-1-Markdown"
+++

<h2<Aide pour Markdown<h2>  


Voilà des sites explicatifs sur le markdown et des aides pour l’écriture

[Tutoriel](https://blog.wax-o.com/2014/04/tutoriel-un-guide-pour-bien-commencer-avec-markdown/)  
  
  
[Syntaxe](http://www.haddok.fr/wp-content/uploads/2011/03/syntaxe-markdown.pdf)

