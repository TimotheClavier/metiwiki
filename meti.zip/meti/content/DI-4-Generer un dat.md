+++
date="2017-05-16T15:12:23+02:00"
draft="true"
title="Generer un dat"

[menu.main]

identifier="DI-4-Generer un dat"
parent="DI-1-Divers"

+++
Auteur:  
Date: 28/03/2017

----------------------

### Création d'un script dat et les gtt associées


<B>Pré-requis :</b> Ncécessite d'avoir déjà créer en base la structure MGFLX/MGFAD/MGFIC/MGFID

A partir du code flux, un traitement va générer les fichiers dat et les scripts gtt associés dans le répertoire indiqué ou suivant la scrupture classique ($METI_HOME/transfer/CODE_SITE/DOSSIER/central) du serveur applicatif Linux

- Taitement

![Menu preference](http://lxdev03:3004/resources/divers/lancement_genere_dat.jpg)
 
 
- Liste des paramètres  
<br></br>


-----------------
|Parametre|Type|Commentaire|Valeur défaut|Obligation|
|--------------|:---------:|-----------|--------|--------------|
|PAR_CDFLUX|A|code Flux||Oui|
|CONCAT_GTT_O_N|A1|Concaténer toutes les gtt dans le même fichier(O/N)|N||
|COLONNE_CDETAT|A30|Nom de la colonne cdetat (gtt)|CDETA||
|COLONNE_CDANO|A30|Nom de la colonne cdano (gtt)|CDANO||
|COLONNE_COMMENTAIRE|A30|Nom de la colonne commentaire (gtt)|COMMENTAIRE||
|FLG_A_PARTIR_TABLE_REEL_O_N|A1|Génération à partir d'une table réélle (O/N)|N||
|NOM_TABLE_REELLE|A30|Nom de la table réelle (fonctionne avec le aprametre précédent|||
|GENERER_AUSSI_ZONE_ACTIVE_O_N|A1|Rajouter que les zones du dat actives(O/N)|N||
|GENERER_AUSSI_ZONE_A_EDITER_O_N|A1|Rajouter que les zones du dat éditer à vrai(O/N)|N||
|FLG_RAJOUTER_VAL_DEFAUT_O_N|A1|Rajouter des valeurs défault sur les colonnes de la gtt (numérique => DEFAULT 0)|N||
|SUFFIXE_FICHIER_DAT|A|nom du suffixe du dat|||
|PREFIXE_FICHIER|A|préfixe du fichier dat générer |code flux||
|SUFFIXE_FICHIER_DAT|A|nom du suffixe du dat|||
|REP_SORTIE|A|Repertoire ou sera générer les fichiers dat et script gtt|||
|FLG_CREER_FIC_GTT_O_N|A1|générer les scripts gtt (O/N)|O||
|FILTRE_MGFIC|A|Gnénérer uniquement pour un flux données ques les MGFIC listé séparé par un ;|||




