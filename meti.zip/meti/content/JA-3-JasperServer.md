+++
date="2017-05-18"
draft="true"
title="Jasper Server"
author="Timothé Clavier"

[menu.main]
identifier="JA-3-JasperServer"
parent="JA-1-Jasper"
+++
Auteur:  
Date: 25/08/2016  

------------------

## Ligne de commande 
### redemarrage des serveurs
- Jasper dev-g1 sur lxdev03
```Bash
service jasperserver-dev-g1 stop
service jasperserver-dev-g1 start
```

### Liste des ressources

- Utilisation de service REST : 

```Bash
curl -u jasperadmin:jasperadmin --request GET http://$(hostname):8090/jasperserver/rest/resources/METI/emag

 ```


### Suppression de ressource

- Utilisation de service REST : 

```Bash
curl -u jasperadmin:jasperadmin --request DELETE http://$(hostname):8090/jasperserver/rest/resource/METI/emag/spec/P76/

 ```
 
 
### Web service
 
 http://172.16.10.3:8090/jasperserver/services/repository?wsdl
 
 - Liste des services : 
 <br> utilisation de l'extension Chrome <b><i>Wizdler</i></b>
 <br> Puis renseignement des paramètres