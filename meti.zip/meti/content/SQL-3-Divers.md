+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Divers"
author="Timothé Clavier"

[menu.main]
identifier = "SQL-3-Divers"
parent ="SQL-1-SQL"
+++
Auteur:  
Date: 29/09/2016

---------------
### Fonction de type caractères

  - création de Hash value 
  ```Sql
  select ORA_HASH('<buffer>ceci est un test</buffer>') from dual;
  ``` 
  <br>retourne un PLS_INTEGER</br>
 
- Filtrer les données avec LIKE et ESCAPE
 
<br> Comment utiliser les signes '_' et '%' dans une requête avec LIKE étant données qu'ils sont les car. par défaut utlisé par LIKE ?.

<br>Exemple : Je veux toutes les colonnes avec EMP_ :

```Sql 
	SELECT table_name FROM user_tab_columns
     WHERE column_name LIKE 'EMP_%';
```

On obtient non seulement les colonnes avec EMP_ mais aussi ENMPR,MGEMP etc...

Pour ne pas considérer le car '_' comme un car. spéciales il faut dans ce cas uutiliser le mot clé ESCAPE. Basiquement un slash '\' mais n'importe quel autre car. fonctionne.

```Sql 
     SELECT table_name FROM all_tables
     WHERE table_name LIKE 'EMP\_%' ESCAPE '\';
```

### Fonction de type date

  - milliseconde (millieme)  

```Sql
select to_char(SYSTIMESTAMP,'HH24:MI:SS:FF3') from dual;
```
- Jour Heure en local

```Sql 
SELECT    TO_CHAR (SYSDATE, 'YYYY-MM-DD')
       || 'T'
       || TO_CHAR (SYSDATE, 'HH24:MI:SS')
       || SUBSTR (TO_TIMESTAMP_TZ (SYSDATE, 'YYYY-MM-DD HH24:MI:SS'), -7)
  FROM DUAL;
  
```
<br> on obtient 2015-09-01T16:26:23 +02:00

- Formatter suivant un fuseau horaire

```Sql
SELECT TO_TIMESTAMP_TZ (TO_CHAR (SYSDATE, 'DD/MM/YYYY HH24:MI:SS') || ' GMT',
                        'DD/MM/YYYY HH24:MI:SS TZR')
          AT TIME ZONE 'Turkey'
  FROM DUAL;

SELECT TO_TIMESTAMP_TZ (TO_CHAR (SYSDATE, 'DD/MM/YYYY HH24:MI:SS') || ' GMT',
                        'DD/MM/YYYY HH24:MI:SS TZR')
          AT TIME ZONE ' Europe/Paris'
  FROM DUAL;

  
```
   - Liste des fuseaux Oracle 
 
 https://docs.oracle.com/cd/B13866_04/webconf.904/b10877/timezone.htm

   - Datetime Datatypes aet Time Zone Support

 https://docs.oracle.com/cd/B28359_01/server.111/b28298/ch4datetime.htm#i1006081


     
### Environnement SQL PLUS (sous windows)
#### Client <b><u>avant</u></b> Oracle 11 g
 - <u> Variable d'environnement </u>  
  <br> Le fichier <i><b>glogin.sql</b></i> permet d'initialiser toutes ces variables de sessions préférées  <i>(NLS_LENGTH_SEMANTICS, Prompt etc ....)</i>
  
  	-	<b>Paramétrage (sous Windows/linux) </b>:
  <br> Ce fichier est par défaut sous <i> %ORACLE_HOME%\sqlplus\admin\glogin.sql </i>
  <br> Le nom du fichier doit respecter la casse et doit être <i><b>glogin.sql</b></i>
    
  	- <b>Changer son éditeur par défault </b>: 
  <br> Dans le fichier glogin.sql rajouter la variable suivante : 
  
  ```Sql
  define _editor="<Endroit ou se trouve mon éditeur préféré>"
  ```
  
  <i><u>Exemple</u></i>: 
  
  ```Sql
  define _editor="C:\METI\tools\Notepad++Portable\Notepad++Portable.exe"
  ```

  	- <b>Visualiser les nombres très grand (genre EAN_CD)</b>: 
  <br> Dans le fichier glogin.sql rajouter la variable 
  
	```Sql
	column ean_cd format 9999999999999
	```
<br> Autre possibilité (pour les autres colonnes)
	
	```Sql
	set numformat "99999999999999.9999"
	```

  
#### Client <b><u>après</u></b> Oracle 11 g  

<br> Depuis la version 11g, l'utilitaire <b>SQLPLUS<u>W</u></b> n'est plus fournit. Celui-ci est déprécié et Oracle préconise l'utilisation de SQL Developer.
<br> seul existe sur le client léger l'utilitaire SQLPLUS.exe.
<br> Il existe 2 fichiers de personnalisation des variables d'environnement :
<br>- Le fichier <b>glogin.sql</b>    
<br>- Le fichier <b>login.sql</b>

##### <b><u>Paramétrage du glogin.sql</u></b>
<br> Pour accéder au fichier <b>glogin.sql</b>, il est nécessaire de précier la variable d'environnement <b><i>SQLPATH</i></b> avec le répertoire ou se trouve le fichier <b>glogin.sql</b>
<br>Cette variable peut être fixée soit en local soit au niveau du paramétrage des variables d'environnement Windows( si accès en mode Administrateur)

<i>Exemple</i>
```Bash 
set SQLPATH="c:\meti\mes_scripts_perso\"
```
<br> Le lancement de <i>SQLPLUS.exe</i> prend alors en compte le fichier <b><i>glogin.sql</i></b>


##### <b><u>Méthode 1 </u></b>
 - <b>Paramétrage de sqlplus.exe via .bat du fichier login.sql</b>
 <br>Faire un fichier de commande .bat et incluant un répertoire de démarrage, les variables local d'environnement.
 
<i><u>Exemple</u></i>
``` Bash
set NLS_DATE_FORMAT=DD/MM/YYYY
set NLS_NUMERIC_CHARACTERS=.,
set NLS_SORT=BINARY
set NLS_LENGTH_SEMANTICS=CHAR
set PATH=%PATH%;<Mon_repertoire_Sqlplus>
start /D <mon_repertoire_de_demarrage>  sqlplus.exe
```
<br> soit <i>mon_repertoire_de_demarrage</i> = c:\meti\mes_scripts_perso\
<br>Une fois connecté sous sqlplus, je vais créer un fichier <i><b>login.sql</b></i>.
```Sql
ed login.sql
```

<br> Dans ce fichier je vais mettre mes infos de session préférés.
```Sql
COL db_name 	new_value db_name 
COL db_name2 	new_value db_name2 
COL qui 	new_value qui

select 'User: '|| user || ' on database ' || global_name,
       '  (term='||USERENV('TERMINAL')||
       ', audsid='||USERENV('SESSIONID')||')' as MYCONTEXT
from   global_name;

set lines 400
select user db_name from global_name;
select global_name db_name2 from global_name;
select USERENV('TERMINAL') qui from global_name;
set termout on
SET define "&"
SET SQLPROMPT "&qui\&db_name2\&db_name>"

define _editor="C:\METI\tools\Notepad++\Notepad2.exe"
```
<br>- je vais vérifier que le fichier existe sous mon répertoire de démarrage (défini précédemment).
<br>- je me reconnecte pour vérifier que mes paramètres ont bien été pris en compte sous SQLPLUS

##### <b><u>Méthode 2 </u></b>
- [<b>Utilisation sans .bat</b>]

(http://www.williamrobertson.net/documents/sqlplus-setup.html)

### Liste des commandes sous Sql Plus
- [SQL*Plus® User's Guide and Reference](http://docs.oracle.com/cd/E11882_01/server.112/e16604/ch_twelve040.htm#SQPUG060)