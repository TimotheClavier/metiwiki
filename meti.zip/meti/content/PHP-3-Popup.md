+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Popup"
author="Timothé Clavier"

[menu.main]
identifier = "PHP-3-Popup"
parent ="PHP-1-PHP"
+++
Auteur:  
Date: 02/09/2016

---------------
# Hook manager

### Ecran principal
- <b>Script 1</b>
<br> Visible lorsqu'on passe un point de dév en recettage dans MetiSP


```Php
<?php
// Script 1
	echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">';
	echo '<html>';
		echo '<head>';
			echo fnc_init_JS();
			// Creation de la variable controle de checklist (init = false mais peu importe vu que la variable passe false au clic bouton avant la popup)
			echo '<script type="text/javascript">var checklist_ok = false;</script>';
			echo '<title>titre</title>';
		echo '</head>';
		echo '<body>';
			echo '<form action="'.getsrc('msp','std_meti/POINT/msp_POINT_g_SPPTS_SAI.php?p_type_appel='.$pp_type_appel.'&p_cdcat='.$cdcat.'&p_nopts='.$nopts,'php').'" name="FRM_SPPTS" id="FRM_SPPTS" method="POST">';
			// Au clic du bouton on n'a pas encore valide ou annule la checklist
			$hook_action  = 'checklist_ok = false;';
			// Hook pour bloquer l'execution
			$hook_action .= 'var deferredObject = HookManager.addHook();';
			// Ouverture de la popup de checklist
			$hook_action .= 'OpenWindow(\''.getsrc('msp','std_meti/UTIL/msp_UTIL_checklist_dev.php','php').'\',';
			$hook_action .=            '\'\',';
			$hook_action .=            '\'\',';
			// Evenement onclose sur la popup
			$hook_action .=            '{\'onclose\' : function(){';
			// Si on a clique OK
			$hook_action .=                                     'if (checklist_ok) {';
			// Action de lancement des procs
			$hook_action .=                                                        ''.$action.'';
			$hook_action .=                                                        '}';
			$hook_action .=                                                        'else';
			$hook_action .=                                                        '{';
			// Sinon on stoppe tout
			$hook_action .=                                                        'Event.stop(event);';
			$hook_action .=                                                        '}';
			// On ferme le Hook
			$hook_action .=                                     'deferredObject.resolve();';
			$hook_action .=                                     '}';
			$hook_action .=            '}';
			$hook_action .=            ');';
				echo '<button onclick="'.$hook_action.'">'._('LIB_LANCER').'</button>';
			echo '</form>';
		echo '</body>';
	echo '</html>';
?>
```

### Ecran popup
- <b>Script 2</b>

```Php

<?php
// Script 2
	// Popup de controle de la checklist de dev au passage d'un point en recette
	echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">';
	echo '<html>';
		echo '<head>';
			echo "<link rel=\"stylesheet\" href=\"".getsrc('msp',"common.css","css")."\" type=\"text/css\">";
			echo fnc_init_JS();
		echo '</head>';
		echo '<body>';
			echo '<iframe src="'.getsrc('metilib','comp/emag_m_comp.php?p_nogci=13055','php').'" scrolling="AUTO" id="cmp_13055" frameborder="NO" _dimensionAuto="O" style="width:100%;">';
			echo '</iframe>';
			echo '<br /><br />'._('MES_MSP_UTIL_CHECKLIST_DEV').'<br />';
			echo '<button onclick="_opener().checklist_ok = true;_close();" class="btn btn-primary header_btn_white">'._('LIB_OK').'</button>';
			echo '<button onclick="_close();" class="btn btn-primary header_btn_white">'._('LIB_ANNULER').'</button>';
		echo '</body>';
	echo '</html>';
?>
```

- <b>Popup résultat</b>

![Popup_resultat](http://lxdev03:3004/resources/php/popup_hookmanager.png)