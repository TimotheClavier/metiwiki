+++
draft = true
title = "Astuces Eclipse"
description = ""
date = "2017-01-16"
author="Timothé Clavier"

[menu.main]
identifier="E-2-Astuces"
parent="E-1-Eclipse"

+++
Auteur:  
Date: 16/01/2017

---------------------

## Guide de création de projet

[dev_GUID_crea_config_proj_java.odt](http://lxdev01:8080/docs/trunk/Developpement/dev_GUID_crea_config_proj_java.odt)


## Librairie meti-libraries

Depuis la version 9022, la meti-libraries est versionnée.

Pour la prendre en compte il faut d'abord faire un checkout du projet disponible ici : http://lxdev01:8080/metidev/(trunk ou tags/version)/allapp/trunk/meti-libraries

![](/resources/eclipse/eclipse-lib.png)


## Accélérer Eclipse

### Désactiver les "validator"

Dans window > preferences

![](/resources/eclipse/disabled_validation.png)


### Désactiver le "spellchecking"

Dans window > preferences

![](/resources/eclipse/spellcheck.png)

## Divers

### Exporter ses préférences

Dans File > export

![](/resources/eclipse/export_prefs.png)

Pour l'import aller dans File > Import

L'export exporte toutes les préférences du workspace !

### Afficher les caractères spéciaux

Dans window > preferences

![](/resources/eclipse/special_chars.png)


### Supprimer automatiqument les espaces en fin de ligne

Dans window > preferences

![](/resources/eclipse/remove_trailing_whitespaces.png)

### Supprimer automatiquement les imports inutiles

Dans window > preferences

![](/resources/eclipse/remove_unused_import.png)


### Plugin SVN Subversive : Activer la console

Dans window > preferences

![](/resources/eclipse/svn_show_console.png)


## Quelques plugins en vrac

- [jeeeyuls-eclipse-themes](http://marketplace.eclipse.org/content/jeeeyuls-eclipse-themes) : Thème Eclipse, thèmes store => [http://themes.jeeeyul.net/](http://themes.jeeeyul.net/)
- Thème de couleur pour l'editeur de code [http://www.eclipsecolorthemes.org/](http://www.eclipsecolorthemes.org/)
- SVN avec subversive [https://marketplace.eclipse.org/content/subversive-svn-team-provider](https://marketplace.eclipse.org/content/subversive-svn-team-provider)
- SVN avec subeclipse [https://github.com/subclipse/subclipse/wiki](https://github.com/subclipse/subclipse/wiki)
- SSH/SCP : [https://marketplace.eclipse.org/content/remote-system-explorer-ssh-telnet-ftp-and-dstore-protocols]()https://marketplace.eclipse.org/content/remote-system-explorer-ssh-telnet-ftp-and-dstore-protocols