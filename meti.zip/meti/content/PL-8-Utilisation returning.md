+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Utilisation returning"
author="Timothé Clavier"

[menu.main]
identifier = "PL-8-Utilisation returning"
parent ="PL-1-PLSQL"
+++
Auteur:  
Date: 25/08/2016

---------------

#### La clause Returning

- Qu'est-ce que c'est ?
<br>La clause <i>returning into </i> permet de récuperer lors d'opération d'ordre DML les valeurs des colonnes ayant été mis- a jour (INSERT/UPDATE/DELETE)

<br> Cette récupération peut se faire par paquet (BULK) ou bien par mono-enreg (via record ou variables énumérées)

<br> Cette clause ne peut être interpreter qu'en PLSQL ou bien via l'interface SQL dans des variables hotes.

<br> Elle peut être utilisée à la fois en requête dynamique qu'n requête statique

<br> Il est possible De retourner des valeurs calculées

<br> Par contre avec un INSERT SELECT cela ne fonctionne pas, mais uniquement avec un INSERT VALUES
<br> Remarque : On ne peut utiliser le returning en insert select avec des données de types "aggrégat" (SUM,AVG,etc...)

### Via Forall

- Recuperation des informations qui ont servi à mettre à jour la table 

```Sql
DECLARE
BEGIN
   FORALL i IN 1 .. l_tab_art.COUNT
         UPDATE mgast
            SET ast_qtstock = l_tab_art (i).qte
          WHERE     ast_cdmag = meti_param.prm_cdmagprinc
                AND ast_noart = l_tab_art (i).art_noart
                AND (ast_qtstock <> l_tab_art (i).qte OR ast_qtstock IS NULL)
      -- Recuperation des No de ligne qui ont realise une mise a jour
      RETURNING l_tab_art (i).noligne
           BULK COLLECT INTO l_tab_art_maj;
END;
/
```        

- Recuperation des enreg qui ont servi mis à jour 

```Sql
DECLARE

TYPE l_ast_tab_type is table of mgast%rowtype index by PLS_INTEGER;
l_tab_mgast l_ast_tab_type;
BEGIN
   FORALL i IN 1 .. l_tab_art.COUNT
         UPDATE mgast
            SET ast_qtstock = l_tab_art (i).qte
          WHERE     ast_cdmag = meti_param.prm_cdmagprinc
                AND ast_noart = l_tab_art (i).art_noart
                AND (ast_qtstock <> l_tab_art (i).qte OR ast_qtstock IS NULL)
      -- Recuperation des No de ligne qui ont realise une mise a jour
      RETURNING ast_noart
           BULK COLLECT INTO l_tab_mgast.ast_noart;
END;
/
```        

### Via record

```Sql 

DECLARE
   rec_art   mgart%ROWTYPE;
BEGIN
      UPDATE mgart
         SET art_lbarti = rec_art.art_noart
       WHERE art_noart = rec_art.art_noart
   RETURNING art_cdf, art_cds, art_lbarti
        INTO rec_art.art_cdf, rec_art.art_cds, rec_art.art_lbarti;
END;
/                                          
```


```Sql
delete ma_table
     where A_TRAITER = 'O'
    returning NOTRAIT, NOLIGNE BULK COLLECT INTO l_notrait;
```

```Sql
INSERT INTO gtt_exstp_loop (cdstp,num,params)
            VALUES  ('20',1,'<PAR_LST_NOTRAIT>'||pi_notrait||'</PAR_LST_NOTRAIT>') 
          RETURNING params INTO v_buffer;
```


<br> Retour de valeur calculée
```Sql 
RETURNING ast_noart,ast_qtstomvt * 10 
           BULK COLLECT INTO l_tab_mgast;
```


```Sql
RETURNING SUM(DECODE(exists_rayon_meti(rayon), 0, 1, 0)) INTO v_tot;
```