+++
date="2017-05-16T15:12:23+02:00"
draft="true"
title="Liens utiles multi langage"

[menu.main]

identifier="DI-6-liens utiles multi langage"
parent="DI-1-Divers"

+++
Auteur:  
Date: 28/03/2017

----------------------
## Online Docs
### Web
- [http://devdocs.io/](http://devdocs.io/)  


## Divers liens
 - [Shell Oracle Css etc ](http://ss64.com/)

 - ![System Oracle](http://lxdev03:3004/resources/oracle/System-Global-Area.png)

 - [Vulgarisation sql](http://sql.sh/)

 - [Dictionnaire Oracle ](http://docs.oracle.com/database/121/REFRN/toc.htm)
 
 - [http://overapi.com](http://overapi.com/)
 
 - [http://www.cheat-sheets.org/](http://www.cheat-sheets.org)
 
 - [https://learnxinyminutes.com/](https://learnxinyminutes.com/)
 
 - [https://github.com/detailyang/awesome-cheatsheet](https://github.com/detailyang/awesome-cheatsheet)