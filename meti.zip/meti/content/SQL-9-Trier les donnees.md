+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Trier les données"
author="Timothé Clavier"

[menu.main]
identifier = "SQL-9-Trier les donnes"
parent ="SQL-1-SQL"
+++
Auteur:  
Date: 25/08/2016

---------------
###  Mettre les données null à la fin ou au début d'un tri :

 - au debut : 


```sql 

SELECT   * FROM mgarv order by arv_dtdeb NULLS FIRST;

``` 

 - a la fin : 

 
 ```sql

SELECT   * FROM mgarv order by arv_dtdeb NULLS LAST;

```

 - Combine avec un Ordre de tri ASCendant ou DESCendant : 
 
 
 ```sql

SELECT   * FROM mgarv order by arv_dtdeb DESC NULLS LAST;

```

###  Utilisation de requete analytique <u>(ROW_NUMBER)</u> 

- Etude de Cas 1 : 
<br><u>Je veux des variantes articles suivant l'ordre de tri :</u> 
<br>	- ouverte ou futur (avec priorité à la date du jour, puis date passée)
<br>    - ayant le plus petit pcb 
<br>    - prioritairement avec une ul commandable
<br>    - prioritairement la plus petite variante
<br>    - prioritairement la variante avec la date de debut la plus vieille et la date de fin la plus éloigné
    
<br>Pour réaliser ceci on va simplement utiliser la méthode de partitionnement (<b>OVER PARTITION</b>) 
<br>en attribuant un numéro de tri (<i>avec <b>row_number()</b></i>) suivant les critères de priorités, pour enfin ne sélectionner que les données avec l'ordre de priorité 1. 


```Sql 

SELECT *
  FROM (SELECT vul_noart, vul_cdfo, vul_nbpcbul, vul_flulcde, vul_novar, arv_dtdeb, arv_dtfin,
               ROW_NUMBER () OVER (PARTITION BY vul_noart ORDER BY vul_noart,
                vul_cdfo,
                case SIGN (NVL (arv_dtdeb, TO_DATE ('01/01/0001')) - TRUNC (SYSDATE)) 
                WHEN 0 then 0 -- ici on trie d'abord date du jour 
                WHEN -1 then 1 -- puis date passé 
                else 1 -- puis date future
                end ,
                vul_nbpcbul,
                vul_flulcde DESC,
                vul_novar,
                arv_dtdeb,
                arv_dtfin) AS pos
          FROM mgvul, mgarv
         WHERE arv_cdfo = vul_cdfo
           AND arv_novar = vul_novar
           AND vul_noart = arv_noart
           AND NVL (arv_dtfin, TO_DATE ('31/12/2999', 'DD/MM//YYYY')) >= TRUNC (SYSDATE))
 WHERE pos = 1;

```

- Etudes de cas 2

<br><u>Je veux des variantes articles suivant l'ordre de tri :</u> 
<br>- les variantes ouvertes en 1er
<br>- la date ouverture la plus proche de la date du jour 
<br>- puis les variantes futures 
<br>- puis les variantes passés
<br>- ayant le plus petit pcb 
<br>    - prioritairement avec une ul commandable
<br>    - prioritairement la plus petite variante

 principe de fonctionnement

```Sql 
   date jour |    <    |  <   |   <   |  =  |  =  |  >
             |    <    |  =   |   >   |  =  |  >  |  >
__________________________________________________________
*   arv_dtdeb|   -1     |  -1  |  -1   | 0   |  0  |  1       (sign)
__________________________________________________________
*   arv_dtfin|   -1     |  0   |  1    | 0   |  1  |  1       (sign)
*=========================================================
*    Total  |   -2      | -1  |  0     | 0  |  1  |  2
 =========================================================
*  Revient a| Passe    |    EN  C O U R S         |  Futur
*
 Il n'y a donc que 2 cas a tester les dates

```

```Sql 

SELECT *
  FROM (SELECT vul_noart, vul_cdfo, vul_nbpcbul, vul_flulcde, vul_novar, arv_dtdeb, arv_dtfin,
               SIGN (arv_dtdeb - TRUNC (SYSDATE)) AS dtdeb,
               SIGN (arv_dtfin - TRUNC (SYSDATE)) AS dtfin,
               -- Resultat des test de dates (passé, en cours, futur)
               CASE   SIGN (arv_dtdeb - TRUNC (SYSDATE))
                    + SIGN (arv_dtfin - TRUNC (SYSDATE))
                  WHEN -2
                     THEN 2
                  WHEN 2
                     THEN 1
                  ELSE 0
               END AS en_cours,
               ROW_NUMBER () OVER (PARTITION BY vul_noart, vul_cdfo ORDER BY vul_noart,
                vul_cdfo,
                CASE SIGN (arv_dtdeb - TRUNC (SYSDATE)) + SIGN (arv_dtfin - TRUNC (SYSDATE))
                   WHEN -2
                      THEN 2
                   WHEN 2
                      THEN 1
                   ELSE 0
                END,
                arv_dtdeb DESC,
                vul_nbpcbul,
                vul_flulcde DESC,
                vul_novar,
                arv_dtdeb,
                arv_dtfin) AS pos
          FROM mgvul, mgarv
         WHERE arv_cdfo = vul_cdfo
           AND arv_novar = vul_novar
           AND vul_noart = arv_noart
           AND arv_noart = 30604041);

```

On obtiens

<br><p>
			<table border='1' width='90%' align='center' summary='Script output'>
			<tr>
				<th scope="col">VUL_NOART</th><th scope="col">VUL_CDFO</th><th scope="col">VUL_NBPCBUL</th><th scope="col">V</th><th scope="col">VUL_NOVAR</th><th scope="col">ARV_DTDEB</th><th scope="col">ARV_DTFIN</th><th scope="col">DTDEB</th><th scope="col">DTFIN</th><th scope="col">EN_COURS</th><th scope="col">POS</th></tr>
				<tr><td align="right">  30604041</td><td align="right">         1</td><td align="right">         2</td><td>O</td><td align="right">        77</td>
<td>
29/04/2015
</td>
<td>
31/12/2999
</td>
<td align="right">
        -1
</td>
<td align="right">
         1
</td>
<td align="right">
         0
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
         1
</td>
<td align="right">
        10
</td>
<td>
O
</td>
<td align="right">
        77
</td>
<td>
29/04/2015
</td>
<td>
31/12/2999
</td>
<td align="right">
        -1
</td>
<td align="right">
         1
</td>
<td align="right">
         0
</td>
<td align="right">
         2
</td>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
         1
</td>
<td align="right">
         4
</td>
<td>
O
</td>
<td align="right">
         7
</td>
<td>
07/04/2014
</td>
<td>
31/10/2100
</td>
<td align="right">
        -1
</td>
<td align="right">
         1
</td>
<td align="right">
         0
</td>
<td align="right">
         3
</td>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
         1
</td>
<td align="right">
         2
</td>
<td>
O
</td>
<td align="right">
         5
</td>
<td>
21/01/2014
</td>
<td>
31/10/2100
</td>
<td align="right">
        -1
</td>
<td align="right">
         1
</td>
<td align="right">
         0
</td>
<td align="right">
         4
</td>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
         1
</td>
<td align="right">
        10
</td>
<td>
O
</td>
<td align="right">
         5
</td>
<td>
21/01/2014
</td>
<td>
31/10/2100
</td>
<td align="right">
        -1
</td>
<td align="right">
         1
</td>
<td align="right">
         0
</td>
<td align="right">
         5
</td>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
         1
</td>
<td align="right">
{null}
</td>
<td>
O
</td>
<td align="right">
         5
</td>
<td>
21/01/2014
</td>
<td>
31/10/2100
</td>
<td align="right">
        -1
</td>
<td align="right">
         1
</td>
<td align="right">
         0
</td>
<td align="right">
         6
</td>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
         1
</td>
<td align="right">
        10
</td>
<td>
O
</td>
<td align="right">
         4
</td>
<td>
20/01/2014
</td>
<td>
31/10/2100
</td>
<td align="right">
        -1
</td>
<td align="right">
         1
</td>
<td align="right">
         0
</td>
<td align="right">
         7
</td>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
         1
</td>
<td align="right">
{null}
</td>
<td>
O
</td>
<td align="right">
         4
</td>
<td>
20/01/2014
</td>
<td>
31/10/2100
</td>
<td align="right">
        -1
</td>
<td align="right">
         1
</td>
<td align="right">
         0
</td>
<td align="right">
         8
</td>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
         1
</td>
<td align="right">
        10
</td>
<td>
O
</td>
<td align="right">
         2
</td>
<td>
26/11/2013
</td>
<td>
31/10/2100
</td>
<td align="right">
        -1
</td>
<td align="right">
         1
</td>
<td align="right">
         0
</td>
<td align="right">
         9
</td>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
         1
</td>
<td align="right">
        10
</td>
<td>
O
</td>
<td align="right">
         2
</td>
<td>
26/11/2013
</td>
<td>
31/10/2100
</td>
<td align="right">
        -1
</td>
<td align="right">
         1
</td>
<td align="right">
         0
</td>
<td align="right">
        10
</td>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
         1
</td>
<td align="right">
{null}
</td>
<td>
O
</td>
<td align="right">
         2
</td>
<td>
26/11/2013
</td>
<td>
31/10/2100
</td>
<td align="right">
        -1
</td>
<td align="right">
         1
</td>
<td align="right">
         0
</td>
<td align="right">
        11
</td>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
         1
</td>
<td align="right">
         2
</td>
<td>
O
</td>
<td align="right">
         3
</td>
<td>
26/11/2013
</td>
<td>
28/04/2015
</td>
<td align="right">
        -1
</td>
<td align="right">
        -1
</td>
<td align="right">
         2
</td>
<td align="right">
        12
</td>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
         1
</td>
<td align="right">
        10
</td>
<td>
O
</td>
<td align="right">
         1
</td>
<td>
26/11/2013
</td>
<td>
17/11/2014
</td>
<td align="right">
        -1
</td>
<td align="right">
        -1
</td>
<td align="right">
         2
</td>
<td align="right">
        13
</td>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
         1
</td>
<td align="right">
        10
</td>
<td>
O
</td>
<td align="right">
         3
</td>
<td>
26/11/2013
</td>
<td>
28/04/2015
</td>
<td align="right">
        -1
</td>
<td align="right">
        -1
</td>
<td align="right">
         2
</td>
<td align="right">
        14
</td>
</tr>
<tr>
<th scope="col">
VUL_NOART
</th>
<th scope="col">
VUL_CDFO
</th>
<th scope="col">
VUL_NBPCBUL
</th>
<th scope="col">
V
</th>
<th scope="col">
VUL_NOVAR
</th>
<th scope="col">
ARV_DTDEB
</th>
<th scope="col">
ARV_DTFIN
</th>
<th scope="col">
DTDEB
</th>
<th scope="col">
DTFIN
</th>
<th scope="col">
EN_COURS
</th>
<th scope="col">
POS
</th>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
         1
</td>
<td align="right">
{null}
</td>
<td>
O
</td>
<td align="right">
         1
</td>
<td>
26/11/2013
</td>
<td>
17/11/2014
</td>
<td align="right">
        -1
</td>
<td align="right">
        -1
</td>
<td align="right">
         2
</td>
<td align="right">
        15
</td>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
         2
</td>
<td align="right">
        10
</td>
<td>
O
</td>
<td align="right">
         1
</td>
<td>
18/11/2014
</td>
<td>
31/12/2999
</td>
<td align="right">
        -1
</td>
<td align="right">
         1
</td>
<td align="right">
         0
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
         2
</td>
<td align="right">
{null}
</td>
<td>
O
</td>
<td align="right">
         1
</td>
<td>
18/11/2014
</td>
<td>
31/12/2999
</td>
<td align="right">
        -1
</td>
<td align="right">
         1
</td>
<td align="right">
         0
</td>
<td align="right">
         2
</td>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
     17963
</td>
<td align="right">
         5
</td>
<td>
O
</td>
<td align="right">
         1
</td>
<td>
19/03/2014
</td>
<td>
31/10/3000
</td>
<td align="right">
        -1
</td>
<td align="right">
         1
</td>
<td align="right">
         0
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
     17963
</td>
<td align="right">
        30
</td>
<td>
O
</td>
<td align="right">
         1
</td>
<td>
19/03/2014
</td>
<td>
31/10/3000
</td>
<td align="right">
        -1
</td>
<td align="right">
         1
</td>
<td align="right">
         0
</td>
<td align="right">
         2
</td>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
     24929
</td>
<td align="right">
         5
</td>
<td>
O
</td>
<td align="right">
         2
</td>
<td>
19/03/2014
</td>
<td>
31/10/3000
</td>
<td align="right">
        -1
</td>
<td align="right">
         1
</td>
<td align="right">
         0
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
     24929
</td>
<td align="right">
        10
</td>
<td>
O
</td>
<td align="right">
         2
</td>
<td>
19/03/2014
</td>
<td>
31/10/3000
</td>
<td align="right">
        -1
</td>
<td align="right">
         1
</td>
<td align="right">
         0
</td>
<td align="right">
         2
</td>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
     24929
</td>
<td align="right">
        10
</td>
<td>
O
</td>
<td align="right">
         2
</td>
<td>
19/03/2014
</td>
<td>
31/10/3000
</td>
<td align="right">
        -1
</td>
<td align="right">
         1
</td>
<td align="right">
         0
</td>
<td align="right">
         3
</td>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
     24929
</td>
<td align="right">
        20
</td>
<td>
O
</td>
<td align="right">
         2
</td>
<td>
19/03/2014
</td>
<td>
31/10/3000
</td>
<td align="right">
        -1
</td>
<td align="right">
         1
</td>
<td align="right">
         0
</td>
<td align="right">
         4
</td>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
     41224
</td>
<td align="right">
         1
</td>
<td>
O
</td>
<td align="right">
         1
</td>
<td>
10/12/2009
</td>
<td>
31/12/9999
</td>
<td align="right">
        -1
</td>
<td align="right">
         1
</td>
<td align="right">
         0
</td>
<td align="right">
         1
</td>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
     41224
</td>
<td align="right">
         2
</td>
<td>
O
</td>
<td align="right">
         1
</td>
<td>
10/12/2009
</td>
<td>
31/12/9999
</td>
<td align="right">
        -1
</td>
<td align="right">
         1
</td>
<td align="right">
         0
</td>
<td align="right">
         2
</td>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
     41224
</td>
<td align="right">
       150
</td>
<td>
O
</td>
<td align="right">
         1
</td>
<td>
10/12/2009
</td>
<td>
31/12/9999
</td>
<td align="right">
        -1
</td>
<td align="right">
         1
</td>
<td align="right">
         0
</td>
<td align="right">
         3
</td>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
     41224
</td>
<td align="right">
      1800
</td>
<td>
O
</td>
<td align="right">
         1
</td>
<td>
10/12/2009
</td>
<td>
31/12/9999
</td>
<td align="right">
        -1
</td>
<td align="right">
         1
</td>
<td align="right">
         0
</td>
<td align="right">
         4
</td>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
     41224
</td>
<td align="right">
      1800
</td>
<td>
O
</td>
<td align="right">
         1
</td>
<td>
10/12/2009
</td>
<td>
31/12/9999
</td>
<td align="right">
        -1
</td>
<td align="right">
         1
</td>
<td align="right">
         0
</td>
<td align="right">
         5
</td>
</tr>
<tr>
<th scope="col">
VUL_NOART
</th>
<th scope="col">
VUL_CDFO
</th>
<th scope="col">
VUL_NBPCBUL
</th>
<th scope="col">
V
</th>
<th scope="col">
VUL_NOVAR
</th>
<th scope="col">
ARV_DTDEB
</th>
<th scope="col">
ARV_DTFIN
</th>
<th scope="col">
DTDEB
</th>
<th scope="col">
DTFIN
</th>
<th scope="col">
EN_COURS
</th>
<th scope="col">
POS
</th>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
     41224
</td>
<td align="right">
      7200
</td>
<td>
O
</td>
<td align="right">
         1
</td>
<td>
10/12/2009
</td>
<td>
31/12/9999
</td>
<td align="right">
        -1
</td>
<td align="right">
         1
</td>
<td align="right">
         0
</td>
<td align="right">
         6
</td>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
     41224
</td>
<td align="right">
      7200
</td>
<td>
O
</td>
<td align="right">
         1
</td>
<td>
10/12/2009
</td>
<td>
31/12/9999
</td>
<td align="right">
        -1
</td>
<td align="right">
         1
</td>
<td align="right">
         0
</td>
<td align="right">
         7
</td>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
     41224
</td>
<td align="right">
{null}
</td>
<td>
O
</td>
<td align="right">
         1
</td>
<td>
10/12/2009
</td>
<td>
31/12/9999
</td>
<td align="right">
        -1
</td>
<td align="right">
         1
</td>
<td align="right">
         0
</td>
<td align="right">
         8
</td>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
     41224
</td>
<td align="right">
{null}
</td>
<td>
O
</td>
<td align="right">
         1
</td>
<td>
10/12/2009
</td>
<td>
31/12/9999
</td>
<td align="right">
        -1
</td>
<td align="right">
         1
</td>
<td align="right">
         0
</td>
<td align="right">
         9
</td>
</tr>
<tr>
<td align="right">
  30604041
</td>
<td align="right">
     41224
</td>
<td align="right">
{null}
</td>
<td>
O
</td>
<td align="right">
         1
</td>
<td>
10/12/2009
</td>
<td>
31/12/9999
</td>
<td align="right">
        -1
</td>
<td align="right">
         1
</td>
<td align="right">
         0
</td>
<td align="right">
        10
</td>
</tr>
</table>
<p>
<br>
