+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Svn"
author="Timothé Clavier"

[menu.main]
identifier = "NORM-3-Svn"
parent ="NORM-1-Normes"
+++
Auteur:  
Date: 6/12/2016

---------------
## Gestion des docs 

### Mail RB (du 22 avril 2016) 
[SVN Docs] Réorganisation SVN au niveau des documents CHPO, DOCS, RECT et SUIV


Bonjour, 

RAPPEL sur l'organisation SVN, notamment pour Emag : http://lxdev01:8080/metidev/trunk/emag

Les documents positionnés sous ses répertoires sont à transformer/créer au format Microsoft OFFICE (.docx, .xlsx, ...)

Document organisation SVN dispo : http://lxdev01:8080/docs/trunk/NORM_Normes/NORMES_organisation_docs_svn.odt

Création de plusieurs sous répertoires par application et/ou module et/ou sous-module :
    - CHPO_Chapeau : Document chapeau par point d'analyse ou plusieurs point d'analyse :
            Nommage : CHPO_ACHA_1208_1256_gestion_ug.docx    (avec 1208 et 1206  : points d'analyses)

    - DOCS_Fonctionnel : Document général fonctionnel sur le module
            Nommage : DOCS_ACHA_param_propo_cde.docx

    - RECT_Qualification : 
            Test unitaire/ PV de recette (Point d'analyse et/ou de dev)
                   Nommage : RECT_PVRT_ACHA_1208_1209_gestion_ug.docx
            Fiche de recette (Qualification d'une fonctionnalité : document réutilisable)
                   Nommage : RECT_FICH_ACHA_saisie_de_cde.docx
            Scénario de recette (Qualification de version)
                   Nommage : RECT_SCEN_ACHA_saisie_de_cde.docx

    - SUIV_Suivi : Documents de suivi de projet fonctionnel 
            Nommage : SUIV_ACHA_avancement_projet_ug.docx


![Arborescence](http://lxdev03:3004/resources/svn/arbo_svn_doc.png)


2 éme partie ( A planifier ensuite) : 
Réorganisation des spécifications standards et spécifiques par module.
Création du sous-répertoire SPEC_Programmes.


## Gestion des revisions PLSQL

- Bloc type (en entete de package)

```Sql
VERSION CONSTANT VARCHAR2(1000):='$Revision::               $ $HeadURL::                                                                                                    $';

/********************************************************************************************************
* $Revision::                                                                                           $
* $Author::                                                                                             $
* $Date::                                                                                               $
* $HeadURL::                                                                                            $
*********************************************************************************************************
*/
```

## Gestion des revisions shell linux

- Bloc type (en entete de package)

```Bash

#===============================================================================
# $Revision::                                                                                           $
# $Author::                                                                                             $
# $Date::                                                                                               $
# $HeadURL::                                                                                            $
#===============================================================================
```

## Liste des hooks SVN 

- Liste détaillée des hooks svn : http://lxdev01:8080/docs/trunk/Developpement/SVN/dev_SVN_hooks.odt

- Rappel sur la mise en place propriétés svn automatique : http://lxdev01:8080/docs/trunk/Developpement/SVN/dev_SVN_propriete_automatique.odt

- Rajouter manuellement les propriétés SVN : 
	- http://lxdev01:8080/docs/trunk/Developpement/SVN/dev_SVN_prop_revision.odt
	- http://lxdev01:8080/docs/trunk/Developpement/SVN/dev_SVN_prop_eol.odt

- Résumé des propriétés svp :
	
	![Arborescence](http://lxdev03:3004/resources/svn/propriete_keyword_svn.png)
	![Arborescence](http://lxdev03:3004/resources/svn/propriete_eol_svn.png)

-  Résumé des hooks : 

|No|Nom du Ctrl |  Prefixe |Extension| Action | Controle |
|--:| :------------- |:-------------|-----:|:-----:| -----:|
|1|eol                     |     |.php .js .html .php.inc .sh .sh.default .CTL .ctl .css .ini .ini.default .sql|  |**LF**|
|2|utf8                    |     |.php .js .html .php.inc .sh .sh.default .ctl .css .ini .ini.default .sql| |Format **Utf8**|
|3|PHP53                   |     |.php||contient pas des fonctions non compatibles avec PHP 5.3|
|4|unicode-php             |     |.php||Le fichier utilse des fonctions non mbstring|
|5|unicode-js              |     |.php||Le fichier utilise des fonctions non mbstring|
|6|modal                   |     |.php .html .js .php.inc||Contient des references a dialogArguments et showModalDialog|
|7|norme-drop-wrk-gtt      |wrk\_ gtt\_|.sql||Ne **drop** pas les tables via **PL/SQL anonyme**|
|8|norme-colonne-wrk       |wrk\_ gtt\_|.sql||Ne contient pas la colonne technique **WRK__DTCREA**|
|9|norme-colonne-wrk       |wrk\_ gtt\_|.sql|**Ajout**|Ne contient pas la colonne technique **WRK__IDSESSION**|
|10|dble-exec-wrk-gtt       |wrk\_ gtt\_|.sql||Contient des doubles execution (**;/**) |
|11|ctl-filename-windows    |ctl\_ CTL\_ | .ctl||Contient un **"."** dans le nom du fichier|
|12|no-exec-pkg             |pkg_ |.sql||Package sans **"/"** d'execution(header ou body)|
|13|revision-object         |pkg_ |.sql||Ne contient pas les variables **$KEYWORD** et **VERSION** |
|14|revision-svn            |     |.php .js .html .php.inc .sh .sh.default .CTL .ctl .css .ini .ini.default .sql||Ne contient pas les propriétés **KEYWORD Svn**|
|15|commentaire-plsql       |pkg\_|.sql||Contient des **"@"** en debut de chaine|
|16|norme-create-sequence   |seq\_|.sql||Ne **creer** pas les sequences via **PL/SQL anonyme**|
|17|lower-extension         |     |.php .js .html .php.inc .sh .sh.default .ctl .css .ini .ini.default .sql||Les **extensions** doivent être en **minuscule**|
|18|norme-nb-wrk-gtt-by-file|wrk\_ gtt\_|.sql|**Ajout**|Les fichiers ne doivent avoir au plus que **un seul objet table**|