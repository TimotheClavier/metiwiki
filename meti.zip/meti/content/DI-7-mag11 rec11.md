+++
date="2017-05-16T15:12:23+02:00"
draft="true"
title="Mag11 Rec11"
author="Timothé Clavier"
[menu.main]

identifier="DI-7-mag11 rec11"
parent="DI-1-Divers"

+++
Auteur:  
Date: 12/01/2017

----------

#### Rafraichir les objets Oracle sur un schémas MAG11

<br>( Sur le Serveur <b>lxdev03</b> compte <b><i>metiadm </i></b>)</br>  

```bash
sh $HOME/outil_dev/patch/refresh_rec11.sh -i MAG11 -r <SCHEMAS_METIER>
```
<br><i>exemple</i></br>  

```bash
sh $HOME/outil_dev/patch/refresh_rec11.sh -i MAG11 -r HYP068
```

#### Blocage de maj
<br>( Sur le Serveur <b>lxdev03</b> compte <b><i>metiadm </i></b>)</br>

- 1) <b>Via le crontab (Niveau global multi-instance)</b>
</b>
<br> -<u> Contenu du crontab </u>
```Bash 
# DEBUT REC11 Oracle =======================================
# Midi -------
30 12 * * 1-5 /home/metiadm/outil_dev/patch/maj_serveur.sh -m update
# Soir -------
20 20 * * 1-5 /home/metiadm/outil_dev/patch/maj_serveur.sh -m init
00 22 * * 1-5 /home/metiadm/outil_dev/patch/refresh_rec11.sh -i MAG11 -r MLIB -a mlib
``` 
<br> Mettre en commentaires les maj à bloquer

- 2) <b>Via fichier de paramétrage (niveau schemas par instance)</b>  

$HOME/outil_dev/patch/schemas_parametrage/  

Il y a un fichier par instance  
	- Instance MAG11 :
<i>liste_schema_bloque_metidev_mag11.txt</i>  
	- Instance REC11 :
<i>liste_schema_bloque_metidev_rec11.txt</i>  


Il suffit de renseigner le nom du schémas Oracle à bloquer en maj ( modèle,package, etc...)

<i><u>Exemple</i></u> : 

```Sql
HYP011   --> implique que ce schémas sera ignoré
```

- 3) <b>Via fichier de paramétrage (niveau instance)</b>  

$HOME/outil_dev/patch/schemas_parametrage/
fichier liste_instance_bloque.txt

	- Contenu du fichier : 
    
  ```bash
  <instance>=<OUI/NON>;
  ```
  
<i><u>Exemple</i></u> : 

```Sql
REF11=NON;   #--> implique que l'instance REF11 sera ignorée
REC11=OUI;   #--> implique que l'instance REC11 sera gérée
```

#### Gestion du DRCP sur REC11
<br> Sous le compte <b>system</b></br>
- Vérifier que le DRCP est actif
```Sql
SELECT TRIM (connection_pool) AS connection_pool, TRIM (status) AS status, minsize, maxsize,
       incrsize, session_cached_cursors, inactivity_timeout, max_think_time, max_use_session,
       max_lifetime_session, num_cbrok, maxconn_cbrok
  FROM dba_cpool_info;
```
- Information sur les connections
```Sql
SELECT process_id, username, connection_status FROM v$cpool_conn_info order by username;
```
- statistiques sur les Pools
```Sql
SELECT pool_name "Name", num_open_servers, num_busy_servers, num_requests, num_misses, num_waits
  FROM v$cpool_stats;
```
- Arrêt des pools
```Sql
exec sys.dbms_connection_pool.stop_pool;
```
- Démarrage des pools
```Sql
exec sys.dbms_connection_pool.start_pool;
```

### Utilisation de l'espace disk par taille decroissante

```Sql
  SELECT schemas, megs_alloc AS "Mo ", megs_free AS "Mo libre", megs_used AS "Mo used",
         pct_free AS "% libre", pct_used AS "% used"
    FROM (SELECT REPLACE (a.tablespace_name, '_DATA', '') AS schemas,
                 ROUND (a.bytes_alloc / 1024 / 1024, 2) megs_alloc,
                 ROUND (NVL (b.bytes_free, 0) / 1024 / 1024, 2) megs_free,
                 ROUND ( (a.bytes_alloc - NVL (b.bytes_free, 0)) / 1024 / 1024, 2) megs_used,
                 ROUND ( (NVL (b.bytes_free, 0) / a.bytes_alloc) * 100, 2) pct_free,
                 100 - ROUND ( (NVL (b.bytes_free, 0) / a.bytes_alloc) * 100, 2) pct_used
            FROM (  SELECT f.tablespace_name, SUM (f.bytes) bytes_alloc,
                           SUM (DECODE (f.autoextensible,  'YES', f.maxbytes,  'NO', f.bytes)) maxbytes
                      FROM dba_data_files f
                  GROUP BY tablespace_name) a,
                 (  SELECT f.tablespace_name, SUM (f.bytes) bytes_free
                      FROM dba_free_space f
                  GROUP BY tablespace_name) b
           WHERE a.tablespace_name = b.tablespace_name(+)
          UNION ALL
            SELECT REPLACE (h.tablespace_name, '_DATA', '') AS schemas,
                   ROUND (SUM (h.bytes_free + h.bytes_used) / 1048576, 2) megs_alloc,
                   ROUND (SUM ( (h.bytes_free + h.bytes_used) - NVL (p.bytes_used, 0)) / 1048576, 2) megs_free,
                   ROUND (SUM (NVL (p.bytes_used, 0)) / 1048576, 2) megs_used,
                   ROUND ( (SUM ( (h.bytes_free + h.bytes_used) - NVL (p.bytes_used, 0)) / SUM (h.bytes_used + h.bytes_free)) * 100, 2) pct_free,
                   100 - ROUND ( (SUM ( (h.bytes_free + h.bytes_used) - NVL (p.bytes_used, 0)) / SUM (h.bytes_used + h.bytes_free)) * 100, 2) pct_used
              FROM sys.v_$temp_space_header h, sys.v_$temp_extent_pool p, dba_temp_files f
             WHERE     p.file_id(+) = h.file_id
                   AND p.tablespace_name(+) = h.tablespace_name
                   AND f.file_id = h.file_id
                   AND f.tablespace_name = h.tablespace_name
          GROUP BY h.tablespace_name)
   WHERE EXISTS
            (SELECT 1
               FROM all_objects
              WHERE object_name IN ('MGSOC', 'TPSOC', 'MXDOS', 'APMEN') AND schemas = owner)
ORDER BY 2 DESC
/
```

### Espace Disque perdu pour schemas non utilisé

<br> Sous le compte <b><i>System</i></b>
```Sql
WITH my_space AS
     (SELECT REPLACE (a.tablespace_name, '_DATA') AS schemas, a.tablespace_name,
             ROUND (a.bytes_alloc / 1024 / 1024, 2) megs_alloc,
             ROUND (NVL (b.bytes_free, 0) / 1024 / 1024, 2) megs_free,
             ROUND ((a.bytes_alloc - NVL (b.bytes_free, 0)) / 1024 / 1024, 2) megs_used,
             ROUND ((NVL (b.bytes_free, 0) / a.bytes_alloc) * 100, 2) pct_free,
             100 - ROUND ((NVL (b.bytes_free, 0) / a.bytes_alloc) * 100, 2) pct_used,
             ROUND (maxbytes / 1048576, 2) MAX
        FROM (SELECT   f.tablespace_name, SUM (f.BYTES) bytes_alloc,
                       SUM (DECODE (f.autoextensible,
                                    'YES', f.maxbytes,
                                    'NO', f.BYTES
                                   )) maxbytes
                  FROM dba_data_files f
              GROUP BY tablespace_name) a,
             (SELECT   f.tablespace_name, SUM (f.BYTES) bytes_free
                  FROM dba_free_space f
              GROUP BY tablespace_name) b
       WHERE a.tablespace_name = b.tablespace_name(+)
      UNION ALL
      SELECT   REPLACE (h.tablespace_name,
                        '_DATA',
                        ''
                       ) AS schemas, h.tablespace_name,
               ROUND (SUM (h.bytes_free + h.bytes_used) / 1048576, 2) megs_alloc,
               ROUND (  SUM ((h.bytes_free + h.bytes_used) - NVL (p.bytes_used, 0))
                      / 1048576,
                      2) megs_free,
               ROUND (SUM (NVL (p.bytes_used, 0)) / 1048576, 2) megs_used,
               ROUND (  (  SUM ((h.bytes_free + h.bytes_used) - NVL (p.bytes_used, 0))
                         / SUM (h.bytes_used + h.bytes_free)
                        )
                      * 100,
                      2) pct_free,
                 100
               - ROUND (  (  SUM ((h.bytes_free + h.bytes_used) - NVL (p.bytes_used, 0))
                           / SUM (h.bytes_used + h.bytes_free)
                          )
                        * 100,
                        2) pct_used,
               ROUND (SUM (f.maxbytes) / 1048576, 2) MAX
          FROM SYS.v_$temp_space_header h, SYS.v_$temp_extent_pool p, dba_temp_files f
         WHERE p.file_id(+) = h.file_id
           AND p.tablespace_name(+) = h.tablespace_name
           AND f.file_id = h.file_id
           AND f.tablespace_name = h.tablespace_name
      GROUP BY h.tablespace_name)
SELECT   username, created, (SELECT MAX (dt)
                               FROM meti$_connection_by_schemas
                              WHERE schemas = username) AS last_acces, megs_alloc AS "total Mo",
         pct_used AS "% Utilisé", SUM (ROUND (megs_alloc / 1024, 2)) OVER () AS " Sur Go total de la liste"
    FROM all_users, my_space
   WHERE created < (TRUNC (SYSDATE) - 31)
     AND EXISTS (SELECT 1
                   FROM all_tables
                  WHERE table_name = 'MGSOC' AND owner = username)
     AND NOT EXISTS (SELECT 1
                       FROM meti$_connection_by_schemas
                      WHERE schemas = username AND dt > (TRUNC (SYSDATE) - 31))
     AND schemas = username
     --AND username NOT IN ('CASH01', 'CASHCE', 'HYPVDE')
     AND username NOT IN ('RFMETI')
ORDER BY 1;
```

### Stats de connection sur 3 mois et espace utilisé

```Sql
WITH my_space AS
     (SELECT REPLACE (a.tablespace_name, '_DATA') AS schemas, a.tablespace_name,
             ROUND (a.bytes_alloc / 1024 / 1024, 2) megs_alloc,
             ROUND (NVL (b.bytes_free, 0) / 1024 / 1024, 2) megs_free,
             ROUND ((a.bytes_alloc - NVL (b.bytes_free, 0)) / 1024 / 1024, 2) megs_used,
             ROUND ((NVL (b.bytes_free, 0) / a.bytes_alloc) * 100, 2) pct_free,
             100 - ROUND ((NVL (b.bytes_free, 0) / a.bytes_alloc) * 100, 2) pct_used,
             ROUND (maxbytes / 1048576, 2) MAX
        FROM (SELECT   f.tablespace_name, SUM (f.BYTES) bytes_alloc,
                       SUM (DECODE (f.autoextensible,
                                    'YES', f.maxbytes,
                                    'NO', f.BYTES
                                   )) maxbytes
                  FROM dba_data_files f
              GROUP BY tablespace_name) a,
             (SELECT   f.tablespace_name, SUM (f.BYTES) bytes_free
                  FROM dba_free_space f
              GROUP BY tablespace_name) b
       WHERE a.tablespace_name = b.tablespace_name(+)
      UNION ALL
      SELECT   REPLACE (h.tablespace_name,
                        '_DATA',
                        ''
                       ) AS schemas, h.tablespace_name,
               ROUND (SUM (h.bytes_free + h.bytes_used) / 1048576, 2) megs_alloc,
               ROUND (  SUM ((h.bytes_free + h.bytes_used) - NVL (p.bytes_used, 0))
                      / 1048576,
                      2) megs_free,
               ROUND (SUM (NVL (p.bytes_used, 0)) / 1048576, 2) megs_used,
               ROUND (  (  SUM ((h.bytes_free + h.bytes_used) - NVL (p.bytes_used, 0))
                         / SUM (h.bytes_used + h.bytes_free)
                        )
                      * 100,
                      2) pct_free,
                 100
               - ROUND (  (  SUM ((h.bytes_free + h.bytes_used) - NVL (p.bytes_used, 0))
                           / SUM (h.bytes_used + h.bytes_free)
                          )
                        * 100,
                        2) pct_used,
               ROUND (SUM (f.maxbytes) / 1048576, 2) MAX
          FROM SYS.v_$temp_space_header h, SYS.v_$temp_extent_pool p, dba_temp_files f
         WHERE p.file_id(+) = h.file_id
           AND p.tablespace_name(+) = h.tablespace_name
           AND f.file_id = h.file_id
           AND f.tablespace_name = h.tablespace_name
      GROUP BY h.tablespace_name),
     my_connect AS
     (SELECT   schemas AS schemas_connect, TO_CHAR (dtconnect, 'Month YYYY') AS mois,
               COUNT (*) AS nb_connect
          FROM meti$_connection
         WHERE dtconnect >= ADD_MONTHS (TRUNC (SYSDATE), -3) AND flg_data_a_prendre = 1
      GROUP BY schemas, TO_CHAR (dtconnect, 'Month YYYY'))
SELECT   username, TRUNC (created) AS created, mois, nb_connect, pct_used AS "% Espace Utilisé",
         ROUND (megs_alloc / 1024) AS "  Go alloué"
    FROM all_users, my_space, my_connect
   WHERE username = schemas AND username = schemas_connect
                                                          --AND username NOT IN ('CASH01', 'CASHCE', 'HYPVDE')
         AND username NOT IN ('RFMETI')
ORDER BY username, mois DESC;
```



### Serveur Multi-Version

- vérification des @ip
```Bash
cat /etc/hosts
cat /etc/sysconfig/network
cat /etc/resolv.conf 
```
<br>on doit avoir (exemple sur serveur vm9019.meti.fr)
```Txt
[ora11g@vm901903 ~]$ cat /etc/resolv.conf
search meti.fr
nameserver 172.16.0.23
nameserver 172.16.0.14
[ora11g@vm901903 ~]$ cat /etc/sysconfig/network
NETWORKING=yes
HOSTNAME=vm901903
NOZEROCONF=yes
[ora11g@vm901903 ~]$ cat /etc/hosts
# Do not remove the following line, or various programs
# that require network functionality will fail.
127.0.0.1       localhost.localdomain localhost
172.17.10.15    vm901903
```
- vérification que Oracle est en démarrage automatique
```Bash
cat /etc/oratab
```
<br> On doit avoir (Y)es
```Txt
mv9018:/metibdd/ora11g/db/prod:Y 
```

- Redémarrer le serveur (Compte Root)

```Bash
shutdown -r -t 60 now
```

- Vérification serveur de temps 

```Bash
cat /etc/sysconfig/clock 
cat /etc/ntp.conf
ping 172.10.0.100
service ntpd status
## Si le service est ko
chkconfig --list ntpd
rm /var/run/ntpd.pid 
service ntpd start
date
service ntpd status
ntpdate -sB 172.10.0.100
date


```

- Démarrage des services
```Bash
service tomcat restart
service tomcat status
service tomcat stop
service tomcat start
date ; service ntpd stop; ntpd -q -g ; service ntpd start; date
```

- variable d'environnement

```Bash
cat /home/ora11g/.bash_profile
echo $LANG
echo $HOSTNAME
ping $HOSTNAME

grep POSTGRESQL_START= /opt/jasperserver/postgresql/scripts/ctl.sh
grep JAVA_HOME= /opt/jasperserver/apache-tomcat/bin/setenv.sh
grep JRE_HOME= /opt/jasperserver/apache-tomcat/bin/setenv.sh
grep METI_HOME= /opt/jasperserver/apache-tomcat/bin/setenv.sh
grep CLASSPATH /opt/jasperserver/apache-tomcat/bin/setenv.sh
grep JASPERSERVER_HOME= /etc/init.d/jasperserver
grep APACHE_HOME= /meti/sys/conf/apache_setenv.sh
grep APACHE_HOME= /metiapp/sys/conf/apache_setenv.sh
grep CONF_FILE= /metiapp/sys/conf/apache_setenv.sh
grep PID_FILE= /metiapp/sys/conf/apache_setenv.sh
grep TNS_ADMIN= /metiapp/sys/conf/apache_setenv.sh

```

- Vérifier le tnsname

```Bash
cat /opt/instantclient/tnsnames.ora
cat /metibdd/ora11g/grid/prod/network/admin/listener.ora
cat /metibdd/ora11g/grid/prod/network/admin/tnsname.ora
tnsping mv901903
# vérifier le listener
$ORACLE_HOME/bin/lsnrctl status
# Vérifier la connection
export ORACLE_SID=MV901903
sqlplus RFMETI/ATTENT1
sqlplus RFMETI/ATTENT1@localhost/MV901903
sqlplus RFMETI/ATTENT1@vm901903.meti.fr/MV901903

```

- vérifier les imprimantes Cups

```Bash
lpstat -v
ls -al /var/cache/cups/
cat /etc/cups/cupsd.conf
service cups start
ls -al /var/cache/cups/
service cups status
``` 

- vérifier les editions Jasper

```Bash
grep JASPERSERVER_HOME= /etc/init.d/jasperserver
service jasperserver status
chkconfig --list jasperserver
cat  /etc/logrotate.d/jasperserver_log
curl -v http://127.0.0.1:8090
curl -v http://127.0.0.1:8090/jasperserver/login.html
curl -v -d "j_username=metiadm&j_password=metiadm" http://127.0.0.1:8090/jasperserver/j_spring_security_check

```

- Paramétrage (port) jasper
```Bash
## fichier 
%emag%dfap/conf/dfap.ini
## Verifier le port jasper
[JASPERSERVER]
URL_REF = http://127.0.0.1:8090/jasperserver
USER_REF = metiadm
PWD_REF = metiadm
## Puis l'acces sur l'ip emag:no port jasper
http:/172.16.0.85:8090
## On doit avoir la mire jasper
```

- Arrêt/marche Jasper
<br>Sous <b>root</b>
```Bash
/etc/init.d/jasperserver stop
/etc/init.d/jasperserver start
# ou bien 
service jasper stop
service jasper start
```


#### Recherche colonne manquante 

<br> Sous <b><i>System</i></b>

<br> <i>Pour un schemas</i>

```Sql 
WITH my_table AS
     (SELECT table_name AS tbl
        FROM all_tables
       WHERE TEMPORARY = 'N'
         AND owner = 'RFMETI'
         AND table_name NOT LIKE 'WRK_%'
         AND table_name NOT LIKE 'A_VIRER_%'
         AND table_name NOT LIKE 'TMP_%'
         AND table_name NOT LIKE 'TEMP_%'
         AND table_name NOT IN
                ('DEBUGKD', 'FLI_DEBUG_TRACE', 'GTT_C31_PROC_CTRL_FLX_10', 'GTT_C405_ETQ_MENS',
                 'GTT_RATTRAP_VARIANTE_ATA', 'TABLE1', 'TABLE2', 'TVD_CAPTURED_SQL_T',
                 'TVD_METADATA_T', 'TVD_PARSED_OBJECTS_T'))
SELECT table_name, column_name
  FROM all_tab_cols, my_table
 WHERE owner = 'RFMETI' AND table_name = tbl
MINUS
SELECT table_name, column_name
  FROM all_tab_cols, my_table
 WHERE owner = :SCHEMAS_METIER AND table_name = tbl
;
```
<br> <i>Pour <b>Tous</b> les schemas</i>

```Sql
DECLARE
   CURSOR c_diff (
      cp_owner IN VARCHAR2)
   IS
      WITH my_table
           AS (SELECT table_name AS tbl
                 FROM all_tables
                WHERE     temporary = 'N'
                      AND owner = 'RFMETI'
                      AND table_name NOT LIKE 'WRK_%'
                      AND table_name NOT LIKE 'A_VIRER_%'
                      AND table_name NOT LIKE 'TMP_%'
                      AND table_name NOT LIKE 'TEMP_%'
                      AND table_name NOT LIKE '%DEBUG%'
                      AND table_name NOT IN
                             ('DEBUGKD',
                              'FLI_DEBUG_TRACE',
                              'GTT_C31_PROC_CTRL_FLX_10',
                              'GTT_C405_ETQ_MENS',
                              'GTT_RATTRAP_VARIANTE_ATA',
                              'TABLE1',
                              'TABLE2',
                              'TVD_CAPTURED_SQL_T',
                              'TVD_METADATA_T',
                              'TVD_PARSED_OBJECTS_T',
                              'FP_DEBUG',
                              'MAJSVN$_',
                              'STAT_TABLE'))
      SELECT table_name, column_name
        FROM all_tab_cols, my_table
       WHERE owner = 'RFMETI' AND table_name = tbl and virtual_column='NO'
      MINUS
      SELECT table_name, column_name
        FROM all_tab_cols, my_table
       WHERE owner = cp_owner AND table_name = tbl  and virtual_column='NO';
BEGIN
   FOR i IN (  SELECT owner
                 FROM all_tables
                WHERE table_name = 'MGSOC' AND owner <> 'RFMETI'
             ORDER BY 1)
   LOOP
      DBMS_OUTPUT.put_line ('--------------------');
      DBMS_OUTPUT.put_line ('Schemas ' || i.owner);

      FOR j IN c_diff (i.owner)
      LOOP
         DBMS_OUTPUT.put_line (j.table_name || '->' || j.column_name);
      END LOOP;
   END LOOP;

   DBMS_OUTPUT.put_line ('Fin --------------------');
END;
/
```

### Divers

#### Vérifier la version de l'os (version linux)
```Bash
uname -a

cat /etc/redhat-release
cat /etc/os-release


```

#### Vérifier sur quel port tourne un service

<br>Sous <i>Root </i>
- Etape 1 : liste des services tomcat 

```Bash
ls -ltr /etc/init.d/?omcat*
```

- Etape 2 : vérifier si le services est montée 

```Bash
service tomcat status 
```

- Etape 3 : Liste des process tomcat

```Bash
ps -eaf|grep jsvc
```
On obtient 
 
```
    metiadm   9278  9277  0 10:36 ?        00:00:23 jsvc.exec-tomcat -user metiadm
```
- Etape 5 : avec le pid obtenu, on vérifie quel est le port utilisé : 
```Bash
netstat -pan | grep 9278
```
On obtient la liste des ports utilisé
```
tcp        0      0 :::8010                     :::*                        LISTEN      3861/jsvc.exec-tomc
tcp        0      0 ::ffff:127.0.0.1:61617      :::*                        LISTEN      3861/jsvc.exec-tomc
tcp        0      0 :::8081                     :::*                        LISTEN      3861/jsvc.exec-tom
```

- Ensuite on a l'@ ip du webservice (par défaut, il est asynchrone)

```Html
http://<ip>:<port obtenu>/BatchWSService?wsdl
```


- vérification des port tomcat

<br> Ou bien dans le fichier de config du tomcat

```Bash
#recherche la balise Connector dans le fichier 
cat /etc/apache-tomcat-job/conf/server.xml

```


#### Connaitre l'espace disk occupé par un répertoire

```Bash
# pour un repertoire précis
du -sh <mon rep>
# Pour le détail de tout un répertoire
cd /<mon rep>
du -sh *
```