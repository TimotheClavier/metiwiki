+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Utilisation forall"
author="Timothé Clavier"

[menu.main]
identifier = "PL-7-Utilisation forall"
parent ="PL-1-PLSQL"
+++
Auteur:  
Date: 25/08/2016

---------------

- Forall avec <b>exception</b> : 

```Sql 
DECLARE
   -- declaration d'un tableau
   TYPE l_art_tab_type IS TABLE OF mgart%ROWTYPE
      INDEX BY PLS_INTEGER;

   l_tab_art   l_art_tab_type;
   idx_art     PLS_INTEGER := 0;
   log_raise   BOOLEAN := FALSE;
   nb_cr       NUMBER (9) := 0;
BEGIN
   -- Remplissage du tableau
   l_tab_art (123456).art_noart := 123456;
   l_tab_art (123456).art_lbarti := 'article 123456';

   l_tab_art (566).art_noart := 566;
   l_tab_art (566).art_lbarti := 'article 566';

   l_tab_art (99999999).art_noart := 99999999;
   l_tab_art (99999999).art_lbarti := 'article 99999999';

   -- update par bulk du tableau
   FORALL i IN INDICES OF l_tab_art SAVE EXCEPTIONS
      UPDATE mgart
         SET art_lbarti = l_tab_art (i).art_lbarti
       WHERE art_noart = l_tab_art (i).art_noart;

   nb_cr := SQL%ROWCOUNT;
   DBMS_OUTPUT.put_line (' (Mo) MGPLG ' || nb_cr);
EXCEPTION
   -- Qd erreur de type Bulk ( a la fin de l'execution du FORALL)
   WHEN mlib_erreur.exc_bulk_errors
   THEN
     --===============================================
     -- Bcle sur l'ensemble des erreurs rencontrees
     --===============================================
     <<loop_tab_erreur>>
      FOR indx IN 1 .. SQL%BULK_EXCEPTIONS.COUNT
      LOOP
         -- Recup de l'index du tableau l_tab_plg
         idx_art := SQL%BULK_EXCEPTIONS (indx).ERROR_INDEX;

         -- ( ERROR_CODE correspond au code Oracle SQLCODE)
         DBMS_OUTPUT.put_line (
               'ERREUR '
            || SQLERRM (- (SQL%BULK_EXCEPTIONS (indx).ERROR_CODE))
            || ' '
            || l_tab_art (idx_art).art_noart
            || ' lb:'
            || l_tab_art (idx_art).art_lbarti);
      END LOOP loop_tab_erreur;
END;
/

```