+++
draft = true
title = "Astuce mutiprocess"
description = "Astuce pour désactiver le multiprocess e10s"
date = "2017-05-18"
author="Timothé Clavier"

[menu.main]
identifier="F-2-Astuce"
parent="F-1-Firefox"
+++
Auteur:  
Date: 02/03/2017

---------------------

## Désactiver le multiprocess e10s


Dans __about:config__, mettre la valeur __browser.tabs.remote.autostart.2__ à __false__


![](/resources/firefox/e10s_disabled_config.png)


Dans __about:support__, vérifier la désactivation


![](/resources/firefox/e10s_disabled_support.png)