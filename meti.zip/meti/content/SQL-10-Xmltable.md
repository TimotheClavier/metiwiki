+++
date = "2017-05-16T15:11:16+02:00"
draft = true
title = "Xmltable"
author="Timothé Clavier"

[menu.main]
identifier = "SQL-10-xmltble"
parent ="SQL-1-SQL"
+++
Auteur:  
Date: 14/09/2016

---------------

```Sql 
SELECT *
FROM apdci , apgci ,
xmltable('/APDCI' passing xmltype(adci_xmlpar)
    columns
      PK varchar2(1028) path 'PK'
      ),
xmltable('/APGCI' passing xmltype(agci_xmlpar)
    columns
      TYPRES varchar2(1028)  path 'TYPRES'
      )
where agci_nogci = adci_nogci
and agci_cdapli = adci_cdapli
and PK = 'O'
and instr(TYPRES, 'COLONNE') > 0
```

- Faire un select d'un fichier XML 

```Sql
       SELECT xoei_idsite, xoei_cdapli, xoei_cddoss, xoei_cdmag, xoei_iduser, xoei_cdedt, xoei_tyorient,
              xoei_cdcleort, xoei_cdimp, xoei_flimpdir, xoei_nbexplr, xoei_flarchiv, xoei_flenvoi,
              xoei_cddest, xoei_mdfoncsp, xoei_norang
         FROM XMLTABLE (
                 '/CONF/TABLE/EXOEI'
                 PASSING xmltype (
'<CONF><TABLE>
<EXOEI num="1">
<XOEI_IDSITE>NEW_SITE</XOEI_IDSITE>
<XOEI_CDAPLI>emag</XOEI_CDAPLI>
<XOEI_CDDOSS>ENT010</XOEI_CDDOSS>
<XOEI_CDMAG>0</XOEI_CDMAG>
<XOEI_IDUSER> </XOEI_IDUSER>
<XOEI_CDEDT> </XOEI_CDEDT>
<XOEI_TYORIENT>G</XOEI_TYORIENT>
<XOEI_CDCLEORT>1</XOEI_CDCLEORT>
<XOEI_CDIMP>HP_Bureau_SiWel</XOEI_CDIMP>
<XOEI_FLIMPDIR>46</XOEI_FLIMPDIR>
<XOEI_NBEXPLR>0</XOEI_NBEXPLR>
<XOEI_FLARCHIV>0</XOEI_FLARCHIV>
<XOEI_FLENVOI>0</XOEI_FLENVOI>
<XOEI_CDDEST NULL="TRUE"/>
<XOEI_MDFONCSP NULL="TRUE"/>
<XOEI_NORANG>2</XOEI_NORANG>
</EXOEI>
</TABLE></CONF>')
                 COLUMNS xoei_idsite     VARCHAR2 (8)   PATH 'XOEI_IDSITE',
                         xoei_cdapli     VARCHAR2 (8)   PATH 'XOEI_CDAPLI',
                         xoei_cddoss     VARCHAR2 (8)   PATH 'XOEI_CDDOSS',
                         xoei_cdmag      NUMBER (6)     PATH 'XOEI_CDMAG',
                         xoei_iduser     VARCHAR2 (128) PATH 'XOEI_IDUSER',
                         xoei_cdedt      VARCHAR2 (32)  PATH 'XOEI_CDEDT',
                         xoei_tyorient   CHAR (1)       PATH 'XOEI_TYORIENT',
                         xoei_cdcleort   VARCHAR2 (8)   PATH 'XOEI_CDCLEORT',
                         xoei_cdimp      VARCHAR2 (64)  PATH 'XOEI_CDIMP',
                         xoei_flimpdir   RAW (2)        PATH 'XOEI_FLIMPDIR',
                         xoei_nbexplr    NUMBER (2)     PATH 'XOEI_NBEXPLR',
                         xoei_flarchiv   NUMBER (1)     PATH 'XOEI_FLARCHIV',
                         xoei_flenvoi    NUMBER (1)     PATH 'XOEI_FLENVOI',
                         xoei_cddest     VARCHAR2 (32)  PATH 'XOEI_CDDEST',
                         xoei_mdfoncsp   VARCHAR2 (1)   PATH 'XOEI_MDFONCSP',
                         xoei_norang     NUMBER (2)     PATH 'XOEI_NORANG'
                         ) x;
```                         



### pb connu sur XMLTABLE

<br> Insert XMLTYPE dans une colonne de table trim les blancs

<u><i>Exemple</i></u>

```
DROP TABLE GTT_DFEX_UTIL_CONF_SITE CASCADE CONSTRAINTS;

CREATE GLOBAL TEMPORARY TABLE GTT_DFEX_UTIL_CONF_SITE
(
  COL_XML  SYS.XMLTYPE
)
ON COMMIT PRESERVE ROWS
NOCACHE;

INSERT INTO gtt_dfex_util_conf_site
            (col_xml
            )
     VALUES (XMLTYPE
                ('
                <CONF>
	                  <TABLE>
				             <EXOEI num="1">
				                  <XOEI_IDUSER> </XOEI_IDUSER>
				                  <XOEI_CDEDT> </XOEI_CDEDT>
				             </EXOEI>
	                  </TABLE>
                 </CONF>
                ')
            );

```
<br>On obtient 

```Xml
<CONF>
	<TABLE>
				<EXOEI num="1">
				       </XOEI_IDUSER>
				       </XOEI_CDEDT>
				</EXOEI>
	</TABLE>
</CONF>
```
- solution 

<br> Si possible, passer directement la variable XMLTYPE dans la clause FROM (cf la requête précédente)

### Perf avec XMLTABLE

<br> en soi cette technique est assez rapide (par rapport a d'autre comme DBMS_XMLSAVE à base de Java), mais si la colonne à manipuler se trouve dans une table permanente (et non une gtt), il est ossible d'y associé un INDEX xdb pour booster encore plus les résultats :

<i>Exemple</i>
```Sql
CREATE ma_table_xml (col_xml XMLTYPE);

CREATE INDEX i_ma_table_xml
   ON ma_table_xml (col_xml)
   INDEXTYPE IS XDB.XMLINDEX;
```
       


### Gestion du XML (XMLTYPE)

cf doc oracle 11g https://docs.oracle.com/cd/B28359_01/appdev.111/b28369/xdb04cre.htm


<i>Exemple</i>

```Sql
SELECT UPDATEXML (xmltype (agci_xmlpar),
                  'APGCI/SCRIPT_JS',
                  '<SCRIPT_JS>emag_REFE_ARTI_m_MGARG.js</SCRIPT_JS>')
  FROM apgci
 WHERE agci_nogci = 532 AND agci_cdapli = 'emag';
 ```
 <i>Remarque</i>
 <br>Le dernier noeud doit reprendre la balise au cas ou cell-ci est vide