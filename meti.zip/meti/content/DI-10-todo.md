+++
date="2017-05-16T15:12:23+02:00"
draft="true"
title="Todo"
author="Timothé Clavier"
[menu.main]

identifier="DI-10-todo"
parent="DI-1-Divers"

+++
Auteur:  
Date: 25/08/2016

----------------------
### 1- SQL
	
  - Différence entre CHAR et VARCHAR2
  - utilisation de sysdate dans un group by
  

### 2- PL/SQL

- Exemple de PLSQL optimisé 
<br> - liste des actions effectuées
<br> - comparatif avant et après
<br> - Exemple Requete avec where (select ma_col from ma_table)='54' ( a banir)
<br>Exemple XMl 

```Sql 
declare

b   blob := utl_raw.cast_to_raw ('<a>myxml</a>');
BEGIN
--open :cur for select (xmltype (utl_raw.cast_to_varchar2 (b))) xml from dual;
open :cur for select ((utl_raw.cast_to_varchar2 (b))) xml from dual;
END;
/
```